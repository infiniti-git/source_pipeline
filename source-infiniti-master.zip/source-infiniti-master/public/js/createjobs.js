var _token = $('meta[name=csrf-token]').attr("content");
$(document).ready(function(){
  $("#add_screen_questions").on("click", function(){
    $("#new_question_area").append('<div class="row new_screening_question_row"><div class="col-md-3"><input type="text" class="form-control new_screening_question_title" maxlength="20" placeholder="Question Title" /></div><div class="col-md-8" style="padding-left:0"><input type="text" class="form-control new_screening_question" maxlength="255" placeholder="Write new screening question" /></div><label class="col-md-1 btn btn-sm btn-danger remove_screening_question" style="padding:0.4rem .5rem"><i class="fa fa-trash "></i></label></div>');
    $("#new_question_area").show();
    $("#btn_save_screening_question").show();
  });
});

$(document).on("click",".remove_screening_question", function(){
  $(this).closest('.new_screening_question_row').remove();
  if($(".new_screening_question").length == 0){
    $("#btn_save_screening_question").hide();
  }
});

$(document).on("click","#btn_save_screening_question", function(){
    var questions = [];
    var stop = false;
    var thisobj = $(this);
    $('.new_screening_question_row').each(function(){
        var ques_title = $(this).find('.new_screening_question_title').val();
        var ques = $(this).find('.new_screening_question').val();
        if(ques_title != '' && ques != ''){
            var tmp_ques_arr = {'question_title':ques_title,'question':ques}; 
            questions.push(tmp_ques_arr);
        }else{
            $(this).find('.new_screening_question_title').focus();
            stop = true;
            return false;
        }
    });
    if(stop){
        $.alert({
            title: 'Error!',
            content: "Please provide Question Title & Question for all questions!",
        });
        return false;
    }

    if(questions.length <= 0){
        return false;
    }

    $.ajax({
        url:STORE_QUESTION_ROUTE,
        type:"POST",
        data:{questions:questions,_token:_token},
        success:function(response){
            if(response.status == 'success'){
                for(var i=0; i<response.questions.length; i++){
                    $('.screening_questions_area').append('<label class="col-md-5 checkbox-inline"><input name="standard_questions[]" type="checkbox" value="'+response.questions[i]['question_id']+'">&nbsp;'+response.questions[i]['question']+'</label>');
                }
                $('#new_question_area').html('');
                $(thisobj).hide();
            }else{
                $.alert({
                    title: 'Error!',
                    content: response.message,
                });
            }
        },
        error:function(xhr,err){
            alert(err);
        }
    });
});
