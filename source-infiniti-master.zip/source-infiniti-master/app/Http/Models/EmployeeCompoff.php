<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use DateTime;

class EmployeeCompoff extends Model
{
    protected $table = 'employee_compoff';

    protected $primaryKey = 'id';

    protected $fillable = (['employee_id','date','day_type','hours','status','created_by','updated_by']);

     static function GetEmployeeCompOffofMonth($month,$year,$empid)
    {
        $query = DB::table('employee_compoff as E1')
        ->whereYear('E1.date', '=', $year)
        ->whereMonth('E1.date', '=', $month)
        ->where('E1.employee_id',$empid)
        ->get();
        return $query;
    }
}
