<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobApplicationStatus extends Model
{
    protected $table = 'job_application_status';
    protected $primaryKey = 'id';
}
