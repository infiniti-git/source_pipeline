<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Questions extends Model
{
   	protected $table = 'questions';
    protected $primaryKey = 'id';

    public function jobs(){
    	return $this->belongsToMany('App\Models\Jobs','jobs_questions_mapping','jobs_id','questions_id');
    }
}
