<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
class Jobs extends Model
{
    protected $table = 'jobs';
    protected $primaryKey = 'id';

    public function questions(){
    	return $this->belongsToMany('App\Models\Questions','jobs_questions_mapping','jobs_id','questions_id');
    }

    public function getJobsCountOfTheDay($date = ''){
    	if($date == ''){
    		$dt = Carbon::now();
			$date = $dt->toDateString();
    	}
    	$result = $this->whereDate('created_at',$date)->get();
    	return $result;
    }

    public function getNextJobReference(){
    	$job_count_today = $this->getJobsCountOfTheDay();
        $job_cnt = $job_count_today->count();
        if($job_cnt < 10){
            $job_cnt = '0'.($job_cnt+1);
        }
        $dt = Carbon::now();
        $next_job_id = 'J'.$dt->format('ymd').$job_cnt;
        return $next_job_id;
    }

    public function applications(){
        return $this->hasMany('App\Models\JobApplication','jobs_id','id');
    }
}
