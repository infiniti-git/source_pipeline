<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobsQuestionsAnswers extends Model
{
    protected $table = 'jobs_questions_answers';
    protected $primaryKey = 'id';
}
