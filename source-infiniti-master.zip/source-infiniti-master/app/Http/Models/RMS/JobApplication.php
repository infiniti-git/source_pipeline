<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobApplication extends Model
{
    protected $table = 'jobs_applications';
    protected $primaryKey = 'id';

    public function status(){
        return $this->belongsTo('App\Models\JobApplicationStatus','application_status','id');
    }

    public function answers(){
        return $this->hasMany('App\Models\JobsQuestionsAnswers','application_id','id');
    }
}
