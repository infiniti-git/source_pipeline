<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobsQuestionsMapping extends Model
{
    protected $table = 'jobs_questions_mapping';
    protected $primaryKey = 'id';


    public function questions(){
    	return $this->belongsTo('App\Models\Questions','id','questions_id');
    }

    public function jobs(){
    	return $this->belongsTo('App\Models\Jobs','id','jobs_id');
    }
}
