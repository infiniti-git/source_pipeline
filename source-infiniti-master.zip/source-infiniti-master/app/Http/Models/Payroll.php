<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Payroll extends Model
{
    protected $table = 'payroll';

    protected $primaryKey = 'id';

    protected $fillable = [
		'id',
		'employee',
		'month',
		'year',
		'basicpay',
		'reimbursment',
		'isloyaltyapplicable',
		'loyaltybonus',
		'totalpay',
		'created_at',
		'updated_at',
		'source_workingday',
		'workingday',
		'leaveencashamount',
		'leavetaken',
		'ispayrollgenerated',
		'invoicelink',
		'incentiveamount',
		'created_by',
		'updated_by'
	];

	static function GetPayroll($empid,$month,$year)
    {
    	
		$query = DB::table('payroll as P1')
				->join('employees as E1', 'E1.id', '=', 'P1.employee')
				->leftjoin('month as M1', 'M1.id', '=', 'P1.month')
				->leftjoin('leaveencash as L1', 'L1.employee_id', '=', 'P1.employee')
				->where('P1.employee',$empid)
				->where('P1.month',$month)
				->where('P1.year',$year)
				->where('L1.month',$month)
				->where('L1.year',$year)
				->select('P1.*','E1.name as employeename','M1.month as payrollmonth', 'E1.joineddate','L1.cl_leave','L1.compoff_leave')    		
				->get();
		    	
		return $query;
		    
	}
}
