<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class EmployeeLeaveMaster extends Model
{
    protected $table = 'employee_leave_master';

    protected $primaryKey = 'id';

    protected $fillable = ['id','employee_id','balance','lop','month','year','created_by','created_at','updated_at'];

    static function GetEmployeeLeaveMasterDetails($month,$year,$empid)
    {
    	
		$query = DB::table('employee_leave_master')
		    		
		->where('month',$month)
		    		
		->where('year',$year)
		    		
		->where('employee_id',$empid)
		    		
		->first();
		    	
		return $query;
		    
	}


}
