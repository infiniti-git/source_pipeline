<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class EmployeeCompoffMaster extends Model
{
    protected $table='employee_compoff_master';

    protected $primarKey = 'id';

    protected $fillable = ['id','employee_id','available','expired','created_at','updated_at'];

    static function GetEmployeeMonthCompOffDetails($empid,$month,$year)
    {
    	
		$query = DB::table('employee_compoff_master')
		->where('month',$month)
		    		
		->where('year',$year)
		    		
		->where('employee_id',$empid)
		    		
		->first();
		    	
		return $query;
		    
	}

}
