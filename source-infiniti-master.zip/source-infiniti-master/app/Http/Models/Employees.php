<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Employees extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'employees';

   protected $fillable = ['id','name','email',
      'skypeid',
      'supervisor',
      'phone',
      'resource',
      'payment',
      'avatar',
      'status',
      'created_by',
      'updated_by',
      'created_at',
      'updated_at',
      'basicpay',
      'loyaltybonus',
      'address',
      'isloyaltybonus',
      'joineddate',
      'team',
      'company',
      'role',
      'hourstype'
    ];

     static function EmployeeDetails($resourceStatus)
     {
         $query = DB::table('employees as T1');
                  $query->leftjoin('employees as J1', 'J1.id', '=', 'T1.supervisor');
                  $query->leftjoin('team as D1', 'D1.id', '=', 'T1.team');
                  if($resourceStatus == 1)
                  {
                    $query->where('T1.status', '=', 1);
                  }
                  elseif($resourceStatus == 2)
                  {
                    $query->where('T1.status', '=', 2);
                  }
                  $query->select('T1.id as employeeId','T1.name','T1.email','T1.skypeid','J1.name as supervisor','T1.resource','T1.status','D1.teamname');
                  $query->orderBy('T1.name','asc');
                  $result= $query->get();
          return $result;
     }

     static function GetActiveResourcesCount()
     {
      $query = DB::table('employees as T1')
                  ->where('T1.status', '!=', 2)
                  ->count();
          return $query;
     }

     static function GetInActiveResourcesCount()
     {
      $query = DB::table('employees as T1')
                  ->where('T1.status', '=', 2)
                  ->count();
          return $query;
     }

     static function GetAllEmployeeDetails()
     {
          $query = DB::table('employees as T1')
                  ->leftjoin('employees as J1', 'J1.id', '=', 'T1.supervisor')
                  ->leftjoin('company as C1', 'C1.id','=','T1.company')
                  ->leftjoin('role as U1', 'U1.id','=','T1.role')
                  ->leftjoin('team as E1', 'E1.id','=','T1.team')
                  ->leftjoin('payment_type as P1', 'P1.id','=','T1.payment')
                  //->where('T1.status', '!=', 2)
                  ->select('T1.name','T1.email','T1.skypeid','J1.name as supervisor','T1.phone','T1.address','U1.name as role','E1.teamname as team','T1.basicpay','T1.loyaltybonus','T1.joineddate','C1.name as company','T1.resource','T1.status','P1.payment_type as payment'
                    )
                  ->orderBy('T1.status','asc')
                  ->get();
          return $query;
     }

     static function GetActiveEmployeeDetailsById($resourceId)
     {
          $query = DB::table('employees as T1')
                  ->where('T1.id', '=', $resourceId)
                  ->where('T1.status', '!=', 2)
                  ->select('T1.id as employeeId','T1.name','T1.email','T1.skypeid','T1.phone','T1.address','T1.basicpay','T1.loyaltybonus','T1.joineddate','T1.resource','T1.payment as payment_type','T1.isloyaltybonus'
                    )
                  ->first();
          return $query;
     }

     static function GetEmployeeById($resourceId)
     {
         $query = DB::table('employees as T1')
                  ->where('T1.id', '=', $resourceId)
                  ->first();
        return $query;
     }

    static function ResourceLeavesDetails()
    {
        $query = DB::table('employees as T1')
                ->leftJoin('employee_leave_master as J1', 'J1.employee_id', '=', 'T1.id')
                ->leftJoin('employee_compoff_master as J2', 'J2.employee_id', '=', 'J1.employee_id')                
                ->where(['T1.status'=>1])->get();
        return $query;
    }

    static function GetEmployeeIdByName($resourceName)
     {
         $query = DB::table('employees as T1')
                  ->where('T1.name', '=', $resourceName)
                  ->where(['T1.status'=>1])
                  ->select('T1.id','T1.name')
                  ->first();
        return $query;
     }

     static function GetActiveEmployees()
     {
         $query = DB::table('employees as T1')
                  ->where('T1.status', '=', 1)
                  ->get();
        return $query;
     }

     static function GetSupervisors()
     {
         $query = DB::table('employees as T1')
                  ->select('T1.id as supervisorId','T1.name as supervisorName')
                  ->where('T1.status', '=', 1)
                  ->whereIn('T1.role',array(1,3))
                  ->get();
        return $query;
     }

     static function GetEmployeesByResource($resourceId)
     {
         $query = DB::table('employees as T1');
                  $query->where(['T1.status'=>1]);
                  if($resourceId>0)
                  {
                    $query->where('T1.id','=',$resourceId);
                  }
                  $query->where('T1.resource','=',2);

                  $result=$query ->get();
        return $result;
     }
}
