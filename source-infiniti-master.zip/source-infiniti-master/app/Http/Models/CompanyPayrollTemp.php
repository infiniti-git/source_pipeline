<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class CompanyPayrollTemp extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'company_payroll_temp';

    protected $fillable = ['id','company_id','employee_id',
      'month',
      'year',
      'inapp_workingdays',
      'ehrs_days',
      'basicpay',
      'salary',
      'encashment',
      'total_pay',
      'file_path',
      'created_at',
      'updated_at',
      'generated_by',
    ];

}
