<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Month extends Model
{
    protected $table = 'month';
    protected $primaryKey = 'id';   
    static function GettingMonthName($monthid)
    {
		$query = DB::table('month')->where('id',$monthid)->select('month')->first();
		return $query;
    } 
}
