<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class LoyaltyBonus extends Model
{
    protected $table = 'loyaltybonus';

    protected $primaryKey = 'id';

    protected $fillable = [
		'id',
		'employee',
		'month',
		'year',
		'loyaltybonusamount',
		'created_by',
		'updated_by',
		'created_at',
		'updated_at'
	];

	static function GetLoyaltyBonusofMonth($empid,$month,$year)
    {
    	
		$query = DB::table('loyaltybonus')
		    		
		->where('employee',$empid)

		->where('month',$month)

		->where('year',$year)
		    		
		->first();
		    	
		return $query;
		    
	}
}
