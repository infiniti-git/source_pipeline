<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Team extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'team';

    protected $fillable = ['id','teamname'];
    

     static function GetTeams()
     {
         $query = DB::table('team')
                  ->get();
        return $query;
     }

}
