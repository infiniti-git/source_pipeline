<?php



namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model as Eloquent;

use Jiaxincui\Hashid\Traits\Hashid;

/**
 * Class Lead
 *
 * @property int $id
 * @property string $payment_type
 * @property string $status
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * 
 * @package App\Http\Models
 */
class PaymentType extends Eloquent
{

    protected $table = 'payment_type';
	protected $primaryKey = 'id';

	protected $casts = [
		'payment_type' => 'string',
		'status'=> 'string'		
	];

	protected $fillable = [
		'payment_type',
		'status'
	];

}