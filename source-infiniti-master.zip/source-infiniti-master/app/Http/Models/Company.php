<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Company extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'company';

    protected $fillable = ['id','name','status'];
    

     static function GetCompany()
     {
         $query = DB::table('company')
                  ->get();
        return $query;
     }

}
