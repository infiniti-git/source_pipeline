<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class EmployeeLeave extends Model
{
    protected $table = 'employee_leave';

    protected $primaryKey = 'id';

    protected $fillable = ['employee_id', 'date', 'leave_type','day_type','status','created_by'];



    static function ResourceMonthLeaves($month,$year)
    {
        $query = DB::table('employee_leave as T1')
                ->LeftJoin('employees as J1', 'J1.id', '=', 'T1.employee_id')
                ->whereYear('date', '=', $year)
                ->whereMonth('date', '=', $month)
                ->select('T1.id as leave_id','T1.*','J1.*')
				->get();
        return $query;
    }

    static function GetEmployeeLeaveDetailsForMonth($month,$year,$empid)
    {
        $query = DB::table('employee_leave')
        ->whereYear('date', '=', $year)
        ->whereMonth('date', '=', $month)
        ->where('employee_id',$empid)
        ->get();
        return $query;
    }
}
