<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Users extends Model
{
    protected $table = 'users';

    protected $primaryKey = 'id';

    protected $fillable = [
		'id',
		'name',
		'email',
		'password',
		'avatar',
		'role',
		'status',
		'create_by',
		'update_by',
		'created_at',
		'updated_at'
	];

	 
}
