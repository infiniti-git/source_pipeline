<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model as Eloquent;

use Jiaxincui\Hashid\Traits\Hashid;

/**
 * Class Lead
 *
 * @property int $id
 * @property string $source_name
 * @property string $email
 * @property string $skypeid
 * @property int $phone
 * @property int $resource
 * @property int $payment
 * @property string $avatar
 * @property string $status
 * @property int $update_by
 * @property int $create_by
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 *
 * @property \App\Http\Models\PaymentType $paymenttype
 *
 *
 * @package App\Http\Models
 */
class Resource extends Eloquent
{

	use Hashid;

	protected $table = 'employee';

	protected $fillable = [
		'source_name',
		'email',
		'skypeid',
		'supervisor',
		'phone',
		'resource',
		'payment',
        'avatar',
		'status',
		'update_by',
		'create_by'
	];



    /*public function create($attributes){
      return $this->create($attributes);
    }*/

	
}