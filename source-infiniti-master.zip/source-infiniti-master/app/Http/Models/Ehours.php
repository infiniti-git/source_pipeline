<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Ehours extends Model
{
    protected $table = 'ehours';

    protected $primaryKey = 'id';

    protected $fillable = [
		'id',
		'user_id',
		'user_name',
		'ehour_date',
		'hrs',
		'created_at',
		'updated_at'
	];

	static function GetEhoursBySearch($request)
    {
    	$fromDate = date("Y-m-d", strtotime($request->ehour_fromdate));
    	$toDate = date("Y-m-d", strtotime($request->ehour_todate));
        $query = DB::table('ehours as T1');
        $query ->join('employees as E1', 'E1.id', '=', 'T1.employee_id');
        $query ->leftjoin('company as C1', 'C1.id', '=', 'E1.company');
        if($request->ehour_employee)
        {
        	$query ->where('T1.employee_id', '=', $request->ehour_employee);
        }
        if($request->resource_company != null)
        {
        	$query ->where('E1.company', '=', $request->resource_company);
        }
        if($fromDate != null && $fromDate != '1970-01-01')
        {
        	$query ->whereDate('T1.ehour_date', '>=', $fromDate);
        }
        if($toDate != null && $toDate != '1970-01-01')
        {
        	$query ->whereDate('T1.ehour_date', '<=', $toDate);
        }  
        $query ->select('T1.id as id','T1.employee_name','T1.ehour_date','T1.hrs');
		$result=$query ->get();
        return $result;
    }

    static function getEmployeeeHourforMonth($month,$year,$empid)
    {
        $query = DB::table('ehours')
                ->whereMonth('ehour_date',$month)
                ->whereYear('ehour_date',$year)
                ->where('employee_id',$empid)
                ->orderBy('ehour_date','DESC')
                ->select('hrs','ehour_date')
                ->get();
        return $query;
    }


    static function geteHourswithDateRangeEmp($start,$end,$empid)
    {
        $query = DB::table('ehours')
                ->whereBetween('ehour_date', array($start, $end))
                ->where('employee_id',$empid)
                ->orderBy('ehour_date','DESC')
                ->select('id','hrs','ehour_date')
                ->get();
        return $query;
    }
}
