<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class LeaveEncash extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'leaveencash';

   protected $fillable = ['id','employee_id','cl_leave',
      'compoff_leave',
      'month',
      'year',
      'no_of_cl',
      'created_by',
      'updated_by',
      'created_at',
      'updated_at'
    ];
}