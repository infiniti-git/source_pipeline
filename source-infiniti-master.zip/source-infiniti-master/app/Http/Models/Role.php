<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class role extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'role';

    protected $fillable = ['id','name','status'];

}
