<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class WorkingDays extends Model
{
    protected $table = 'working_days';

    protected $primaryKey = 'id';

    protected $fillable = ['id','month','year','days','created_by','updated_by','created_at','updated_at'];
    static function WorkingDaysofMonth($month,$year)
    {
        $query = DB::table('working_days');
		        if($month!=null && $month!=0)
		        {
		        	$query->where('month', '=', $month);
		        }
	            if($year!=null && $year!=0)
		        {
		        	$query->where('year', '=', $year);
		        }  
                $query->orderBy('year','DESC');
                $query->orderBy('month','DESC');
                $query->select('month','year','days');
				$result = $query->get();
        return $result;
    }
}
