<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class CompanyPayroll extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'company_pay_roll';

  

}
