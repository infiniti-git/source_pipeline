<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class HoursType extends Model
{
    protected $primaryKey = 'id';
    
    protected $table = 'hourstype';

    protected $fillable = ['id','hours_type','status'];
    
}
