<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Employees;
use App\Http\Models\EmployeeCompoff;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Controllers\Traits\ApiTrait;
use Validator;
use Session;
use Log;

class EmployeeCompoffController extends Controller
{
    use ApiTrait;
    //

     /*
      FUNCTION NAME   : AddCompOff
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/add_comp_off
      IF NOTES        : Add comp off for resources
      WROTE BY        : Yuvaraj
    */
    public function AddCompOff()
    {
      try
      {
    	$employees = Employees::where('status',1)->get();
        return view('leave.add_comp_off')->with(['employees'=>$employees]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : InsertCompOff
      ARGUMENTS       : Request
      ARGUMENTS NOTES : request - form input
      TABLE(DB)       : employee_compoff
      VIEW PAGE       : leave/add_comp_off
      IF NOTES        : Add comp off for employees
      WROTE BY        : Yuvaraj
    */
    public function InsertCompOff(Request $request)
    {
      try
      {
        $rules     = array('employee' => 'required', 'compoff_date' => 'required','day_type' => 'required');
        $userdata = array(
                    'employee'      => $request->employee,
                    'compoff_date'   => $request->compoff_date,
                    'day_type'     => $request->day_type,
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            $where = array('employee_id'=>$request['employee'],'date'=>date('Y-m-d', strtotime($request['compoff_date'])),'status'=>1);
            $emp_comp_details = EmployeeCompoff::where($where)->first();
            if(isset($emp_comp_details) && count($emp_comp_details)>0)
            {
                Session::flash('error','Comp-off already added to this Employee');
            }
            else
            {
                $compoffdate = explode('-', $request->compoff_date);
                $month = $compoffdate[1];
                $year  = $compoffdate[2];
                $day_type = $request['day_type'];
                $where = array('employee_id'=>$request['employee'],'month'=>$month,'year'=>$year);
                $CompOffMaster = EmployeeCompoffMaster::where($where)->first();
                if(isset($CompOffMaster) && !empty($CompOffMaster) && count($CompOffMaster)>0)
                {
                    $details = $CompOffMaster->toArray();  
                    $total_comp_off = $details['available'] + (($day_type==1)?1:(($day_type==2)?0.5:0));
                    if($day_type==3)
                    {
                      $employee = Employees::where('id',$request['employee'])->select('hourstype')->first();
                      if(isset($employee) && !empty($employee) && count($employee)>0 && isset($employee->hourstype) )
                      {
                        $day = $this->calculateDayType($request['hours'],$employee->hourstype);
                        $total_comp_off = $total_comp_off + $day;
                      }
                    }
                    $update_data = array('available'=>$total_comp_off,'updated_at'=>date('Y-m-d H:i:s'));
                    $CompOffMaster = EmployeeCompoffMaster::where($where)->update($update_data);
                }
                else
                {
                    $total_comp_off = (($day_type==1)?1:(($day_type==2)?0.5:0));
                    if($day_type==3)
                    {
                      $employee = Employees::where('id',$request['employee'])->select('hourstype')->first();
                      if(isset($employee) && !empty($employee) && count($employee)>0 && isset($employee->hourstype) )
                      {
                        $day = $this->calculateDayType($request['hours'],$employee->hourstype);
                        $total_comp_off = $day;
                      }
                    }
                    $insert_data = array('employee_id'=>$request['employee'],'available'=>$total_comp_off,'expired'=>0,'month'=>$month,'year'=>$year,'created_at'=>date('Y-m-d H:i:s'));
                    $CompOffMaster = EmployeeCompoffMaster::insert($insert_data);
                }
                $data = array(
                                'employee_id'=>$request['employee'],
                                'date'=>date('Y-m-d', strtotime($request['compoff_date'])),
                                'day_type'=>$day_type,
                                'status'=>1,
                                'created_by'=>Session::get('UserData')['SA_id'],
                                'created_at'=>date('Y-m-d H:i:s')
                            );
                if($request['day_type']==3 && $request['hours']!='')
                {
                    $data['hours']=$request['hours'];
                }
                EmployeeCompoff::create($data);
                Session::flash('success','Comp-off Created Successfully');
            }
            return redirect()->route('admin/add_comp_off');
        }  
      }
      catch(\Exception $e)
      {
        \Log::error($e);
        dd($e);
      }          
    }
}
