<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Employees; 
use App\Http\Models\EmployeeLeaveMaster;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Models\EmployeeCompoff;
use App\Http\Models\Ehours;
use App\Http\Models\Month;
use App\Http\Models\EmployeeLeave;
use App\Http\Models\WorkingDays;
use App\Http\Models\Payroll;
use App\Http\Models\CompanyPayrollTemp;
use App\Http\Models\CompanyPayroll;
use DB;
use Session;
use Helpers;
use Validator;
use Auth;
use URL;
use App\Http\Models\Company;
use App\Http\Controllers\Traits\ApiTrait;
use Log;



class AjaxController extends Controller
{
  use ApiTrait;
    /* AJAX STARTS */

    /*
      FUNCTION NAME   : GetEmployeeByResourceType
      ARGUMENTS       : Request
      ARGUMENTS NOTES : Requets - get inputs
      TABLE(DB)       : employee
      VIEW PAGE       : NULL
      IF NOTES        : Get employees based on resource type
      WROTE BY        : Yuvaraj
    */
    public function GetEmployeeByResourceType(Request $request)
    {
      try
      {
        $type = $request['type']; 
        $where = array('status'=>1);
        if($type!='' && $type>0)
        {
            $where['resource'] = $type;
        }
        $employees = Employees::where($where)->select('id','name')->get();
        $data = view('includes.ajax-select',compact('employees'))->render();
        return response()->json(['options'=>$data,'emplength'=>count($employees)]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    public function GetEmployeeByCompany(Request $request)
    {
      try
      {
        $company = $request['company']; 
        $where = array('status'=>1);
        if($company!='' && $company>0)
        {
            $where['company'] = $company;
        }
        $employees = Employees::where($where)->select('id','name')->get();
        $data = view('includes.ajax-select',compact('employees'))->render();
        return response()->json(['options'=>$data]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : GetEmployeeCL
      ARGUMENTS       : Request
      ARGUMENTS NOTES : Request - get inputs
      TABLE(DB)       : employee
      VIEW PAGE       : NULL
      IF NOTES        : Get employee CL for current month 
      WROTE BY        : Yuvaraj
    */
    public function GetEmployeeCL(Request $request)
    {
      try
      {
        $employee_id = $request['emp_id'];
        $where = array('employee_id'=>$employee_id,'status'=>1);
        $employeesCL = EmployeeLeaveMaster::where($where)->select('balance','id')->first();
        if($employeesCL)
        {
            $data['cldays'] = $employeesCL->balance;
            $data['clid'] = $employeesCL->id;
         }
        else
        {
            $data['cldays'] = ''; 
            $data['clid'] = '';        
        }
        return response()->json($data);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


     /*
      FUNCTION NAME   : Get_Leave_Details
      ARGUMENTS       : Request
      ARGUMENTS NOTES : Request - get inputs
      TABLE(DB)       : employee_leave_master
      VIEW PAGE       : NULL
      IF NOTES        : Get employee CL for current month 
      WROTE BY        : Yuvaraj
    */
    public function GetLeaveDetails(Request $request)
    {
      try
      {
    	$employee_id = $request['emp_id'];
    	$leave_type = $request['lev_type'];
    	/*if($leave_type==1)
    	{*/
        	$where = array('employee_id'=>$employee_id,'status'=>1);
        	$employeesCL = EmployeeLeaveMaster::where($where)->select('balance','id')->first();
    	/*}
    	else
    	{
    		$where = array('employee_id'=>$employee_id,'status'=>1);
        	$employeesCL = EmployeeLeaveMaster::where($where)->select('balance','id')->first();
    	}*/
        if($employeesCL)
        {
            $data['cldays'] = $employeesCL->balance;
            $data['clid'] = $employeesCL->id;
        }
        else
        {
            $data['cldays'] = '';
            $data['clid'] = '';
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : UpdateEhour
      ARGUMENTS       : Hours
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : ehours
      VIEW PAGE       : NULL
      WROTE BY        : Jenifer
    */
    public function UpdateEhour(Request $request)
    {
      try
      {
        $rules     = array('hrs' => 'required');
        $userdata = array(
                    'hrs'=> $request->hrs
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            if($request['id']!='')
            {
              
                $data = array( 'hrs'=>$request['hrs']);
                $ehours = Ehours::where('id',$request['id'])->update($data);
            }
           
            return response()->json($ehours);
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    public function SearchEhour(Request $request)
    {
      try
      {
        $ehours = Ehours::GetEhoursBySearch($request);
        //$data = view('includes.ajax-ehourstable',compact('ehours'))->render();
        return view('includes.ajax-ehourstable')->with('ehours',$ehours);
        //return response()->json(['ehours'=>$data]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }
        

    /* AJAX  ENDS  */ 

    /*
      FUNCTION NAME   : AddCLResource
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employee_leave_master
      VIEW PAGE       : NULL
      IF NOTES        : Add cl for every month 1st day.
      WROTE BY        : Yuvaraj
    */
    public function AddCLResource()
    {
      try
      {
        $employees = Employees::whereIn('status',array(1, 2))->get();
        foreach ($employees as $value) 
        {
            $where=array('employee_id'=>$value->id,'status'=>1);
            $employee_leave = EmployeeLeaveMaster::where($where)->first();
            if(isset($employee_leave) && !empty($employee_leave) && count($employee_leave)>0)
            {
                if(date('m')==1)
                {
                    $new_balance = 1;
                }
                else
                {
                    $new_balance = $employee_leave->balance + 1;
                }                
                $update_id = $employee_leave->id;
                $where=array('id'=>$update_id);
                $update_data = array('status'=>0);
                EmployeeLeaveMaster::where($where)->update($update_data);
                $insert_data  = array(
                        'employee_id'=>$employee_leave->employee_id,
                        'balance'=>$new_balance,
                        'lop'=>0,
                        'month'=>date('m'),
                        'year'=>date('Y'),
                        'created_by'=>0,
                        'created_at'=>date('Y-m-d H:i:s')
                    );
                EmployeeLeaveMaster::insert($insert_data);
            }
            else
            {
                /* chceking joining date starts */ 
                //$joining = $value->joining;
                $joining = '2018-10-25';
                $last_month = date('m', strtotime("last month"));
                $joining_month = date('m',strtotime($joining));
               
                if($last_month == $joining_month)
                {
                    $joining_date = date('d',strtotime($joining));
                    if($joining_date>=1 && $joining_date<=7)
                    {
                        $balance = 2;
                    }
                    elseif($joining_date>=8 && $joining_date<=19)
                    {
                        $balance = 1.5;
                    }
                    else
                    {
                        $balance = 1;
                    }
                }
                else
                {
                    $balance = 1;
                }
                /* checking joining date  ends  */

                $insert_data  = array(
                        'employee_id'=>$value->id,
                        'balance'=>$balance,
                        'lop'=>0,
                        'month'=>date('m'),
                        'year'=>date('Y'),
                        'created_by'=>0,
                        'created_at'=>date('Y-m-d H:i:s')
                    );
                EmployeeLeaveMaster::insert($insert_data);
            }
            
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      } 
    }


    /*
      FUNCTION NAME   : CompOffExpiry
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employee_compoff_master
      VIEW PAGE       : NULL
      IF NOTES        : Expiry Compoff dates
      WROTE BY        : Yuvaraj
    */
    public function CompOffExpiry()
    {
      try
      {
        $employees = Employees::whereIn('status',array(1, 2))->get();
        foreach ($employees as $value) 
        {
            $where=array('employee_id'=>$value->id,'status'=>1);
            $compoffdates = EmployeeCompoff::where($where)->get();
            if(isset($compoffdates) && !empty($compoffdates) && count($compoffdates)>0)
            {
                if(isset($compoffdates) && !empty($compoffdates) && count($compoffdates)>0)
                {
                    foreach ($compoffdates as $compoff) 
                    {
                        $last_date = date('d-m-Y', strtotime('-30 days'));
                        if($last_date>$value->date)
                        {
                            $day = ($compoff->day_type==1)?1:(($compoff->day_type==2)?0.5:0);
                            $where = array('id'=>$compoff->id);
                            $update_data = array('status'=>0);
                            EmployeeCompoff::where($where)->update($update_data);

                            $where = array('employee_id'=>$value->id);
                            $compoffMaster = EmployeeCompoffMaster::where($where)->first();                            
                            $available = $compoffMaster->available - $day;
                            $expired = $compoffMaster->expired + $day;

                            $where = array('id'=>$compoffMaster->id);
                            $update_data = array('available'=>$available,'expired'=>$expired,'updated_at'=>date('Y-m-d H:i:s'));
                            EmployeeCompoffMaster::where($where)->update($update_data);
                        }
                    }
                }
            }
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      } 
    }


/*
      FUNCTION NAME   : CalculatePayroll
      
ARGUMENTS       : NULL
      
ARGUMENTS NOTES : NULL
      
TABLE(DB)       : ehours,employee,employee_leave_master,employee_compoff_master
      
VIEW PAGE       : null
      
IF NOTES        : payroll calculations
      
WROTE BY        : Yuvaraj
    */
    
public function CalculatePayroll(Request $request)
{
    $emp_id =  $request['emp_id'];

    //$resource_type = $request['resource_type'];

    $where = array('user_name'=>$emp_id);
    $requestmonth=0;
    $requestyear = 0;
    if(isset($request['monthyear']) && $request['monthyear'] != null)
    {
      $explode =explode('/',$request['monthyear']);
      if(!empty($explode)){
        $requestmonth = $explode[0];
        $requestyear = $explode[1];
      }
    }
    $workingdays = WorkingDays::WorkingDaysofMonth($requestmonth,$requestyear);
    if(isset($workingdays) && count($workingdays)>0)
    {
      foreach ($workingdays as $workingday) 
      {

        $month = $workingday->month;
                
        $months = Month::GettingMonthName($workingday->month);

        $mon = json_decode(json_encode($months),true);
                       
        $month_name = $mon['month'];
      
        $year = $workingday->year;
                        
        $total_days  = $workingday->days;
                      
        //$employees = Employees::GetActiveEmployees()->toArray();

        $employees = Employees::GetEmployeesByResource($emp_id)->toArray();
                    
        if(isset($employees) && count($employees)>0)
        {
          foreach ($employees as $employee)
          {
            $emppayrolldetails = array();
            $empid = $employee->id;
            $hourstype = 0;
            if(isset($employee->hourstype) && !empty($employee->hourstype))
            {
              $hourstype = $employee->hourstype;
            }

            /* CHECKING INAPP WORKING DAYS STARTS */
          
            $empworkdays = $this->getEmployeeInappWorkingDays($empid, $month, $year, $total_days,$hourstype); 
            //dd($employeecompoffs);
            /* CHECKING INAPP WORKING DAYS ENDS */
            /* CHECKING IS PAYROLL GENERATED */
             $payrollgenerated = false;
             $payrollinvoicelink = "#";
             $ispayrollgenerated = Payroll::where('month',$month)->where('year',$year)->where('employee',$empid)->first();
             if(isset($ispayrollgenerated))
             {
                $payrollgenerated = $ispayrollgenerated['ispayrollgenerated'];
                $payrollinvoicelink = $ispayrollgenerated['invoicelink'];
             }
            /* CHECKING IS PAYROLL GENERATED END */

            /* CHECKING EHOURS WORKING DAYS STARTS */
            $ehourday = $this->getEmployeeEhrsDays($empid, $month, $year,$hourstype);
            /* CHECKING EHOURS WORKING DAYS  ENDS  */
            if($empworkdays==$ehourday)
            {
                $ready = 1;
            }
            else
            {
                $ready = 0;
            }
            $emppayrolldetails = array(
                                'emp_name'=>$employee->name,
                                'month'=>$month_name,
                                'year'=>$year,
                                'inapp'=>$empworkdays,
                                'ehour'=>$ehourday,
                                'ready'=>$ready,
                                'empid'=>$empid,
                                'isppayrollgenerated'=>$payrollgenerated,
                                'invoicelink'=>$payrollinvoicelink,
                                'role'=>Session::get('UserData')['role']
                            );
            $all_over_details[] = $emppayrolldetails;
        }
      }
      else
      {
          $all_over_details = array();
      }
    }
    
    }
    else 
    {
        $all_over_details = array();
    }
      return view('payroll.table_details')->with('over_details',$all_over_details);
    }




    public function EhourDetailsDaterange(Request $request)
    {
        $empid = $request['emp_id'];
        $start = date('Y-m-d',strtotime($request['startdate']));
        $end =  date('Y-m-d',strtotime($request['enddate']));
        $ehours_date = Ehours::geteHourswithDateRangeEmp($start,$end,$empid);
        return view('payroll.ehourslist')->with('ehours',$ehours_date);

        //print_r($ehours_date);
        //return view('payroll.table_details')->with('over_details',$ehours_date);
    }


    /**
    * Get Companies
    * @method GET
    * @param 
    * @return json
    */

    public  function getCompanies()
    {
      try{
        $companies = Company::where('status','1')->get();
        $response['status']  = true;
        $response['code']    = 1;
        $response['message'] = 'success';
        $response['result']  = $companies;
        // $response = $this->getReponse(TRUE, 1, $companies);
        return $response;
      }catch (\Exception $e) {echo $e->getMessage(); exit;
            $response = $this->getResponse(FALSE, 0, $e->getMessage());
            $this->errorLogCreate('ApiTrait', 'getActualSolarType', 'error', 1, ['catch'=>$e->getMessage()]);
            return $response;
        }
    }


    /**
    * Get Employees by company / direct
    * @method POST
    * @param company
    * @return json
    */
    public  function getEmployees(Request $request)
    {
      try{
        $company = $request['company']; 
        if($company > 0)
          $employees = Employees::where('company', $company)->select('id','name')->get();
        else
          $employees = Employees::whereNull('company')->select('id','name')->get();
        
        $response['status']  = true;
        $response['code']    = 1;
        $response['message'] = 'success';
        $response['result']  = $employees;
        // $response = $this->getReponse(TRUE, 1, $companies);
        return $response;
      }catch (\Exception $e) {echo $e->getMessage(); exit;
            $response = $this->getResponse(FALSE, 0, $e->getMessage());
            $this->errorLogCreate('AjaxController', 'getEmployees', 'error', 1, ['catch'=>$e->getMessage()]);
            return $response;
        }
    }

   /**
    * Delete the applied leave
    * @method POST
    * @param request
    * @return json
    */
    public function CompanyPayrollUpdate(Request $request)
    {
      try
      {
        $explode = explode('/',$request['monthyear']);
        $month = $explode['0'];
        $year = $explode['1'];
        $rules     = array('salary' => 'required','encashment' => 'required','total_pay'=>'required');
        $userdata = array(
                    'salary'=> $request->salary,
                    'encashment'=> $request->encash,
                    'total_pay'=> $request->total_pay,
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            if($request['empid']!='')
            {
              
                $data = array( 
                  'salary'=>$request['salary'],
                  'encashment'=>$request['encash'],
                  'total_pay'=>$request['total_pay'],
                );
                $payrolltemp = CompanyPayrollTemp::where('employee_id',$request['empid'])->where('company_id',$request['companyId'])->where('month',$month)->where('year',$year)->update($data);
            }
           
            return response()->json($payrolltemp);
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }
    /**
    * Delete the applied leave
    * @method POST
    * @param leave id 
    * @return json
    */

    public  function deleteLeave(Request $request)
    {
      try{
        $leaveId = $request['leave_id']; 
        if($leaveId){
          $employeeLeave = EmployeeLeave::where('id',$leaveId)->first();
          $delete = EmployeeLeave::find($leaveId)->delete();
          if($employeeLeave)
          {
            $leavedate = explode('-', $employeeLeave['date']);
            $month = $leavedate[1];
            $year  = $leavedate[0];
            $where = array('employee_id'=>$employeeLeave['employee_id'],'month'=>$month,'year'=>$year);
            if($employeeLeave['leave_type'] == 1)
            {

              $balance = (($employeeLeave['day_type']==1)?1:(($employeeLeave['day_type']==2)?0.5:0));
              $data = array(
                        'balance'=>$balance,
                        'updated_by'=>Session::get('UserData')['SA_id'],
                        'updated_at'=>date('Y-m-d H:i:s')
                    );
              $leaveMaster = EmployeeLeaveMaster::where($where)->update($data);
            }
            elseif($employeeLeave['leave_type'] == 2)
            {
               $compoff = (($employeeLeave['day_type']==1)?1:(($employeeLeave['day_type']==2)?0.5:0));
               $compoffApply = EmployeeCompoffMaster::where($where)->first();
                if($compoffApply){
                    $compoffApply->available = $compoffApply->available+$compoff;
                    $compoffApply->updated_at = date('Y-m-d H:i:s');
                    $compoffApply->save();
                }
            }
            elseif($employeeLeave['leave_type'] == 3)
            {
               $lop = (($employeeLeave['day_type']==1)?1:(($employeeLeave['day_type']==2)?0.5:0));
               $lopApply = EmployeeLeaveMaster::where($where)->first();
                if($lopApply){
                    $lopApply->lop = $lopApply->lop-$lop;
                    $lopApply->updated_by = Session::get('UserData')['SA_id'];
                    $lopApply->updated_at = date('Y-m-d H:i:s');
                    $lopApply->save();
                }
            }

          }
          
        }
        
        if($delete){
          $response['status']  = true;
          $response['code']    = 1;
          $response['message'] = 'success';
          $response['result']  = true;
        }else{
          $response['status']  = false;
          $response['code']    = 1;
          $response['message'] = 'fail';
          $response['result']  = false;
        }
        
        // $response = $this->getReponse(TRUE, 1, $companies);
        return $response;
      }catch (\Exception $e) {echo $e->getMessage(); exit;
            $response = $this->getResponse(FALSE, 0, $e->getMessage());
            $this->errorLogCreate('AjaxController', 'getEmployees', 'error', 1, ['catch'=>$e->getMessage()]);
            return $response;
        }
    }
    /**
    * Deactivate Resource
    * @method POST
    * @param resource id 
    * @return json
    */
    public function DeactivateResource(Request $request)
    {
      try
      {
        $resourceId = $request['resourceId']; 
        $Resource = Employees::where('id',$resourceId)->update(['status'=>2]);
        Session::flash('success','Employee Deactivated Successfully');
        if($Resource){
          $response['status']  = true;
          $response['code']    = 1;
          $response['message'] = 'success';
          $response['result']  = true;
        }else{
          $response['status']  = false;
          $response['code']    = 1;
          $response['message'] = 'fail';
          $response['result']  = false;
        }
        
        return $response;
      }
      catch(\Exception $e)
      {echo $e->getMessage(); exit;
            $response = $this->getResponse(FALSE, 0, $e->getMessage());
            $this->errorLogCreate('AjaxController', 'DeactivateResource', 'error', 1, ['catch'=>$e->getMessage()]);
            return $response;
      }
    }
    /**
    * Calculate Company payroll
    * @param post
    * @return
    */
     public function calculateCompanyPayroll(Request $request){
      $companyId = $request->input('company_id');
      $monthInput = $request->input('month');
      $explode = explode('/',$monthInput);
      $month = $explode['0'];
      $year = $explode['1'];
      $salary = 0;
      $encash = 0;
     
      $payRoll = [];
      $companyModel = Company::find($companyId);
      
      if($companyModel){
        $companyName = $companyModel['name'];
        $payRoll['status'] = true;
        $payRoll['company_name'] = $companyModel->name;
        $payRoll['month'] = $month;
        $payRoll['year'] = $year;
       
        $compEmployees = $this->getCompanyEmployees($companyId);
        
            //dd($compEmployees);
        $empList = [];
        $forceGenerate = false;
        foreach ($compEmployees as $key => $employee) {
          $empBasicPay = $employee['basicpay'];
          $empPayType = $employee['payment'];


          $hourstype = 0;
          if(isset($employee['hourstype']) && !empty($employee['hourstype']))
          {
            $hourstype = $employee['hourstype'];
          }

          // calculate hrs from ehours table for particular month and year
          $ehoursDays = $this->getEmployeeEhrsDays($employee['id'],$month,$year,$hourstype);





          $workingDaysModel = WorkingDays::where('month',$month)->where('year',$year)->first();
          if($workingDaysModel){
            $totalWorkingDays = $workingDaysModel->days;
          }else{
            $totalWorkingDays = 21;
            // return $response = $this->getResponse(FALSE, 3, FALSE);
          }


          // Get leave taken from employee leave table except the Comp off

          $hourstype = 0;
            if(isset($employee['hourstype']) && !empty($employee['hourstype']))
            {
              $hourstype = $employee['hourstype'];
            }
           
          $inappWorkedDays = $this->getEmployeeInappWorkingDays($employee['id'],$month,$year,$totalWorkingDays,$hourstype);
          
          if($ehoursDays == $inappWorkedDays){
            $totalPay = $this->calculateTotalPay($employee['id'],$month,$year,$inappWorkedDays,$totalWorkingDays);
            $pay = json_decode($totalPay);
            $salary = $pay->basic;
            $encash = $pay->encash;
            $temp['emp_name'] = $employee['name'];
            $temp['employee_pay'] = $empBasicPay;
            $temp['payroll_status'] = 'Yes';
            $temp['worked_days'] = $inappWorkedDays;
            $temp['ehrs_days'] = $ehoursDays;
            $temp['encash'] = $encash;
            $temp['salary'] = $salary;
            $temp['total_salary'] = $salary + $encash;
            $temp['remark'] = '-';
            $temp['empid'] = $employee['id'];
          }else{
            $temp['emp_name'] = $employee['name'];
            $temp['employee_pay'] = $empBasicPay;
            $temp['payroll_status'] = 'No';
            $temp['worked_days'] = $inappWorkedDays;
            $temp['ehrs_days'] = $ehoursDays;
            $temp['salary'] = '-';
            $temp['encash'] = '-';
            $temp['total_salary'] = '-';
            $temp['remark'] = 'Please Correct the attendance';
            $temp['empid'] = $employee['id'];
            $forceGenerate = true;
          }
          array_push($empList, $temp);

          $companyPayTempModel = CompanyPayrollTemp::where('company_id',$companyId)->where('month',$month)->where('year',$year)->where('employee_id',$employee['id'])->first();
        if(!$companyPayTempModel){
          $insertCompanyPayTempModel = new CompanyPayrollTemp();
          $insertCompanyPayTempModel->company_id = $companyId;
          $insertCompanyPayTempModel->employee_id = $employee['id'];
          $insertCompanyPayTempModel->month = $month;
          $insertCompanyPayTempModel->year = $year;
          $insertCompanyPayTempModel->inapp_workingdays    = $inappWorkedDays;
          $insertCompanyPayTempModel->ehrs_days = $ehoursDays;
          $insertCompanyPayTempModel->basicpay = $empBasicPay;
          $insertCompanyPayTempModel->salary = $salary;
          $insertCompanyPayTempModel->encashment = $encash;
          $insertCompanyPayTempModel->total_pay = $salary + $encash;
          $insertCompanyPayTempModel->generated_by = Session::get('UserData')['SA_id'];
          $insertCompanyPayTempModel->save();
        }
       
        }
        $payRoll['user'] = Session::get('UserData')['role'];
        $payRoll['data'] = $empList;
        $payRoll['force_generate'] = $forceGenerate;
        if(isset($empList) && count($empList)<=0)
        {
          $payRoll['force_generate'] = 0;
        }
        
        $ispayrollgenerated=false;
        $invoicelink='#';
        $compPayroll = CompanyPayroll::where('company_id',$companyId)->where('month',$month)->where('year',$year)->first();
        if(isset($compPayroll))
        {
          $ispayrollgenerated = $compPayroll->iscompanypayrollgenerated;
          $invoicelink = $compPayroll->file_path;
        }//dd($compPayroll);
        //return json_encode($payRoll);
        //return view('payroll.company_payroll')->with(['payrolldetails'=>$payRoll['data'],'force_generate'=>$payRoll['force_generate'],'companies'=>$companies]);
        return view('payroll.company_table_details')->with(['payrolldetails'=>$payRoll,'force_generate'=>$payRoll['force_generate'],'ispayrollgenerated'=>$ispayrollgenerated,'invoicelink'=>$invoicelink]);
       // return $response = $this->getResponse(TRUE, 1, $payRoll);
        
      }else{
        return $response = $this->getResponse(FALSE, 2, FALSE);

     }

    }  


    

    



}
