<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class resources extends Controller
{
    public function index()
    {
    	return view('resources.manage');
    }

    public function AddNew()
    {
    	return view('resources.add');
    }
}
