<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Employees;
use App\Http\Models\EmployeeLeave;
use App\Http\Models\EmployeeLeaveMaster; 
use App\Http\Models\EmployeeCompoff;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Models\WorkingDays;
use Log;
use Validator;
use Session;
use Illuminate\Support\Facades\Input;


class EmployeeLeaveController extends Controller
{
    //


    /*
      FUNCTION NAME   : ResourceAddLeave
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/addleave
      IF NOTES        : add leave for employee
      WROTE BY        : Yuvaraj
    */
    public function ResourceAddLeave()
    {
      try
      {
        $employees = Employees::where('status',1)->get();
        return view('leave.addleave')->with(['employees'=>$employees]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : ApplyLeaveforResource
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employee_leave
      VIEW PAGE       : NULL
      IF NOTES        : add Leave for employee
      WROTE BY        : Yuvaraj
    */
    public function ApplyLeaveforResource(Request $request)
    {
      try
      {
        $rules  = array(
        				'employee' => 'required', 
        				'employee_leave_dates' => 'required',
        				'leave_type' => 'required',
        				'day_type' => 'required',
        			);
        $userdata = array(
                    'employee'      => $request->employee,
                    'employee_leave_dates'   => $request->employee_leave_dates,
                    'leave_type'   => $request->leave_type,
                    'day_type'   => $request->day_type,
                );
        $validator = Validator::make($userdata, $rules);

        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            $leave_applied = 0;
        	$dates = explode(',',$request['employee_leave_dates']);
            foreach ($dates as $value) 
            {
               $leave_applied =  $leave_applied + (($request['day_type']==1)?1:0.5);

               $month = date('m',strtotime($value));
               $year = date('Y',strtotime($value));

            }
            if($request['leave_type']==1)   //-- If CL Leave
            {
                $where = array('employee_id'=>$request['employee'],'month'=>$month,'year'=>$year);
                $ClLeave = EmployeeLeaveMaster::where($where)->select('balance')->first();
                if(isset($ClLeave) && !empty($ClLeave) && count($ClLeave)>0)
                {
                    $available_leave = $ClLeave->balance;
                }   
                else
                {
                    $available_leave = 0;
                }
                if($leave_applied <= $available_leave)
                {
                    foreach ($dates as $value) 
                    {           
                        $data = array(
                                'employee_id'=>$request['employee'],
                                'date'=>date('Y-m-d',strtotime($value)),
                                'leave_type'=>1,
                                'day_type'=>$request['day_type'],
                                'status'=>1,
                                'created_by'=>Session::get('UserData')['SA_id'],
                                'created_at'=>date('Y-m-d H:i:s')
                            );
                        EmployeeLeave::create($data);




                    }
                    /* UPDATING BALANCE CL ON MASTER LEAVE STARTS */
                    $balance = $available_leave - $leave_applied;
                    $data = array('balance'=>$balance);
                    EmployeeLeaveMaster::where($where)->update($data);
                    /* UPDATING BALANCE CL ON MASTER LEAVE  ENDS  */

                    Session::flash('success','Leave Applied successfully');
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                    
                }
                else if(isset($available_leave) && $available_leave>0)
                {
                    Session::flash('info',"Available CL Day(s): $available_leave");
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                }
                else
                {
                    Session::flash('error',"CL not available");
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                }
            }
            else if($request['leave_type']==2)            // if Comp off checking
            {
                $total_comp_available=0;
                $where = array('employee_id'=>$request['employee'],'month'=>$month,'year'=>$year);
                $CmOffLeave = EmployeeCompoffMaster::where($where)->first();
                if(isset($CmOffLeave) && !empty($CmOffLeave) && count($CmOffLeave)>0)
                {
                    $details = $CmOffLeave->toArray();  
                    $total_comp_available = $details['available'];
                }                
                if( $total_comp_available>0 &&  $leave_applied <= $total_comp_available)
                {
                    /* EMPLOYEE COMP-OFF MASTER STARTS */

                    $day_type = $request['day_type'];
                    
                    if(isset($CmOffLeave) && !empty($CmOffLeave) && count($CmOffLeave)>0)
                    {
                        $details = $CmOffLeave->toArray();  
                        $total_comp_off = $details['available'] - $leave_applied;
                        $update_data = array('available'=>$total_comp_off,'updated_at'=>date('Y-m-d H:i:s'));
                        $CmOffLeave = EmployeeCompoffMaster::where($where)->update($update_data);
                    }
                    else
                    {
                        $total_comp_off = (($day_type==1)?1:(($day_type==2)?0.5:0));
                        $insert_data = array('employee_id'=>$request['employee'],'available'=>$total_comp_off,'expired'=>0,'created_at'=>date('Y-m-d H:i:s'));
                        $CmOffLeave = EmployeeCompoffMaster::insert($insert_data);
                    }

                    /* EMPLOYEE COMP-OFF MASTER  ENDS  */

                    $where = array('employee_id'=>$request['employee'],'status'=>1);
                    $CmOffLeave = EmployeeCompoff::where($where)->get();
                    foreach($dates as $value) 
                    {
                        $data = array(
                                'employee_id'=>$request['employee'],
                                'date'=>date('Y-m-d',strtotime($value)),
                                'leave_type'=>2,
                                'day_type'=>$request['day_type'],
                                'status'=>1,
                                'created_by'=>Session::get('UserData')['SA_id'],
                                'created_at'=>date('Y-m-d H:i:s')
                            );
                        EmployeeLeave::create($data);
                    }

                    /* UPDATING COMP OFF LEAVE STARTS */
                    foreach ($CmOffLeave as $value) 
                    {
                        if($leave_applied>0 && $leave_applied>0.5)
                        {
                            $leave_less = 1;
                        }
                        else if($leave_applied>0 && $leave_applied==0.5)
                        {
                            $leave_less = 0.5;
                        }
                        else if($leave_applied==0)
                        {
                            break;
                        }
                        $leave_applied = $leave_applied - $leave_less;
                        $where = array('id'=>$value->id);
                        if($leave_less==1)
                        {
                            $data = array('status'=>0);
                        }
                        else
                        {
                            if($value->day_type==2)
                            {
                                $data = array('status'=>0);
                            }
                            else
                            {
                                $data = array('day_type'=>2);     
                            }                            
                        }
                        EmployeeCompoff::where($where)->update($data);
                   }
                   /* UPDATING COMP OFF LEAVE  ENDS  */
                    Session::flash('success','Comp off Leave Applied successfully');
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                }
                else if(isset($total_comp_available) && $total_comp_available>0)
                {
                    Session::flash('info',"Available Comp Leave Day(s): $total_comp_available");
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                }
                else
                {
                    Session::flash('error',"Available Comp Leave not available");
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }
                }
            }else{
                $where = array('employee_id'=>$request['employee'],'month'=>$month,'year'=>$year);
                $lop = 0;
                foreach($dates as $value) 
                {

                    $data = array(
                            'employee_id'=>$request['employee'],
                            'date'=>date('Y-m-d',strtotime($value)),
                            'leave_type'=>3,
                            'day_type'=>$request['day_type'],
                            'status'=>1,
                            'created_by'=>Session::get('UserData')['SA_id'],
                            'created_at'=>date('Y-m-d H:i:s')
                        );
                    EmployeeLeave::create($data);

                    if($request['day_type'] == '1'){
                        $lop++;
                    }else{
                        $lop = $lop + 0.5;
                    }
                }
                
                $lopApply = EmployeeLeaveMaster::where($where)->first();
                if($lopApply){
                    $lopApply->lop = $lopApply->lop+$lop;
                    $lopApply->save();
                }else{
                    $model = new EmployeeLeaveMaster();
                    $model->employee_id = $request['employee'];
                    $model->month = $month;
                    $model->year = $year;
                    $model->no_of_cl = 0;
                    $model->balance = 0;
                    $model->lop = $lop;
                    $model->created_by = Session::get('UserData')['SA_id'];
                    $model->save();
                }
                

                Session::flash('success','Leave Applied successfully');
                    if(!isset($request['ispayroll']))
                    {
                        return redirect()->route('admin/resource_add_leave');
                    }


            }
        }
      }
      catch(\Exception $e)
      {
       // \Log::error($e);
        dd($e);
      }
    }



    /*
      FUNCTION NAME   : AddWorkingDays
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : working_days
      VIEW PAGE       : leave/add_workingdays
      IF NOTES        : add working Day
      WROTE BY        : Yuvaraj
    */
    public function AddWorkingDays()
    {
      try
      {
        $month = date('M');
        $year = date('Y');
        $where = array('month'=>date('m'),'year'=>date('Y'));
        $days = WorkingDays::where($where)->first();
        if(isset($days) && !empty($days) && count($days)>0)
        {
            $work_day = $days['days'];
        }
        else
        {
            $work_day = '';
        }
        //print_r($work_day);exit;
        return view('leave.add_workingdays')->with(['month'=>$month,'year'=>$year,'work_day'=>$work_day]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


    /*
      FUNCTION NAME   : InsertWorkingDays
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : working_days
      VIEW PAGE       : leave/add_workingdays
      IF NOTES        : add working Day
      WROTE BY        : Yuvaraj
    */
    public function InsertWorkingDays()
    {
      try
      {
        $rules  = array('working_days' => 'required');
        $userdata = array('working_days' => Input::get('working_days'));
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            $where = array('month'=>date('m'),'year'=>date('Y'));
            $days = WorkingDays::where($where)->first();
            if(isset($days) && !empty($days) && count($days)>0)
            {
                $update_data = array('days'=>Input::get('working_days'),
                                'updated_by'=>Session::get('UserData')['SA_id'],
                                'updated_at'=>date('Y-m-d H:i:s')
                                );
                WorkingDays::where($where)->update($update_data);
                Session::flash('success','Working Day(s) updated successfully');
                return redirect()->route('admin/add_working_days');
            }
            else
            {
                $insert_data = array(
                                'month'=>date('m'),
                                'year'=>date('Y'),
                                'days'=>Input::get('working_days'),
                                'created_by'=>Session::get('UserData')['SA_id'],
                                'created_at'=>date('Y-m-d H:i:s')
                            );
                WorkingDays::insert($insert_data);
                Session::flash('success','Working Day(s) added successfully');
                return redirect()->route('admin/add_working_days');
            }
            print_r($days);
            exit;
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }



}
