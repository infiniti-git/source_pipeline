<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Employees;
use App\Http\Models\WorkingDays;
use App\Http\Models\Ehours;
use App\Http\Models\Payroll;
use App\Http\Models\EmployeeLeaveMaster;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Models\EmployeeLeave;
use App\Http\Models\LoyaltyBonus;
use App\Http\Models\Month;
use App\Http\Models\LeaveEncash;
use Log;
use Session;
use Helpers;
use Auth;
use App\Http\Models\Company;
use App\Http\Controllers\Traits\ApiTrait;
use App\Http\Models\CompanyPayroll;
use App\Http\Models\CompanyPayrollTemp;

class PayrollController extends Controller
{
    use ApiTrait;
    /*
      FUNCTION NAME   : index
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : payroll/payroll
      IF NOTES        : show the payroll page
      WROTE BY        : Yuvaraj
    */
    public function index()
    {
      try
      {
    	   $employees = Employees::where('status',1)->where('resource',2)->get();
         return view('payroll.payroll')->with(['employees'=>$employees]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : generatepayroll
      
      ARGUMENTS       : NULL
            
      ARGUMENTS NOTES : NULL
            
      TABLE(DB)       : ehours,employee,employee_leave_master,employee_compoff_master
            
      VIEW PAGE       : null
            
      WROTE BY        : Jenifer
    */
    public function GeneratePayroll($empid,$noofWD,$noofehourdays,$month,$year)
    {
      try
      {
         $employee = Employees::GetActiveEmployeeDetailsById($empid);
          $payrollmonth = date_parse($month);
          $workingdays = WorkingDays::where('month',$payrollmonth['month'])->where('year',$year)->select('month','year','days')->first();
        /* Calculate encash leave*/
        $totalworkingday = $noofehourdays;
        $available_leave = 0;
        $available_compoffleave = 0;
        $encashleave = 0;
        $encashamount = 0;
        $leavetaken = 0;

        $employeeleaves = EmployeeLeave::GetEmployeeLeaveDetailsForMonth($payrollmonth['month'],$year,$empid);     
        if(isset($employeeleaves) && count($employeeleaves)>0)
        {
              foreach ($employeeleaves as $employeeleave) 
              {
                if($employeeleave->day_type == 1)
                {
                  $leavetaken = $leavetaken + 1;
                }
                elseif ($employeeleave->day_type == 2) {
                  $leavetaken = $leavetaken + 0.5;
                }
              }
        }
        //Encash table
        $leaveencashcheck = LeaveEncash::where('month',$payrollmonth['month'])->where('year',$year)->where('employee_id',$empid)->first();
        if(isset($leaveencashcheck) && !empty($leaveencashcheck))
        {
          if($leaveencashcheck['cl_leave'] && $employee->payment_type != '4' && $employee->payment_type != '1')
            {
              $available_leave = $leaveencashcheck['cl_leave'];
            }
            if($leaveencashcheck['cl_leave'] == 0 && $employee->payment_type != '4' && $employee->payment_type != '1')
            {
              $totalworkingday = $totalworkingday + $leaveencashcheck['no_of_cl'];
            }
            if($leaveencashcheck['compoff_leave'])
            {
                $available_compoffleave = $leaveencashcheck['compoff_leave'];
            } 
        }
        
        $encashleave = $available_leave + $available_compoffleave;
        /* Calculate encash leave end*/

         /*Checking compoff workingday */
          if($available_compoffleave > 0)
          {
            $totalworkingday = $totalworkingday - $available_compoffleave;
          }
          /*Checking compoff workingday end */
        
         /* Calculate basic salary and encash amount */
        if(isset($employee))
        {
          $basicpay=0;
          /* Payment Type Hourly*/
         if($employee->payment_type == '1')
         {
            $ehours = Ehours::getEmployeeeHourforMonth($payrollmonth['month'],$year,$empid);
            $tothours = 0;
            if(isset($ehours) && count($ehours)>0)
            {
                foreach ($ehours as $ehour) 
                {
                    $emphour = $ehour->hrs;
                    $tothours = $tothours + $emphour;
                }
            }
            $basicpay = $tothours  * $employee->basicpay;
            if($encashleave >  0)
            {
              //$salaryperday = $employee->basicpay/$totalworkingday;
              //$encashamount = 8 * $encashleave;
            }
          }
           /* Payment Type Daily*/
          elseif($employee->payment_type == '2')
         {
          $basicpay = $totalworkingday*$employee->basicpay;
          if($encashleave >  0)
          {
            $encashamount = $employee->basicpay * $encashleave;
          }
         }
          /* Payment Type Monthly FullTime*/
         elseif($employee->payment_type == '3')
         {
            $basicpay = ($totalworkingday/$workingdays['days'])*$employee->basicpay;
            if($encashleave >  0)
            {
              $salaryperday = $employee->basicpay/$workingdays['days'];
              $encashamount = ($employee->basicpay/21) * $encashleave;
            }
         }
         /* Payment Type Monthly Premium*/
         elseif($employee->payment_type == '4')
         {
            $basicpay = ($totalworkingday/$workingdays['days'])*$employee->basicpay;
            if($encashleave >  0)
            {
              $salaryperday = $employee->basicpay/$workingdays['days'];
              $encashamount = ($employee->basicpay/21) * $encashleave;
            }
         }
         /* Payment Type Monthly Parttime*/
         elseif($employee->payment_type == '5')
         {
            $basicpay = ($totalworkingday/$workingdays['days'])*$employee->basicpay;
            if($encashleave >  0)
            {
              $salaryperday = $employee->basicpay/$workingdays['days'];
              $encashamount = ($employee->basicpay/21) * $encashleave;
            }
         }
        /* Calculate basic salary and encash amount End*/

        /* Calculate loyalty bonus*/
        $isloyaltybonus = 2;
        $loyaltybonusamount = 0;
        if(isset($employee->isloyaltybonus) && $employee->isloyaltybonus == 1)
        {
          $loyaltybonus = LoyaltyBonus::GetLoyaltyBonusofMonth($empid,$payrollmonth['month'],$year);
          if(isset($loyaltybonus))
          {
            if($loyaltybonus->loyaltybonusamount != null)
            {
              $loyaltybonusamount = $loyaltybonus->loyaltybonusamount;
              $isloyaltybonus = 1;
            }
          }
        }

        /* Calculate loyalty bonus End*/

        $totalpay = $basicpay + $encashamount;
        
         $payrollarray = array(
                            'empid'=>$empid,
                            'name'=>$employee->name,
                            'month'=>$month,
                            'monthid'=>$payrollmonth['month'],
                            'year'=>$year,
                            'numberofWD'=>$workingdays['days'],
                            'numberofsourceWD'=> $noofWD,
                            'noofehourdays'=>$noofehourdays,
                            'basicsalary'=> $basicpay,
                            'loyaltybonus'=> $loyaltybonusamount,
                            'isloyaltybonus'=>$isloyaltybonus,
                            'reimbursment'=> null,
                            'leaveencashamount'=>$encashamount,
                            'totalpay'=>$totalpay,
                            'availablecl'=>$available_leave,
                            'availablecompoff'=>$available_compoffleave,
                            'leavetaken'=>$leavetaken,
                            'incentiveamount'=>null,
                          );
         $payroll = json_decode(json_encode($payrollarray));
         //print_r($payroll);exit; 
        }
        else
        {
          $payroll = array();
        }
         return view('payroll.generatepayroll')->with(['payroll'=>$payroll]);
        
      }
      catch(\Exception $e)
      {
        //dd($e);exit;
        \Log::error($e);
      }
    }

    public function GenerateDirectPayrollPDF(Request $request)
    {
      try
      {
            $payrollexists = Payroll::where('month',$request['month'])->where('year',$request['year'])->where('employee',$request['empid'])->first();
            
            if(isset($payrollexists) && count($payrollexists)>0)
            {
              $payrollId = $payrollexists->id; 
              if($payrollId){
                $delete = Payroll::find($payrollId)->delete();
              }
            }

            $data = array(
                    'employee'=>$request['empid'],
                    'month'=>$request['month'],
                    'year'=>$request['year'],
                    'basicpay'=>str_replace(",", "", $request['payroll_basicsalary']),
                    'reimbursment'=>str_replace(",", "",$request['payroll_reimbursment']),
                    'isloyaltyapplicable'=>$request['loyaltyyesno'],
                    'loyaltybonus'=>str_replace(",", "",$request['payroll_loyaltybonus']),
                    'totalpay'=>str_replace(",", "",$request['payroll_totalpay']),
                    'workingday'=>$request['payroll_WDmonth'],
                    'source_workingday'=>$request['payroll_sourceWD'],
                    'leaveencashamount'=>str_replace(",", "",$request['payroll_leaveencash']),
                    'leavetaken'=>$request['leavetaken'],
                    'ispayrollgenerated'=>true,
                    'incentiveamount'=>str_replace(",", "",$request['payroll_incentive']),
                    'created_by'=>Session::get('UserData')['SA_id'],
                    'created_at'=>date('Y-m-d H:i:s')
                );
            $generatepayroll = Payroll::create($data);
            $payroll =  Payroll::GetPayroll($request['empid'],$request['month'],$request['year'])->toArray();
            $paydata['payrollreport'] = $payroll;
            $pdf = \PDF::loadView('payroll.directpayrollpdf',$paydata);
            $filename = $request['payroll_empname'].'_invoice_'.$request['month'].''.$request['year'].'.pdf';
            $path = 'payroll/direct/'.$filename;
            $pdf->save(public_path($path));
            if(isset($generatepayroll))
            {
              $payrolldata = array(
                            'invoicelink' => $path
                            );
              $invoicelink = Payroll::where('id',$generatepayroll['id'])->update($payrolldata);
            }
          return $pdf->download($filename);
       
      //return view('payroll.directpayrollpdf')->with(['payrollreport'=>$payrollreport]);
      }
      catch(\Exception $e)
      {
        \Log::error($e);
        dd($e);
      }
    }


     /**
    * Company Payroll
    * developed by Kalidass
    * @param
    * @return view
    */

    public function companyPayroll()
    {
      try
      {
         $force_generate = null;
         $companies = Company::where('status',1)->get();
         $userrole = Session::get('UserData')['role'];
         return view('payroll.company_payroll')->with(['companies'=>$companies,'force_generate'=>$force_generate,'userrole'=>$userrole]);

      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


    public  function forceGenerateCompanyPayroll(Request $request)
    {
      $companyId = $request->input('company_id');
      $monthInput = $request->input('month');
      $explode = explode('/',$monthInput);
      $month = $explode['0'];
      $year = $explode['1'];
     
      $payRoll = [];
      $companyModel = Company::find($companyId);

      if($companyModel){
        $companyName = $companyModel['name'];
        $payRoll['status'] = true;
        $payRoll['company_name'] = $companyModel->name;
        $payRoll['month'] = $month;
        $payRoll['year'] = $year;
       
        $compEmployees = CompanyPayrollTemp::where('company_id',$companyId)->where('month',$month)->where('year',$year)->get()->toArray();
        
        $empList = [];
        $forceGenerate = false;
        foreach ($compEmployees as $key => $employee) {
            $salary = $employee['salary'];
            $encash = $employee['encashment'];
            $employeename = Employees::where('id',$employee['employee_id'])->first();
            if($employee['ehrs_days'] == $employee['inapp_workingdays']){
            $temp['emp_name'] = $employeename->name;
            $temp['employee_pay'] = $employee['basicpay'];
            $temp['payroll_status'] = 'Yes';
            $temp['worked_days'] = $employee['inapp_workingdays'];
            $temp['ehrs_days'] = $employee['ehrs_days'];
            $temp['encash'] = $encash;
            $temp['salary'] = $salary;
            $temp['total_salary'] = $salary + $encash;
            $temp['remark'] = '-';
          }else{
            $temp['emp_name'] = $employeename->name;
            $temp['employee_pay'] = $employee['basicpay'];
            $temp['payroll_status'] = 'No';
            $temp['worked_days'] = $employee['inapp_workingdays'];
            $temp['ehrs_days'] = $employee['ehrs_days'];
            $temp['encash'] = '-';
            $temp['salary'] = '-';
            $temp['total_salary'] = '-';
            $forceGenerate = true;
            $temp['remark'] = 'Please Correct the attendance';
            
            
          }
          array_push($empList, $temp);
       
        }

        
       
        $payRoll['emp_list'] = $empList;
        $payRoll['force_generate']= $forceGenerate;
        $pdf = \PDF::loadView('payroll.company_payroll_pdf', $payRoll);
        $pdf->save(storage_path().'_filename.pdf');
      // Finally, you can download the file using download function
      return $pdf->download('download_company_payroll');
        // return $response = $this->getResponse(TRUE, 1, $payRoll);
        
      }else{
        return $response = $this->getResponse(FALSE, 2, FALSE);

      }

      


    }

    public  function generateCompanyPayroll(Request $request)
    {
      $companyId = $request->input('company');
      $monthInput = $request->input('month');
      $explode = explode('/',$monthInput);
      $month = $explode['0'];
      $year = $explode['1'];
     
      $payRoll = [];
      $companyModel = Company::find($companyId);

      if($companyModel){
        $companyName = $companyModel['name'];
        $payRoll['status'] = true;
        $payRoll['company_name'] = $companyModel->name;
        $payRoll['month'] = $month;
        $payRoll['year'] = $year; 
        $payrollexists = CompanyPayroll::where('company_id',$companyId)->where('month',$month)->where('year',$year)->get()->toArray();
            if(isset($payrollexists) && count($payrollexists)>0)
            {
               $ids_to_delete = array_map(function($item){ return $item['id']; }, $payrollexists);
              if($ids_to_delete){
                $delete = CompanyPayroll::whereIn('id', $ids_to_delete)->delete();
              }
            }

        $compEmployees = CompanyPayrollTemp::where('company_id',$companyId)->where('month',$month)->where('year',$year)->get()->toArray();
        
        $empList = [];
        $forceGenerate = false;
        if(isset($compEmployees))
        {
          foreach ($compEmployees as $key => $employee) {
            $salary = $employee['salary'];
            $encash = $employee['encashment'];
            $employeename = Employees::where('id',$employee['employee_id'])->first();
            $temp['emp_name'] = $employeename->name;
            $temp['employee_pay'] = $employee['basicpay'];
            $temp['payroll_status'] = 'Yes';
            $temp['worked_days'] = $employee['inapp_workingdays'];
            $temp['ehrs_days'] = $employee['ehrs_days'];
            $temp['encash'] = $encash;
            $temp['salary'] = $salary;
            $temp['total_salary'] = $salary + $encash;
            $temp['remark'] = '-';

            //$companyPayModel = CompanyPayroll::where('company_id',$companyId)->where('month',$month)->where('year',$year)->first();
            //if(!$companyPayModel){
              $insertCompanyPayModel = new CompanyPayroll();
              $insertCompanyPayModel->company_id = $companyId;
              $insertCompanyPayModel->employee_id = $employee['employee_id'];
              $insertCompanyPayModel->month = $month;
              $insertCompanyPayModel->year = $year;
              $insertCompanyPayModel->inapp_workingdays    = $employee['inapp_workingdays'];
              $insertCompanyPayModel->ehrs_days = $employee['ehrs_days'];
              $insertCompanyPayModel->basicpay = $employee['basicpay'];
              $insertCompanyPayModel->salary = $salary;
              $insertCompanyPayModel->encashment = $encash;
              $insertCompanyPayModel->total_pay = $salary + $encash;
              $insertCompanyPayModel->generated_by = Session::get('UserData')['SA_id'];
              $insertCompanyPayModel->iscompanypayrollgenerated = true;
              $insertCompanyPayModel->save();
            //}
            array_push($empList, $temp);
        }
       }
        else{
           return $response = $this->getResponse(FALSE, 0, FALSE);
          }

            if(isset($compEmployees) && count($compEmployees)>0)
            {
               $ids_to_delete = array_map(function($item){ return $item['id']; }, $compEmployees);
              if($ids_to_delete){
                $delete = CompanyPayrollTemp::whereIn('id', $ids_to_delete)->delete();
              }
            }
        
        $payRoll['emp_list'] = $empList;
        $payRoll['force_generate']= $forceGenerate;
        $pdf = \PDF::loadView('payroll.company_payroll_pdf', $payRoll);
        $fileName = $companyName.'_'.$month.'_'.$year.'.pdf';
        $path = 'payroll/company/'.$fileName;
        $file = public_path($path);
        $pdf->save($file);
          
              $data = array(
                            'file_path' => $path
                            );
              $invoicelink = CompanyPayroll::where('company_id',$companyId)->where('month',$month)->where('year',$year)->update($data);
        return $response = $this->getResponse(TRUE, 1, TRUE);
      }else{
        return $response = $this->getResponse(FALSE, 2, FALSE);

      }
    }
   /* public  function generateCompanyPayroll1(Request $request)
    {
      $companyId = $request->input('company');
      $monthInput = $request->input('month');
      $explode = explode('/',$monthInput);
      $month = $explode['0'];
      $year = $explode['1'];
     
      $payRoll = [];
      $companyModel = Company::find($companyId);

      if($companyModel){
        $companyName = $companyModel['name'];
        $payRoll['status'] = true;
        $payRoll['company_name'] = $companyModel->name;
        $payRoll['month'] = $month;
        $payRoll['year'] = $year;
       
        $compEmployees = $this->getCompanyEmployees($companyId);
        
        $empList = [];
        $forceGenerate = false;
        foreach ($compEmployees as $key => $employee) {
          $empBasicPay = $employee['basicpay'];
          $empPayType = $employee['payment'];

          $hourstype = 0;
          if(isset($employee['hourstype']) && !empty($employee['hourstype']))
          {
            $hourstype = $employee['hourstype'];
          }

          // calculate hrs from ehours table for particular month and year
          $ehoursDays = $this->getEmployeeEhrsDays($employee['id'],$month,$year,$hourstype);

          $workingDaysModel = WorkingDays::where('month',$month)->where('year',$year)->first();
          if($workingDaysModel){
            $totalWorkingDays = $workingDaysModel->days;
          }else{
            $totalWorkingDays = 21;
          }
          $hourstype = 0;
            if(isset($employee['hourstype']) && !empty($employee['hourstype']))
            {
              $hourstype = $employee['hourstype'];
            }
          $inappWorkedDays = $this->getEmployeeInappWorkingDays($employee['id'],$month,$year,$totalWorkingDays,$hourstype);
          // Get leave taken from employee leave table except the Comp off

          
          if($ehoursDays == $inappWorkedDays){

            $totalPay = $this->calculateTotalPay($employee['id'],$month,$year,$inappWorkedDays,$totalWorkingDays);
            $pay = json_decode($totalPay);
            $salary = $pay->basic;
            $encash = $pay->encash;
            
            $temp['emp_name'] = $employee['name'];
            $temp['employee_pay'] = $empBasicPay;
            $temp['payroll_status'] = 'Yes';
            $temp['worked_days'] = $inappWorkedDays;
            $temp['ehrs_days'] = $ehoursDays;
            $temp['encash'] = $encash;
            $temp['salary'] = $salary;
            $temp['total_salary'] = $salary + $encash;
            $temp['remark'] = '-';

            $companyPayModel = CompanyPayroll::where('company_id',$companyId)->where('month',$month)->where('year',$year)->first();
            if(!$companyPayModel){
              $insertCompanyPayModel = new CompanyPayroll();
              $insertCompanyPayModel->company_id = $companyId;
              $insertCompanyPayModel->employee_id = $employee['id'];
              $insertCompanyPayModel->month = $month;
              $insertCompanyPayModel->year = $year;
              $insertCompanyPayModel->inapp_workingdays    = $inappWorkedDays;
              $insertCompanyPayModel->ehrs_days = $ehoursDays;
              $insertCompanyPayModel->basicpay = $empBasicPay;
              $insertCompanyPayModel->salary = $salary;
              $insertCompanyPayModel->encash = $encash;
              $insertCompanyPayModel->total_pay = $salary + $encash;
              $insertCompanyPayModel->generated_by = Session::get('UserData')['SA_id'];
              $insertCompanyPayModel->save();
            }

            
          }else{
           
           return $response = $this->getResponse(FALSE, 0, FALSE);
            
            
          }
          array_push($empList, $temp);
       
        }

        
       
        $payRoll['emp_list'] = $empList;
        $payRoll['force_generate']= $forceGenerate;
        $pdf = \PDF::loadView('payroll.company_payroll_pdf', $payRoll);
        $fileName = $companyName.'_'.$month.'_'.$year.'.pdf';
        $path = 'payroll/company/'.$fileName;
        $file = public_path($path);
        $pdf->save($file);
        
        return $response = $this->getResponse(TRUE, 1, TRUE);
      }else{
        return $response = $this->getResponse(FALSE, 2, FALSE);

      }
    }*/


    public  function downloadCompanyPayroll(Request $request)
    {
      $companyId = $request->input('company');
      $monthInput = $request->input('month');
      $explode = explode('/',$monthInput);
      $month = $explode['0'];
      $year = $explode['1'];

      $company = Company::find($companyId);
      $companyName = $company['name'];

      $fileName = $companyName.'_'.$month.'_'.$year.'.pdf';
      $path = 'payroll/company/'.$fileName;

      $filepath = public_path($path);
      // Process download
      if(file_exists($filepath)) {
          header('Content-Description: File Transfer');
          header('Content-Type: application/octet-stream');
          header('Content-Disposition: attachment; filename="'.basename($fileName).'"');
          header('Expires: 0');
          header('Cache-Control: must-revalidate');
          header('Pragma: public');
          header('Content-Length: ' . filesize($filepath));
          flush(); // Flush system output buffer
          readfile($filepath);
          exit;
      }
    }
    

}
