<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Users;
use DB;
use Session;
use Validator;
use Auth;
use Log;

class LoginController extends Controller
{

	/*
      FUNCTION NAME   : index
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      MODEL           : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : views/login/login
      IF NOTES        : To Show Login page.
      WROTE BY        : Yuvaraj
    */
    public function index()
    {
      try
      {
    	   return view('login.login');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


    /*
      FUNCTION NAME   : LoginVerify
      ARGUMENTS       : request
      ARGUMENTS NOTES : request - form inputs
      TABLE(DB)       : users
      VIEW PAGE       : NULL
      IF NOTES        : Verify login credentials.
      WROTE BY        : Yuvaraj
    */
    public function LoginVerify(Request $request)
    {
      try
      {
      	Session::put('userdata','');
      	$rules     = array('email' => 'required', 'password' => 'required');
      	$userdata = array(
  		            'email'      => $request->email,
  		            'password'   => $request->password,
  		        );
  	    $validator = Validator::make($userdata, $rules);
  	    if ($validator->fails()) 
  	    {
  	      	return redirect()->back()->withErrors($validator);
  	    } 
  	    else 
  	    {
          //if(Auth::attempt($userdata))
          //{
            //dd($userdata);
            $email = $request['email'];
            $password = $request['password'];
            $where_user = array('email'=>$email,'password'=>md5($password),'status'=>1);
                  $result = Users::where($where_user)->first();
            if(!isset($result) && empty($result) && count($result)==0)
            {
              Session::flash('error','Please check your credentials');
              return redirect()->route('login');
            }
            elseif(isset($result) && !empty($result) && count($result)>0)
            {
              $result = json_decode(json_encode($result),true);
              $UserData = array('email'=>$result['email'],'role'=>$result['role'],'SA_id'=>$result['id']);
              Session::put('UserData',$UserData);

              return redirect()->route('admin/dashboard');
            }
          //}
          //else
          //{
          //  return redirect()->route('login');
         // }
  	    	
  	    }
      }
      catch(\Exception $e)
      {
        //\Log::error($e);
        dd($e);
      }
    }

    /*
      FUNCTION NAME   : Logout
      ARGUMENTS       : request
      ARGUMENTS NOTES : request - form inputs
      TABLE(DB)       : NULL
      VIEW PAGE       : NULL
      IF NOTES        : Destroy all sessions.
      WROTE BY        : Yuvaraj
    */
    public function Logout(Request $request) 
    {
      try
      {
    	  Session::flush();
        Auth::logout();
    	  return redirect()->route('login');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
	  }
}
