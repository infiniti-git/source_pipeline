<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Questions;
use App\Models\JobsQuestionsMapping;
use Carbon\Carbon;
use App\Models\Jobs;
use App\Http\Requests\JobRequest;
class QuestionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //return view('rmsdashboard',['jobs'=>$jobs]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //eturn view('jobs.create',['standard_questions'=>$standard_questions]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(JobRequest $request)
    {
        //
    }

    public function storequestions(Request $request){
        $questions = $request->input('questions',[]);
        $response = [];
        if(count($questions) > 0){
            try{
                $stored_questions = [];
                foreach($questions as $each_question){
                    $ques = new Questions;
                    $ques->question_title = $each_question['question_title'];
                    $ques->question = $each_question['question'];
                    $ques->created_by = 1;
                    $ques->created_at = \Carbon::now();
                    $ques->save();

                    $stored_questions[] = ["question_id"=>$ques->id,"question"=>$each_question['question']];
                }
                $response['status'] = "success";
                $response['message'] = "Questions saved successfully!";    
                $response['questions'] = $stored_questions;
            }catch(\Exception $e){
                $response['status'] = "fail";
                $response['message'] = $e->getMessage();    
            }
        }else{
            $response['status'] = "fail";
            $response['message'] = "Please enter questions.";
        }
        return response()->json($response);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
