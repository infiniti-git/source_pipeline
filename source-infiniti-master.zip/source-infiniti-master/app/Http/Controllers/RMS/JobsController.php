<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Questions;
use App\Models\JobsQuestionsMapping;
use Carbon\Carbon;
use App\Models\Jobs;
use App\Models\JobApplication;
use App\Models\JobsQuestionsAnswers;
use App\Models\JobApplicationStatus;
use App\Http\Requests\JobRequest;
use App\Http\Requests\ApplicationRequest;
use Illuminate\Support\Facades\Storage;
use File;

class JobsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jobs = Jobs::orderBy('id','desc')->paginate(\Config::get('constants.DEFAULT_PAGINATION'));
        return view('RMS.rmsdashboard',['jobs'=>$jobs]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $standard_questions = Questions::all();
        return view('RMS.jobs.create',['standard_questions'=>$standard_questions]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(JobRequest $request)
    {
        try{
            $job = new Jobs();
            $next_job_id = $job->getNextJobReference();
            $job->job_reference = $next_job_id;
            $job->job_title = $request->input('job_title');
            $job->description = $request->input('job_description');
            $job->created_by = 1;
            $job->created_at = \Carbon::now();
            $job->save();

            if($request->input('standard_questions') && is_array($request->input('standard_questions')) && count($request->input('standard_questions')) > 0){
                $str_ques = [];
                JobsQuestionsMapping::where('jobs_id',$job->id)->delete();
                foreach ($request->input('standard_questions') as $each_question) {
                    $str_ques[$each_question] = ["created_by"=>1,"created_at"=>\Carbon::now()];
                }
                $job->questions()->sync($str_ques);
            }
            session()->flash('success', 'Job Post was created!');
        }catch(\Exception $e){
            session()->flash('error', $e->getMessage());
        }
        return redirect()->route('job.home');
    }

    public function jobDashboard($jobid, $filter_status=''){
        if($jobid > 0){
            $job = Jobs::find($jobid);
            $applications = JobApplication::where('jobs_id',$jobid)->orderBy('id','desc');
            if($filter_status != ''){
                $applications->where('application_status',$filter_status);
            }
            $applications = $applications->paginate(\Config::get('constants.DEFAULT_PAGINATION'));
            $status_array = JobApplicationStatus::pluck('status','id')->toArray();
            if($job){
                return view('RMS.jobs.jobdashboard',['job'=>$job,
                                                'applications'=>$applications,
                                                'status_array'=>$status_array]);
            }else{
                return view('RMS.error.invalid');
            }
        }else{
            return view('RMS.error.invalid');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, $d = 'N')
    {
        if($id){
            $job = Jobs::where('job_reference',$id)->first();
            if($job){
                return view('RMS.jobs.jobpost',['job'=>$job,'done'=>$d]);
            }else{
                return view('RMS.error.invalid');
            }
        }else{
            return view('RMS.error.invalid');
        }
    }

    public function apply($job_id){
        if($job_id){
            $job = Jobs::where('job_reference',$job_id)->first();
            if($job){
                $standard_questions = $job->questions;
                return view('RMS.jobs.application',['job'=>$job,
                                                'standard_questions'=>$standard_questions]);
            }else{
                return view('RMS.error.invalid');
            }
        }else{
            return view('RMS.error.invalid');
        }
    }

    public function submitapplication(ApplicationRequest $request){
        $job_id = $request->input('job_reference');
        if($job_id){
            try{
                $job = Jobs::where('job_reference',$job_id)->first();
                
                $job_application = new JobApplication;
                $job_application->jobs_id = $job->id;
                $job_application->applicant_name = $request->input('candidate_name');
                $job_application->location = $request->input('candidate_location');
                $job_application->application_status = 1;
                $job_application->created_by = 2;
                $job_application->save();
                if($request->hasFile('candidate_resume')){
                    $resume = $request->file('candidate_resume');    

                    $main_dir_path = 'application_path'.DIRECTORY_SEPARATOR;
                    $job_dir_path = $main_dir_path.$job->id.DIRECTORY_SEPARATOR;
                    $app_dir_path = $job_dir_path.$job_application->id.DIRECTORY_SEPARATOR;
                    if(!File::exists($main_dir_path)) {
                        File::makeDirectory($main_dir_path, 0777, true, true);
                    }
                    if(!File::exists($job_dir_path)) {
                        File::makeDirectory($job_dir_path, 0777, true, true);
                    }
                    if(!File::exists($app_dir_path)) {
                        File::makeDirectory($app_dir_path, 0777, true, true);
                    }

                    $file_path = $app_dir_path;
                    if($resume->store($file_path)){
                        $job_application->resume_original_file_name = $resume->getClientOriginalName();
                        $job_application->resume_file_name = $resume->hashName();
                        $job_application->save();
                    }
                }


                $answers = $request->input('standard_question_answers',[]);
                if(count($answers) > 0){
                    foreach ($answers as $qid => $ans) {
                        $answer = new JobsQuestionsAnswers;
                        $answer->jobs_id = $job->id;
                        $answer->application_id = $job_application->id;
                        $answer->questions_id = $qid;
                        $answer->answer = $ans;
                        $answer->created_by = 1;
                        $answer->created_at = \Carbon::now();
                        $answer->save();
                    }
                }
                session()->flash('success', 'Your application is submitted successfully!');
                return redirect()->route('job.show',['job_reference'=>$job->job_reference,'d'=>'Y']);
            }catch(\Exception $e){
                return view('RMS.error.invalid',['message'=>$e->getMessage()]);
            }

            if($job){
                $standard_questions = $job->questions;
                return view('RMS.jobs.application',['job'=>$job,
                                                'standard_questions'=>$standard_questions]);
            }else{
                return view('RMS.error.invalid');
            }
        }else{
            return view('RMS.error.invalid');
        }
    }

    public function updateApplicationStatus(Request $request){
        $app_id = $request->input('application_id',NULL);
        $status = $request->input('status_id',NULL);
        $response = [];
        if($app_id && $status){
            $chk_status = JobApplicationStatus::find($status);
            if(empty($chk_status)){
                $response['status'] = "fail";
                $response['message'] = "Invalid status request";
                return response()->json($response);
            }
            try{
                $app = JobApplication::find($app_id);
                if($app){
                    $app->application_status = $status;
                    $app->save();
                    $response['status'] = "success";
                    $response['message'] = "Application status updated successfully!";
                }else{
                    $response['status'] = "fail";
                    $response['message'] = "Invalid application id";
                }
            }catch(\Exception $e){
                $response['status'] = "fail";
                $response['message'] = $e->getMessage();    
            }
        }else{
            $response['status'] = "fail";
            $response['message'] = "Invalid request!"; 
        }
        return response()->json($response);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $jobid = $request->input('job_id',0);
        $response = [];
        if($jobid > 0){
            $job = Jobs::find($jobid);
            if($job){
                try{
                    $job->is_deleted = 'Y';
                    $job->deleted_at = \Carbon::now();
                    $job->save();

                    $response['status'] = 'success';
                    $response['message'] = 'Job deleted successfully!';
                }catch(\Exception $e){
                    $response['status'] = 'fail';
                    $response['message'] = $e->getMessage();
                }
            }else{
                $response['status'] = 'fail';
                $response['message'] = 'Job not found!';
            }
        }else{
            $response['status'] = 'fail';
            $response['message'] = 'Invalid parameter!';
        }
        return response()->json($response);
    }


    public function downloadApplicationFile($application_id){
        if($application_id > 0){
            $application = JobApplication::find($application_id);
            if($application){
                $job_id = $application->jobs_id;
                $file_name = $application->resume_file_name;
                $original_file_name = $application->resume_original_file_name;
                $file_path = storage_path("app".DIRECTORY_SEPARATOR."application_path".DIRECTORY_SEPARATOR.$job_id.DIRECTORY_SEPARATOR.$application_id.DIRECTORY_SEPARATOR.$file_name);
                if(File::exists($file_path)){
                    return response()->download($file_path,$original_file_name);
                }else{
                    return view('RMS.error.invalid',['message'=>"Application file not found!"]);
                }
            }else{
                return view('RMS.error.invalid',['message'=>"Application not found!"]);
            }
        }else{
            return view('RMS.error.invalid',['message'=>"Invalid Request!"]);
        }
    }

}
