<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Models\Ehours;
use App\Http\Models\Company;
use App\Http\Models\Employees;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Models\EmployeeLeaveMaster;
use App\Http\Models\LeaveEncash;
use Carbon\Carbon;
use DB;
use Session;
use Helpers;
use Validator;
use Auth;
use Log;

class CronController extends Controller {
    public function addCl(){
      $start = new Carbon('first day of last month');
      try
      {
        $prevmonth = date('m',strtotime($start));
        $prevyear = date('Y',strtotime($start));
        $month = date('m');
        $year = date('Y');
        $employees = Employees::where('status',1)->get();
        
        if(!empty($employees))
        {
          foreach ($employees as $key => $employee) 
          {
            $cl_leave = 0;
            $compoff_leave = 0;
            $no_of_cl = 0;
            $leaveMaster = EmployeeLeaveMaster::where('month',$prevmonth)->where('year',$prevyear)->where('employee_id',$employee['id'])->first();
            $compoffMaster = EmployeeCompOffMaster::where('month',$prevmonth)->where('year',$prevyear)->where('employee_id',$employee['id'])->first();
            if(!empty($leaveMaster))
            {
              $cl_leave = $leaveMaster->balance;
              $no_of_cl = $leaveMaster->no_of_cl;
            }
            if(!empty($compoffMaster))
            {
              $compoff_leave = $compoffMaster->available;
              // Reset the compoff
              $compoffMaster->available = 0;
              $compoffMaster->save();
            }

            $leaveencash = array(
                    'employee_id' => $employee['id'],
                    'cl_leave' => $cl_leave,
                    'compoff_leave' => $compoff_leave,
                    'no_of_cl' => $no_of_cl,
                    'month'=>$prevmonth,
                    'year'=>$prevyear,
                    'created_by'=>1);
            LeaveEncash::create($leaveencash);

            

            // Update the CL for every employee

            if($employee['resource'] == '2' && $employee['payment'] != '4' && $employee['payment'] != '1'){
              $cl = 1;
            }else{
              $cl = 0;
            }

            $checkLeaveMaster = EmployeeLeaveMaster::where('month',$month)->where('year',$year)->where('employee_id',$employee['id'])->first();
            if(!$checkLeaveMaster){ 
              // echo $employee['id'];exit;
              $model = new EmployeeLeaveMaster();
              $model->employee_id = $employee['id'];
              $model->no_of_cl = $cl;
              $model->balance = $cl;
              $model->lop = 0;
              $model->month = $month;
              $model->year = $year;
              $model->created_by = 1;
              $model->save();

            }

         }
         
        }
        
            

          
        
      }
      catch(\Exception $e)
      {
        print_r($e);
        Log::error($e);
      } 
    }
    
}
