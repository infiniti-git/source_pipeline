<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Models\Ehours;
use App\Http\Models\Company;
use App\Http\Models\Employees;
use Carbon\Carbon;
use DB;
use Session;
use Helpers;
use Validator;
use Auth;
class EhoursController extends Controller {
    public function importExportExcelORCSV(){
      try
      {
        return view('ehours/file_import_export');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      } 
    }
    public function importFileIntoDB(Request $request){
      try
      {
        if($request->hasFile('sample_file')){
          
          $validator = Validator::make(
          [
              'file'      => $request->file('sample_file'),
              'extension' => strtolower($request->file('sample_file')->getClientOriginalExtension()),
          ],
          [
              'file'          => 'required',
              'extension'      => 'required|in:csv,xlsx,xls',
          ]);
          if ($validator->fails()) 
          {
              return redirect()->back()->withErrors($validator);
          } 

            $path = $request->file('sample_file')->getRealPath();
            \Config::set('excel.import.startRow', 2);
            //print_r($path); exit;
            $data = \Excel::load($path)->get();
            // echo "<pre>";
            // print_r($data->toArray()); exit; 

            $ehrs = $data->toArray();
            
            if(count($ehrs)){
              // $eHourDatas = $ehrs[0];
              $resources = [];


              foreach($ehrs as $eHourData){
                if($eHourData['user'] != '' && $eHourData['project_name'] != 'Vaccation') {
                  $Ehrdate = $eHourData['date'];
                  $date = $Ehrdate->format('Y-m-d');
                  $employee = Employees::GetEmployeeIdByName($eHourData['user']);
                  if($employee != null)
                 {
                    $checkEhrs = Ehours::where('employee_name',$eHourData['user'])->where('ehour_date',$date)->first();
                    if($checkEhrs)
                      $checkEhrs = Ehours::where('employee_name',$eHourData['user'])->where('ehour_date',$date)->delete();
                  }

                }
              }


              foreach($ehrs as $eHourData){

                if($eHourData['user'] != '' && $eHourData['project_name'] != 'Vaccation') {
                
                  $Ehrdate = $eHourData['date'];
                  $date = $Ehrdate->format('Y-m-d');

                $employee = Employees::GetEmployeeIdByName($eHourData['user']);
                       
                 if($employee != null)
                 {
                    
                    $hr = $eHourData['hours'];
                    if($hr) {
                      $checkEhrs = Ehours::where('employee_name',$eHourData['user'])->where('ehour_date',$date)->first();
                      $empid = $employee->id;

                      if(empty($checkEhrs)){
                          $model = new Ehours();
                          $model->user_id = Session::get('UserData')['SA_id'];
                          $model->employee_id =$empid;
                          $model->employee_name = $eHourData['user'];
                          $model->ehour_date = $date;
                          $model->hrs = $hr;
                          $model->save();
                      }
                      else 
                      {
                        $totalHrs  = $hr + $checkEhrs->hrs; 
                        $data = array(
                        'hrs' => $totalHrs
                        );
                        $ehour = Ehours::where('id',$checkEhrs->id)->update($data);
                      }
                    }
             
                  }else
                  {     
                    
                      array_push($resources,$eHourData['user']);
                  }

                }
              }

             
                 if(count($resources) > 0)
                 {
                  $resources = array_unique($resources);
                    Session::flash('success','Ehours uploaded successfully');
                    return view('ehours.ehours_uploaded')->with('resources',$resources);

                 }
                 else
                 {
                   Session::flash('success','Ehours uploaded successfully');
                   return redirect()->route('admin/import-export-csv-excel');
                 }

            }


           
            
        }
        
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }    
          
    } 
    public function downloadExcelFile($type){
      try
      {
        $products = Product::get()->toArray();
        return \Excel::create('expertphp_demo', function($excel) use ($products) {
            $excel->sheet('sheet name', function($sheet) use ($products)
            {
                $sheet->fromArray($products);
            });
        })->download($type);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    } 

    public function ManageEhours()
    {
      try
      {
          $companies = Company::GetCompany();
          $employees = Employees::GetActiveEmployees();
          return view('ehours.manage_ehours')->with(['companies'=>$companies,'employees'=>$employees]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }   
    
}
