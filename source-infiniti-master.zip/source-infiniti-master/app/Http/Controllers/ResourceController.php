<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\PaymentType;
use App\Http\Models\Employees;
use App\Http\Models\Users;
use App\Http\Models\Team;
use App\Http\Models\Company;
use App\Http\Models\Role;
use App\Http\Models\HoursType;
use DB;
use Session;
use Helpers;
use Validator;
use Auth;
use URL;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;
use App\Http\Models\EmployeeLeaveMaster;


class ResourceController extends Controller
{
    public function index()
    {
      try
      {
    	return view('resources.manage');
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }

    public function AddNew()
    { 
      try
      {
    	return view('resources.add');
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }
     
    public function ManageResources($resourceStatus)
    {
      try
      {
    	 $resources = Employees::EmployeeDetails($resourceStatus);
    	 return view('resources.manage')->with('resources',$resources);
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }
    public function AddResource()
    {
      try
      {
          $paymenttypes = PaymentType::all();
          $supervisors = Employees::GetSupervisors();
          $teams = Team::GetTeams();
          $companies = Company::GetCompany();
          $roles = Role::all();
          $hourstypes = HoursType::all();
          $userrole = Session::get('UserData')['role'];
          return view('resources.add')->with(['paymenttypes'=>$paymenttypes,'supervisors'=>$supervisors,'teams'=>$teams,'companies'=>$companies,'roles'=>$roles,'hourstypes'=>$hourstypes,'userrole'=>$userrole]);
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }

    public function EditResource($resourceId)
    {
      try
      {
    
          $paymenttypes = PaymentType::all();
          $supervisors = Employees::GetSupervisors();
          $resource = Employees::GetEmployeeById($resourceId);
          $teams = Team::GetTeams();
          $companies = Company::GetCompany();
          $roles = Role::all();
          $hourstypes = HoursType::all();
          $userrole = Session::get('UserData')['role'];
          return view('resources.edit')->with(['paymenttypes'=>$paymenttypes,'supervisors'=>$supervisors,'resource'=>$resource,'teams'=>$teams,'companies'=>$companies,'roles'=>$roles,'hourstypes'=>$hourstypes,'userrole'=>$userrole]);
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }


    /*
      FUNCTION NAME   : AddResource
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employees
      VIEW PAGE       : NULL
      IF NOTES        : add employees
      WROTE BY        : Jenifer
    */
    public function AddNewResource(Request $request)
    { 
      try
      {
        $rules     = array('resource_name' => 'required', 'resource_email' =>'required|unique:employees,email', 'resource_skype' => 'required', 'resource_supervisor' => 'required','resource_contact' => 'required|numeric', 'resource_source' => 'required','resource_paymenttype' => 'required','resource_address' => 'required','resource_team'=> 'required','resource_joindate' => 'required','resource_role' => 'required');
        $userdata = array(
                    'resource_name'      => $request->resource_name,
                    'resource_email'   => $request->resource_email,
                    'resource_skype'      => $request->resource_skype,
                    'resource_supervisor'   => $request->resource_supervisor,
                    'resource_contact'      => $request->resource_contact,
                    'resource_source'   => $request->resource_source,
                    'resource_paymenttype'   => $request->resource_paymenttype,
                    'resource_address' => $request->resource_address,
                    'resource_team' => $request->resource_team,
                    'resource_joindate' => $request->resource_joindate,
                    'resource_role' => $request->resource_role
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            $joinDate =date('Y-m-d',strtotime($request['resource_joindate']));
            $data = array(
                    'name'=>$request['resource_name'],
                    'email'=> $request['resource_email'],
                    'skypeid'=>$request['resource_skype'],
                    'supervisor'=>$request['resource_supervisor'],
                    'resource'=>$request['resource_source'],
                    'status'=>1,
                    'created_by'=>Session::get('UserData')['SA_id'],
                    'created_at'=>date('Y-m-d H:i:s'),
                    'phone'=>$request['resource_contact'],
                    'payment'=>$request['resource_paymenttype'],
                    'basicpay'=>$request['resource_basicpay'],
                    'loyaltybonus'=>$request['resource_loyaltybonus'],
                    'address'=> $request['resource_address'],
                    'isloyaltybonus'=> $request['resource_isloyaltybonus'],
                    'team'=> $request['resource_team'],
                    'joineddate'=> $joinDate,
                    'company'=>$request['resource_company'],
                    'role'=>$request['resource_role'],
                    'hourstype'=>$request['resource_hourstype'],
                );
            $employeeSave = Employees::create($data);
            $employeeId = $employeeSave->id;

            if($joinDate && $request['resource_paymenttype'] != 4){

              $noOfCl = 0;
              $currentMonth = date('Y-m-01');
              $midDayMonth = date('Y-m-15');
              $afterMidDay = date('Y-m-17');
              if($midDayMonth > $joinDate){
                $noOfCl = 1;
              }else if($joinDate > $midDayMonth && $joinDate < $afterMidDay){
                $noOfCl = 0.5;
              }

              $month = date('m');
              $year = date('Y');
              $employeeLeaveMaster = EmployeeLeaveMaster::where('employee_id',$employeeId)->where('month',$month)->where('year',$year)->count();
              if($employeeLeaveMaster == 0){
                $leaveModel = new EmployeeLeaveMaster();
                $leaveModel->employee_id = $employeeId;
                $leaveModel->month = $month;
                $leaveModel->year = $year;
                $leaveModel->balance = $noOfCl;
                $leaveModel->no_of_cl = $noOfCl;
                $leaveModel->lop = 0;
                $leaveModel->created_by =Session::get('UserData')['SA_id'];
                $leaveModel->save();
              }


            }
            Session::flash('success','Employee created successfully');
            return redirect()->route('admin/manage_resources',['resourceStatus'=>0]);
        }
      }
      catch(\Exception $e)
      {
        //\Log::error($e);
        dd($e);
      }
    }

    /*
      FUNCTION NAME   : EditResource
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employees
      VIEW PAGE       : NULL
      IF NOTES        : edit employees
      WROTE BY        : Jenifer
    */
    public function UpdateResource(Request $request)
    {   
      try
      {
        $rules     = array('resource_name' => 'required', 'resource_email' => 'required', 'resource_skype' => 'required', 'resource_supervisor' => 'required','resource_contact' => 'required|numeric', 'resource_source' => 'required','resource_paymenttype' => 'required','resource_address' => 'required','resource_team'=> 'required','resource_joindate' => 'required','resource_role' => 'required');
        $userdata = array(
                    'resource_name'      => $request->resource_name,
                    'resource_email'   => $request->resource_email,
                    'resource_skype'      => $request->resource_skype,
                    'resource_supervisor'   => $request->resource_supervisor,
                    'resource_contact'      => $request->resource_contact,
                    'resource_source'   => $request->resource_source,
                    'resource_paymenttype'   => $request->resource_paymenttype,
                    'resource_address' => $request->resource_address,
                    'resource_team' => $request->resource_team,
                    'resource_joindate' => $request->resource_joindate,
                    'resource_role' => $request->resource_role
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            if($request['id']!='')
            {
              
                $data = array(
                        'name'=>$request['resource_name'],
                        'email'=>$request['resource_email'],
                        'skypeid'=>$request['resource_skype'],
                        'supervisor'=>$request['resource_supervisor'],
                        'phone'=>$request['resource_contact'],
                        'resource'=>$request['resource_source'],
                        'updated_by'=>Session::get('UserData')['SA_id'],
                        'updated_at'=>date('Y-m-d H:i:s'),
                        'payment'=>$request['resource_paymenttype'],
                        'basicpay'=>$request['resource_basicpay'],
                        'loyaltybonus'=>$request['resource_loyaltybonus'],
                        'address' => $request['resource_address'],
                        'isloyaltybonus'=> $request['resource_isloyaltybonus'],
                        'team'=> $request['resource_team'],
                    	'joineddate'=> date('Y-m-d',strtotime($request['resource_joindate'])),
                        'company'=>$request['resource_company'],
                        'role'=> $request['resource_role'],
                        'hourstype'=>$request['resource_hourstype'],
                    );
                $Resource = Employees::where('id',$request['id'])->update($data);
                Session::flash('success','Employee Updated successfully');
            }
           
            return redirect()->route('admin/manage_resources',['resourceStatus'=>0]);
        }
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }
    public function DeleteResource($resourceId)
    {
      try
      {
        $Resource = Employees::where('id',$resourceId)->update(['status'=>0]);
        Session::flash('success','Employee Deleted Successfully');
        return redirect()->route('admin/manage_resources',['resourceStatus'=>0]);
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    }
    public function ExportExcel(){
      try
      {
        $resources = Employees::GetAllEmployeeDetails()->toArray();
        $result = json_decode(json_encode($resources),true);
        return \Excel::create('active_resources', function($excel) use ($result) {
            $excel->sheet('sheet name', function($sheet) use ($result)
            {
                $sheet->fromArray($result);
            });
            $userrole = Session::get('UserData')['role'];
            if(isset($userrole) && $userrole != 1)
            {
              $excel->getActiveSheet()->getColumnDimension('I')->setVisible(false);
              $excel->getActiveSheet()->getColumnDimension('J')->setVisible(false);
            }
        })->download('xlsx');
      }
      catch(\Exception $e)
      {
        \Log::error($e);
      }
    } 

   /* public function CheckUserEmailAleradyExists()
    {

      $user = Employees::where('email', Input::get('resource_email'))->first();

      if ($user) {
              return false;
      } else {
          return true;
      }
    }*/
}
