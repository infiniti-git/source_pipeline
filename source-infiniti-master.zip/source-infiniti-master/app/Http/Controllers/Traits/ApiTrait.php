<?php 
/**
   * Api Trait Class
   * To access the common functions
   *
   * @package    Laravel
   * @subpackage Trait 
   */

namespace App\Http\Controllers\Traits;
use Illuminate\Support\Facades\Input;

use Request;
use Config;
use Session;
use Mail;
use Log;
use DateTime;
use DateTimeZone;
use DB;
use App\Http\Models\Company;
use App\Http\Models\Employees;
use App\Http\Models\EmployeeLeave;
use App\Http\Models\EmployeeCompoff;
use App\Http\Models\Ehours;
use App\Http\Models\LeaveEncash;

trait ApiTrait {

    /**
     * Create a new request.
     *
     * @return void
     */
    
    public function __construct(){
        
    } 

    

    /**
       * 
       * To get http request data for the current request
       *
       * @param array $data  
       * @return array
       */

    public function getData($data) 
    {
        $post = Input::json()->all();
        if (!isset($post) || empty($post))
            $post = Input::all();
        return $post;
    }

    


    /**
       * 
       * To get response for the api 
       *
       * @param boolean $status  
       * @param integer $code  
       * @param array $result  
       * @return array
       */

    public function getResponse($status, $code, $result = array('*')) 
    {
        $response['status']  = $status;
        $response['code']    = $code;
        $response['message'] = Config::get('errorcode')[$code];
        $response['result']  = $result;
        return $response;
    }   



    /**
     * Error log create 
     *
     * @param string $controllerName
     * @param string $functionName
     * @param string $errorType
     * @param integer $messagecode
     * @param array $postVal
     * @return boolean
     */
    
    public function errorLogCreate($controllerName,$functionName,$errorType,$messagecode,$postVal){        
        
        $msg =  array('Function' => $functionName, 'Message' => Config::get('logmessage')[$messagecode], 'Data' => $postVal);

        switch ($errorType) {
            case 'error':
                Log::error("Class:".$controllerName, $msg);
                break;
            case 'success':
            case 'info':
                Log::info("Class:".$controllerName, $msg);
                break;
            case 'warning':
                Log::error("Class:".$controllerName, $msg);
                break;   
            case 'notice':
                Log::notice("Class:".$controllerName, $msg);
                break;     
            case 'debug':
                Log::debug("Class:".$controllerName, $msg);
                break;  
            default:
                Log::info("Class:".$controllerName, $msg);
                break;
        }    

        return TRUE;          
    }


    public function getCompanyEmployees($id){
      $employees = Employees::where('company',$id)->where('status',1)->get();
      return $employees;
    }

    /**
    * Get In app working days of the employee
    * @param employeeId, Month, Year, Total days
    * @return 
    */

    public function getEmployeeInappWorkingDays($empId, $month, $year, $totalDays,$hourstype){

      $empworkdays = $totalDays;
      $employeeleaves = EmployeeLeave::GetEmployeeLeaveDetailsForMonth($month,$year,$empId);
      if(isset($employeeleaves) && count($employeeleaves)>0)
      {
        foreach ($employeeleaves as $employeeleave) 
        {
          //Checking Leave Type CL
          if($employeeleave->leave_type == 1 && $employeeleave->day_type == 1)
          {
            $empworkdays = $empworkdays - 1;
          }
          elseif ($employeeleave->leave_type == 1 && $employeeleave->day_type == 2) {
            $empworkdays = $empworkdays - 0.5;
          }

          //Checking Leave Type Compoff
          if($employeeleave->leave_type == 2 && $employeeleave->day_type == 1)
          {
            $empworkdays = $empworkdays - 1;
          }
          elseif ($employeeleave->leave_type == 2 && $employeeleave->day_type == 2) {
            $empworkdays = $empworkdays - 0.5;
          }

          //Checking Leave Type LOP
          if($employeeleave->leave_type == 3 && $employeeleave->day_type == 1)
          {
            $empworkdays = $empworkdays - 1;
          }
          elseif ($employeeleave->leave_type == 3 && $employeeleave->day_type == 2) {
            $empworkdays = $empworkdays - 0.5;
          }

        }
      }
      else
      {
          $empworkdays = $totalDays;
      }
    
      //Checking CompOff table
      $employeecompoffs = EmployeeCompoff::GetEmployeeCompOffofMonth($month,$year,$empId);
      if(isset($employeecompoffs) && count($employeecompoffs)>0)
      {
        foreach ($employeecompoffs as $employeecompoff) {
          if($employeecompoff->day_type == 1)
          {
            $empworkdays = $empworkdays + 1;
          }
          elseif ($employeecompoff->day_type == 2) {
            $empworkdays = $empworkdays + 0.5;
          }
          elseif($employeecompoff->day_type == 3)
          {
             $dayType = $this->calculateDayType($employeecompoff->hours,$hourstype);
             $empworkdays = $empworkdays + $dayType;
          }

        }
      }

      return $empworkdays;

    }


    /**
    * Get Ehours  days of the employee
    * @param employeeId, Month, Year, Total days
    * @return 
    */
    public function getEmployeeEhrsDays($empId, $month, $year,$hourstype){

      $ehours = Ehours::getEmployeeeHourforMonth($month,$year,$empId);
      $ehourday = 0;
      if(isset($ehours) && count($ehours)>0)
      {
          foreach ($ehours as $ehour) 
          {
              $emphour = $ehour->hrs;
             
              $dayType = $this->calculateDayType($emphour,$hourstype);
              $ehourday = $ehourday + $dayType;
          }
      }
      return $ehourday;
    }

    public function calculateDayType($emphour,$hourstype)
    {

        $dayType = 0;
         //4 hours user
          if($hourstype == 1)
          {
            if($emphour<3)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>=3)
            {
                $dayType = $dayType + 1;
            }
          }
          elseif($hourstype == 2)//6 hours user
          {
            if($emphour>=3.5 && $emphour<5)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>=5)
            {
                $dayType = $dayType + 1;
            }
          }
          elseif($hourstype == 3)//7 hours user
          {
            if($emphour>=3 && $emphour<6)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>=6)
            {
                $dayType = $dayType + 1;
            }
          }
          elseif($hourstype == 4)//9 hours user
          {
            if($emphour>=4 && $emphour<7)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>=7)
            {
                $dayType = $dayType + 1;
            }
          }
          elseif($hourstype == 5)//8 hours user
          {
            if($emphour>=4 && $emphour<6.5)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>=6.5)
            {
                $dayType = $dayType + 1;
            }
          }
          else
          {
            if($emphour>2 && $emphour<=6)
            {
                $dayType = $dayType + 0.5;
            }
            elseif($emphour>6)
            {
                $dayType = $dayType + 1;
            }
          }
          return $dayType;
    }


    public function calculateTotalPay($empId,$month, $year, $inAppWorkedDays, $totalWorkingDays)
    {

      $employee = Employees::GetActiveEmployeeDetailsById($empId);


      $leaveencashcheck = LeaveEncash::where('month',$month)->where('year',$year)->where('employee_id',$empId)->first();
      $encashleave = 0;
      if(isset($leaveencashcheck) && !empty($leaveencashcheck))
      {
         $encashleave = $leaveencashcheck['cl_leave'] + $leaveencashcheck['compoff_leave'];
      }
      
      $encashamount = 0;
      $pay['basic'] = 0;
      $pay['encash'] = 0;

      if($employee->payment_type == '1')
      {
        $ehours = Ehours::getEmployeeeHourforMonth($month,$year,$empId);
        $tothours = 0;
        if(isset($ehours) && count($ehours)>0)
        {
            foreach ($ehours as $ehour) 
            {
                $emphour = $ehour->hrs;
                $tothours = $tothours + $emphour;
            }
        }
        $pay['basic'] = $tothours  * $employee->basicpay;
        if($encashleave >  0)
        {
          //$salaryperday = $employee->basicpay/$totalworkingday;
          //$encashamount = 8 * $encashleave;
        }
        return json_encode($pay);
      }
      elseif($employee->payment_type == '2')     /* Payment Type Daily*/
      {
        $pay['basic'] = $inAppWorkedDays*$employee->basicpay;
        if($encashleave >  0)
        {
          $pay['encash'] = $employee->basicpay * $encashleave;
        }
        return json_encode($pay);
      }
      elseif($employee->payment_type == '3')    /* Payment Type Monthly FullTime*/
      {
        $pay['basic'] = ($inAppWorkedDays/$totalWorkingDays)*$employee->basicpay;
        if($encashleave >  0)
        {
          $salaryperday = $employee->basicpay/$totalWorkingDays;
          $pay['encash'] = ($employee->basicpay/21) * $encashleave;
        }
        return json_encode($pay);
      }
      elseif($employee->payment_type == '4')     /* Payment Type Monthly Premium*/
      {
        $pay['basic'] = ($inAppWorkedDays/$totalWorkingDays)*$employee->basicpay;
        if($encashleave >  0)
        {
          $salaryperday = $employee->basicpay/$totalWorkingDays;
          $pay['encash'] = ($employee->basicpay/21) * $encashleave;
        }
        return json_encode($pay);
      } 
      elseif($employee->payment_type == '5')    /* Payment Type Monthly Parttime*/
      {
        $pay['basic'] = ($inAppWorkedDays/$totalWorkingDays)*$employee->basicpay;
        if($encashleave >  0)
        {
          $salaryperday = $employee->basicpay/$totalWorkingDays;
          $pay['encash'] = ($employee->basicpay/21) * $encashleave;
        }
        return json_encode($pay);
      }


    }

    

}