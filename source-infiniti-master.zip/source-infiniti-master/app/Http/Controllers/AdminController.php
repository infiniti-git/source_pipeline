<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Employees; 
use App\Http\Models\EmployeeLeave;
use App\Http\Models\EmployeeLeaveMaster;
use App\Http\Models\EmployeeCompoffMaster;
use App\Http\Models\Month;
use Illuminate\Support\Facades\Input;
use DB;
use Session;
use Helpers;
use Validator;
use Auth;
use DateTime;
use Log;

class AdminController extends Controller
{
    public function index()
    {
      try
      {
        $activeresourcecount = Employees::GetActiveResourcesCount();
        $inactiveresourcecount = Employees::GetInActiveResourcesCount();
        return view('admin.dashboard')->with(['activeresourcecount'=>$activeresourcecount,'inactiveresourcecount'=>$inactiveresourcecount]); 
      }
      catch(\Exception $e)
      {
        Log::error($e);
      } 	
    }

    public function ManageUserRoles()
    {
      try
      {
    	   return view('userroles.manage');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      } 
    }

    public function NewUserRoles()
    {
      try
      {
    	  return view('userroles.add');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    public function ManageUsers()
    {
      try
      {
    	   return view('users.manage');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }   
    }

    public function ManageResources()
    {
      try
      {
    	   return view('resources.manage');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    public function AddResource()
    {
      try
      {
    	   return view('resources.add');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


    /*
      FUNCTION NAME   : ResourceAddCL
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/addcl
      IF NOTES        : view page CL for employee
      WROTE BY        : Yuvaraj
    */
    public function ResourceAddCL()
    {
      try
      {

        $employees = Employees::where('status',1)->get();
        $month = date('M');
        $year = date('Y');
        return view('leave.addcl')->with(['employees'=>$employees,'month'=>$month,'year'=>$year]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

    /*
      FUNCTION NAME   : ApplyCLforResource
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : employee_leave_master
      VIEW PAGE       : NULL
      IF NOTES        : add CL for employee
      WROTE BY        : Yuvaraj
    */
    public function ApplyCLforResource(Request $request)
    {
      try
      {
        $rules     = array('employee' => 'required', 'available_cl' => 'required');
        $userdata = array(
                    'employee'      => $request->employee,
                    'available_cl'   => $request->available_cl,
                );
        $validator = Validator::make($userdata, $rules);
        if ($validator->fails()) 
        {
            return redirect()->back()->withErrors($validator);
        } 
        else 
        {
            if($request['employee_leave_id']!='')
            {
                $data = array(
                        'balance'=>$request['available_cl'],
                        'updated_by'=>Session::get('UserData')['SA_id'],
                        'updated_at'=>date('Y-m-d H:i:s')
                    );
                $ResourceLeave = EmployeeLeaveMaster::where('id',$request['employee_leave_id'])->update($data);
                Session::flash('success','CL Updated successfully');
            }
            else
            {
                $data = array(
                        'employee_id'=>$request['employee'],
                        'balance'=>$request['available_cl'],
                        'lop'=>0,
                        'month'=>date('m'),
                        'year'=>date('Y'),
                        'created_by'=>Session::get('UserData')['SA_id'],
                        'created_at'=>date('Y-m-d H:i:s')
                    );
                EmployeeLeaveMaster::create($data);
                Session::flash('success','CL Applied successfully');
            }
            return redirect()->route('admin/resource_add_cl');
        }
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }

   


    /*
      FUNCTION NAME   : ResourceLeave
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/manage_cl
      IF NOTES        : list the resources month leave
      WROTE BY        : Yuvaraj
    */
    public function ResourceLeave()
    {
      try
      {
        $month = date('m');
        $year = date('Y');
        $employees = Employees::where('status',1)->get();
        $emloyeeAvailLeave = [];

        foreach($employees as $emp){
          $temp['employee_name'] = $emp['name'];
          if($emp['resource'] == '1')
          {
            $temp['resource_type'] = 'Company';
          }else{
            $temp['resource_type'] = 'Direct';
          }
          $leaveMasterModel = EmployeeLeaveMaster::select('balance')->where('employee_id',$emp['id'])->where('month',$month)->where('year',$year)->first();
          if($leaveMasterModel)
            $availCL = $leaveMasterModel->balance;
          else
            $availCL = 0;
          $temp['avail_cl'] = $availCL;

          $compOffModel = EmployeeCompoffMaster::select('available')->where('employee_id',$emp['id'])->where('month',$month)->where('year',$year)->first();
          if($compOffModel)
            $availCompOff = $compOffModel->available;
          else
            $availCompOff = 0;
          $temp['avail_comp_off'] = $availCompOff;

          array_push($emloyeeAvailLeave,$temp);

        }

        
        return view('leave.manage_cl')->with(['emloyeeAvailLeave'=>$emloyeeAvailLeave,'month'=>$month,'year'=>$year]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }



    /*
      FUNCTION NAME   : ResourceManageLeave
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/manage_leave
      IF NOTES        : list the resources leave
      WROTE BY        : Yuvaraj
    */
    public function ResourceManageLeave()
    {
      try
      {

        return view('leave.manage_leave');
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }


    /*
      FUNCTION NAME   : ResourceManageLeave
      ARGUMENTS       : NULL
      ARGUMENTS NOTES : NULL
      TABLE(DB)       : NULL
      VIEW PAGE       : leave/manage_leave
      IF NOTES        : list the resources leave for month
      WROTE BY        : Yuvaraj
    */
    public function ResourceMonthLeave()
    {
      try
      {

        $months = Month::all();
        
        $month_name = '';
        

        if(Input::get('get_month'))
        {
            $inputMonth = Input::get('month');
            $explode =explode('/',$inputMonth);
            if(!empty($explode)){
              $month = $explode[0];
              $year = $explode[1];
              $dateObj   = DateTime::createFromFormat('!m', $month);
              $monthName = $dateObj->format('F'); // March
              $monthLeaves = EmployeeLeave::ResourceMonthLeaves($month, $year);
              
            }
            else
            {
                Session::flash('error','Something Went Wrong.');  
                return redirect()->route('admin/resource_month_leave');
            }

        }
        else
        {
            $month = date('m');
            $monthName = date('M');
            $year = date('Y');

            $monthLeaves = EmployeeLeave::ResourceMonthLeaves($month,$year);
        }

       

        return view('leave.manage_month_leave')->with(['months'=>$months,'monthLeaves'=>$monthLeaves,'monthName'=>$monthName]);
      }
      catch(\Exception $e)
      {
        Log::error($e);
      }
    }



   



      
}
