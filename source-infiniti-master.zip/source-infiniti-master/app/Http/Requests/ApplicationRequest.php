<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ApplicationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'candidate_name' => 'required|max:30',
            'candidate_location' => 'required|max:30',
            'candidate_resume' => 'required|file|mimetypes:application/octet-stream,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf|max:2000',
            'standard_question_answers.*' => 'required',
            'captcha' => 'required|captcha'
        ];
    }

    public function messages()
    {
        return [
            'candidate_resume.max' => 'Resume/Cover Letter/CV should be of 2MB max.',
             'candidate_resume.mimetypes' => 'Resume/Cover Letter/CV should be of doc, docx or PDF type file.',
        ];
    }

    public function attributes()
    {
        return [
            'candidate_resume'=>'Resume/Cover Letter/CV',
        ];
    }
}
