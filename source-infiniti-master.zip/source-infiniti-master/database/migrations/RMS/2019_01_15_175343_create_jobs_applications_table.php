<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobsApplicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('jobs_applications');
        Schema::create('jobs_applications', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('jobs_id')->nullable(FALSE);
            $table->string('applicant_name',30)->nullable(FALSE);
            $table->string('location',30)->nullable(FALSE);
            $table->string('resume_original_file_name',150)->nullable();
            $table->string('resume_file_name',150)->nullable();
            $table->integer('application_status');
            $table->integer('created_by');
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
