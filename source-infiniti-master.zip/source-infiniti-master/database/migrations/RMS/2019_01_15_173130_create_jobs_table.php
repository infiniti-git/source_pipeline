<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('jobs');
        Schema::create('jobs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('job_reference',10)->unique()->nullable(FALSE);
            $table->string('job_title',20)->nullable(FALSE);
            $table->text('description');
            $table->integer('created_by');
            $table->integer('updated_by')->nullable(TRUE);
            $table->enum('is_active',['Y','N'])->default('Y')->nullable(FALSE);
            $table->enum('is_deleted',['Y','N'])->default('N')->nullable(FALSE);
            $table->dateTime('deleted_at')->nullable(TRUE);
            $table->integer('deleted_by')->nullable(TRUE);
            $table->timestamps();
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
