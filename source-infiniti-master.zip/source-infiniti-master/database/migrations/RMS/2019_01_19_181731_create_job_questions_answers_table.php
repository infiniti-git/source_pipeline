<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobQuestionsAnswersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('jobs_questions_answers');
        Schema::create('jobs_questions_answers', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('jobs_id')->nullable(FALSE);
            $table->integer('application_id')->nullable(FALSE);
            $table->integer('questions_id')->nullable(FALSE);
            $table->string('answer',50)->nullable(FALSE);
            $table->integer('created_by');
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->engine = 'InnoDB';
            $table->charset = 'utf8';
            $table->collation = 'utf8_unicode_ci';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
