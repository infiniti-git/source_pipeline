2018_12_20_124730_AddNewFields.php
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddEmployeeNewFields extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
    	 Schema::table('employees', function($table) {
             $table->bigInteger('phone')->nullable();
             $table->integer('basicpay')->nullable();
             $table->integer('loyaltybonus')->nullable();
          });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
