<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableCompanyPayroll extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company_pay_roll', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('company_id')->nullable();
            $table->integer('employee_id')->nullable();
            $table->integer('month')->nullable(); 
            $table->integer('year')->nullable(); 
            $table->decimal('inapp_workingdays',3,1)->nullable();
            $table->decimal('ehrs_days',3,1)->nullable();
            $table->float('basicpay', 8, 2)->nullable();
            $table->float('salary', 8, 2)->nullable();
            $table->float('encashment', 8, 2)->nullable();
            $table->float('total_pay', 8, 2)->nullable();
            $table->string('file_path')->nullable();
            $table->integer('generated_by'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company_pay_roll');
    }
}
