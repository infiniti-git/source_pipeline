<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterEhourcolumnUseridandusername extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ehours', function($table) {
             $table->renameColumn('user_name', 'employee_name');
             $table->integer('employee_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ehours', function(Blueprint $table) {
            $table->renameColumn('employee_name', 'user_name');
        });
    }
}
