<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGeneratePayrollTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payroll', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('employee');
            $table->integer('month'); 
            $table->integer('year'); 
            $table->float('basicpay', 8, 2);
            $table->float('reimbursment', 8, 2)->nullable();
            $table->boolean('isloyaltyapplicable')->nullable();
            $table->float('loyaltybonus', 8, 2)->nullable();
            $table->float('totalpay', 8, 2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payroll');
    }
}
