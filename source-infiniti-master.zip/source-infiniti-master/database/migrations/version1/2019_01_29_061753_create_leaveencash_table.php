<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLeaveencashTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leaveencash', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('employee_id');
            $table->decimal('cl_leave',3,1)->default(0);
            $table->decimal('compoff_leave',3,1)->default(0);
            $table->decimal('no_of_cl',3,1)->default(0);
            $table->integer('month');
            $table->integer('year');
            $table->integer('created_by');
            $table->integer('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()

    {
        Schema::dropIfExists('leaveencash');
    }
}
