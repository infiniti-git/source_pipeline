<?php

use Illuminate\Database\Seeder;

class HoursTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('hourstype')->insert([
            ['id'=>1,'hours_type' => '4 hours user','status' => '1'],
            ['id'=>2,'hours_type' => '6 hours user','status' => '1'],
            ['id'=>3,'hours_type' => '7 hours user','status' =>'1'],
            ['id'=>4,'hours_type' => '9 hours user','status' => '1'],
            ['id'=>5,'hours_type' => '8 hours user','status' =>'1'],
            
        ]);
    }
}

