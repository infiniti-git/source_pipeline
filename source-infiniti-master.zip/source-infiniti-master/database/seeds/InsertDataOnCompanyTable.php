<?php

use Illuminate\Database\Seeder;

class InsertDataOnCompanyTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	DB::table('company')->insert([
            'name'=>'Optisol',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'Infogana',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'Genesis',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'Sublime',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'One technologies',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'CRM',
            'status'=>1
            ]);
        DB::table('company')->insert([
            'name'=>'Precise',
            'status'=>1
            ]);
        
    }
}


                



                 







