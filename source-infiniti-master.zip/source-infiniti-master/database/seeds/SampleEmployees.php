<?php

use Illuminate\Database\Seeder;

class SampleEmployees extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('employees')->insert([
        	'name'=>'Nila',
        	'email'=>'nila@sourceinfiniti.co.uk',
        	'skypeid'=>'nila_sourceinfinity',
        	'supervisor'=>1,
        	'phone'=>123456,
        	'resource'=>2,
        	'payment'=>2,
        	'status'=>1,
        	'created_by'=>1,
        	]);
    }
}
