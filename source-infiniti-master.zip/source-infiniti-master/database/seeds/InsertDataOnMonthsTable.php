<?php

use Illuminate\Database\Seeder;

class InsertDataOnMonthsTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$Months = array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
    	foreach ($Months as $value) 
    	{
    		DB::table('month')->insert(['month'=>$value]);
    	}
        
    }
}
