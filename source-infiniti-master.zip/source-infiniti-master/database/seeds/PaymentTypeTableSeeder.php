<?php

use Illuminate\Database\Seeder;

class PaymentTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('payment_type')->insert([
            ['id'=>1,'payment_type' => 'Hourly','status' => '1'],
            ['id'=>2,'payment_type' => 'Daily','status' => '1'],
            ['id'=>3,'payment_type' => 'Monthly-Fulltime','status' =>'1'],
            ['id'=>4,'payment_type' => 'Monthly-Premium','status' => '1'],
            ['id'=>5,'payment_type' => 'Monthly-Parttime','status' =>'1'],
            
        ]);
    }
}

