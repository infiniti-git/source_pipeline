<?php

use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('company')->insert([
            ['id'=>1,'name' => 'Optisol','status' => '1'],
            ['id'=>2,'name' => 'Infogana','status' => '1'],
            ['id'=>3,'name' => 'Genesis','status' => '1'],
            ['id'=>4,'name' => 'Sublime','status' => '1'],
            ['id'=>5,'name' => 'One technologies','status' => '1'],
            ['id'=>6,'name' => 'CRM','status' => '1'],
            ['id'=>7,'name' => 'Precise','status' => '1'],

        ]);
    }
}
