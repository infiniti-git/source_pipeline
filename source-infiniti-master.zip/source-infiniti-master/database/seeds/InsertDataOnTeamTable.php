<?php

use Illuminate\Database\Seeder;

class InsertDataOnTeamTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	DB::table('team')->insert([
        	'teamname'=>'BA'
        	]);
        DB::table('team')->insert([
            'teamname'=>'QA'
            ]);
        DB::table('team')->insert([
            'teamname'=>'DEV'
            ]);
        DB::table('team')->insert([
            'teamname'=>'UI'
            ]);
        DB::table('team')->insert([
            'teamname'=>'PMO'
            ]);
        DB::table('team')->insert([
            'teamname'=>'Lead'
            ]);
    }
}
