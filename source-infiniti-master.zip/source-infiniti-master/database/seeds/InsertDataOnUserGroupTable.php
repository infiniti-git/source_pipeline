<?php

use Illuminate\Database\Seeder;

class InsertDataOnUserGroupTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	DB::table('role')->insert([
            'name'=>'SuperAdmin',
            'status'=>1
            ]);
        DB::table('role')->insert([
            'name'=>'Admin',
            'status'=>1
            ]);
        DB::table('role')->insert([
            'name'=>'Lead',
            'status'=>1
            ]);
        DB::table('role')->insert([
            'name'=>'Member',
            'status'=>1
            ]);
        
    }
}
