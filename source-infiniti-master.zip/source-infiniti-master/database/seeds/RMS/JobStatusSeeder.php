<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;
use App\Models\JobApplicationStatus;

class JobStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$statuses = [[
            'status' => 'NEW',
            'created_by' => 1,
            'created_at' => \Carbon::now(),
        ],[
            'status' => 'IN PROGRESS',
            'created_by' => 1,
            'created_at' => \Carbon::now(),
        ],[
            'status' => 'SELECTED',
            'created_by' => 1,
            'created_at' => \Carbon::now(),
        ],[
            'status' => 'PARKED',
            'created_by' => 1,
            'created_at' => \Carbon::now(),
        ],[
            'status' => 'REJECTED',
            'created_by' => 1,
            'created_at' => \Carbon::now(),
        ]];
    	foreach($statuses as $stat){
		    JobApplicationStatus::create($stat);
		}
    }
}
