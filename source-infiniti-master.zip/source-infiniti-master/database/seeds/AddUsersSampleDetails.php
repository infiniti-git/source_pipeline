<?php

use Illuminate\Database\Seeder;

class AddUsersSampleDetails extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
        	'name'=>'Super Admin',
        	'email'=>'superadmin@infiniti.com',
        	'role'=>1,
        	'password'=>md5(123456),
        	'status'=>1,
        	'avatar'=>"NULL",
        	'created_by'=>1,
        	]);
        /*DB::table('users')->insert([
            'name'=>'Benita',
            'email'=>'benita@infiniticreation.co.uk',
            'usergroup'=>4,
            'password'=>md5(123456),
            'status'=>1,
            'avatar'=>"NULL",
            'created_by'=>1,
            ]);
        DB::table('users')->insert([
            'name'=>'Benno',
            'email'=>'benno@infiniticreation.co.uk',
            'usergroup'=>4,
            'password'=>md5(123456),
            'status'=>1,
            'avatar'=>"NULL",
            'created_by'=>1,
            ]);
        DB::table('users')->insert([
            'name'=>'RathinaKumar',
            'email'=>'rathinakumar@infiniticreation.co.uk',
            'usergroup'=>4,
            'password'=>md5(123456),
            'status'=>1,
            'avatar'=>"NULL",
            'created_by'=>1,
            ]);
        DB::table('users')->insert([
            'name'=>'Cynthya',
            'email'=>'cynthya@infiniticreation.co.uk',
            'usergroup'=>4,
            'password'=>md5(123456),
            'status'=>1,
            'avatar'=>"NULL",
            'created_by'=>1,
            ]);*/
    }
}
