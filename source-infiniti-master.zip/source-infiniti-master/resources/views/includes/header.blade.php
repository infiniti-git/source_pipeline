<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Source Infinity</title>

    <!-- Bootstrap Core CSS -->


    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <link href="{{asset('css/jquery-ui.css')}}" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{asset('css/metisMenu.min.css')}}" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="{{asset('css/sb-admin-2.css')}}" rel="stylesheet">

    <link href="{{ asset('css/all.min.css') }}" rel="stylesheet" type="text/css">

    <link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet">

    <link href="{{asset('css/morris/morris.css')}}" rel="stylesheet">
    <!-- Custom Fonts -->
    
    <link href="{{asset('css/bootstrap-datepicker.css')}}" rel="stylesheet">

     <!-- DataTables CSS -->
    <link href="{{asset('css/dataTables.bootstrap.css')}}" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="{{asset('css/dataTables.responsive.css')}}" rel="stylesheet">

    <link href="{{asset('css/jquery-confirm.css')}}" rel="stylesheet">

    <link href="{{asset('css/style.css')}}" rel="stylesheet">
    
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">                
                <a class="navbar-brand" href="#">Source Infiniti</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
               
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="{{route('logout')}}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{route('admin/dashboard')}}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <!--<li>
                            <a href="{{route('admin/manage_userroles')}}"><i class="fa fa-universal-access"></i> Manage User Roles</a>
                        </li>
                        <li>
                            <a href="{{route('admin/manage_users')}}"><i class="fa fa-user"></i> Manage User</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-university"></i> Manage Source</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-money"></i> Manage Payment</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Manage Attendance</a>
                        </li>-->
                        <li>
                            <a href="{{route('admin/manage_resources',['resourceStatus'=>0])}}"><i class="fa fa-users"></i> Manage Resources</a> 
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-book"></i> Resource Leave Management<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <!-- <li>
                                    <a href="{{route('admin/add_working_days')}}">Add Working Days</a>
                                </li>-->
                                <!-- <li>
                                    <a href="{{route('admin/resource_add_cl')}}">Load CL for Resource</a>
                                </li> -->
                                <li>
                                    <a href="{{route('admin/add_comp_off')}}">Add Comp-Off</a>
                                </li>
                                <li>
                                    <a href="{{route('admin/resource_leave')}}">Available Leave/Comp-off Balance</a>
                                </li> 
                                <li>
                                    <a href="{{route('admin/resource_add_leave')}}">Apply CL/Comp-Off for Resource</a>
                                    <!-- <a href="{{route('admin/resource_add_leave')}}">Add Leave</a> -->
                                </li>
                                <li>
                                    <a href="{{route('admin/resource_month_leave')}}">View Leave Details</a>
                                </li>                                
                                
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
			            <li>
                            <a href="#"><i class="fa fa-hashtag"></i> Payroll Management <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{route('admin/add_working_days')}}">Add Working Days</a>
                                </li>
                                <li>
                                    <a href="{{route('admin/payroll')}}">Payroll Generation</a>
                                </li>
                                <li>
                                    <a href="{{route('admin/company_payroll')}}">Company Payroll Generation</a>
                                </li>
                            </ul>
                        </li>
                       <!-- <li>
                            <a href="#"><i class="fa fa-retweet"></i> Manage Resources Attendance</a>
                        </li> -->
                        <li>
                            <a href="#"><i class="fa fa-book"></i> E-hours Management<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="{{route('admin/manage_ehours')}}">Manage E-hours</a>
                                </li>
                                <li>
                                    <a href="{{route('admin/import-export-csv-excel')}}">Upload E-hours</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                       
                        <li>
                            <a href="{{route('login')}}"><i class="fa fa-sign-out"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>


    <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="confirm_dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Alert!</h4>
                <div><p class="confirm_content"></p>
                </div>
                </div>
                <input type="hidden" name="confirm_id" id="confirm_id">
                <div class="modal-footer">
                
                <button type="button" class="btn btn-default" id="confirm-btn-no">No</button>
                <button type="button" class="btn btn-primary" id="confirm-btn-yes">Yes</button>
                </div>
            </div>
        </div>
    </div>

