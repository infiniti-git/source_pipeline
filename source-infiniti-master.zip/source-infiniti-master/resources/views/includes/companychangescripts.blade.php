<script type="text/javascript">
	$(".company").change(function(event) 
	{
		$.ajax({
			url: '/get_employeebycompany',
			type: 'POST',
			data: {company: $(this).val(),_token: "{{ csrf_token() }}"},
		})
		.done(function(result) 
		{
			$(".employees").html(result.options);
		})
		.fail(function() {
			console.log("error");
		})
	});
</script>