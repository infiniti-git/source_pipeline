@if(isset($ehours) && count($ehours)>0)
   @php $i = 1 @endphp
    @foreach($ehours as $ehour)
    <tr id="{{$ehour->id}}">
        <td>{{$ehour->employee_name}}</td>
        <td>{{$ehour->ehour_date}}</td>
        <td data-field="hrs" name="hrs">{{$ehour->hrs}}</td>
        <td>
            <a class="button button-small edit" title="Edit">
              <i class="fa fa-pencil"></i>
            </a>
        </td>
    </tr>
    @endforeach
@else
    <tr><td align="center" colspan="4">No data available in table</td></tr>
  
@endif