 

    <script src="{{asset('js/jquery.min.js')}}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{asset('js/bootstrap.min.js')}}"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{asset('js/metisMenu.min.js')}}"></script>

  
    <script src="{{asset('js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('js/additional-methods.js')}}"></script>
    <script src="{{asset('js/jquery-confirm.js')}}"></script>

     <!-- DataTables JavaScript -->

    <script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('js/dataTables.bootstrap.min.js')}}"></script>
    <script src="{{asset('js/dataTables.responsive.js')}}"></script>
    <script src="{{asset('js/jquery-ui.min.js')}}"></script>
    <script src="{{asset('js/bootstrap-datepicker.js')}}"></script>

   

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

      <!-- Custom Theme JavaScript -->
    <script src="{{asset('js/sb-admin-2.js')}}"></script>

    <!-- <script src="//code.jquery.com/jquery-1.11.3.min.js"></script> -->
    <script src="{{asset('js/table-edits.min.js')}}"></script>
    <!-- jQuery -->

    <script>
         $(".alert").fadeOut(10000);



  $('[data-toggle="tooltip"]').tooltip(); 


    </script>

</body>
</html>