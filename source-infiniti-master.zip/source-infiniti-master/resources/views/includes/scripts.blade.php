<script type="text/javascript">
	// $(".employee_type").change(function(event) 
	// {
	// 	$.ajax({
	// 		url: '/get_employee',
	// 		type: 'POST',
	// 		headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
	// 		data: {type: $(this).val()},
	// 	})
	// 	.done(function(result) 
	// 	{
	// 		$(".employees").html(result.options);
	// 	})
	// 	.fail(function() {
	// 		console.log("error");
	// 	})
	// });



function changeEmployeeType(e){
	var type = $(e).val();
	if(type){
		$('#company_select').empty();
		$('#employee_select').empty();
		$('#employee_select').append($('<option>',{
				                value: '',
				                text : '- Select -'
				           }));
		if(type == '1'){
			$("#company_select_div").show();
			getCompanies();
		}else{
			$("#company_select_div").hide();
			getEmployees();
		}
    }
}

function  changeCompany(e) {
	var com = $(e).val();
	getEmployees(com);
}

function getCompanies() {
	$.ajax({
            url: '/get_companies',
            type: 'GET',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            
        })
        .done(function(response) 
        {
        	$('#company_select').empty();
        	if(response.status){
        		
        		var res = response.result;
        		$('#company_select').append($('<option>',{
				                value: '',
				                text : '- Select -'
				           }));
        		if(res.length > 0){
        			$.each(res, function (index, value) {
						  $('#company_select').append($('<option>',{
				                value: value.id,
				                text : value.name
				           }));
					});
        		}

        	}
        })
        .fail(function() {
            console.log("error");
        });
}

function  getEmployees(compId = 0) {
	$.ajax({
            url: '/get_employees',
            type: 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data: {company: compId},
        })
        .done(function(response) 
        {
        	$('#employee_select').empty();
        	if(response.status){
        		$('#employee_select').append($('<option>',{
				                value: '',
				                text : '- Select -'
				           }));
        		var res = response.result;
        		if(res.length > 0){
        			$.each(res, function (index, value) {
						  $('#employee_select').append($('<option>',{
				                value: value.id,
				                text : value.name
				           }));
					});
        		}

        	}
            
        })
        .fail(function() {
            console.log("error");
        });
}

function  deleteLeave(id) {
	
	$.ajax({
            url: '/delete_leave',
            type: 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data: {leave_id: id},
            
        })
        .done(function(response) 
        {
        	
        	if(response.status){
        		
        		location.reload();

        	}
        })
        .fail(function() {
            console.log("error");
        });
}

function  DeactivateResource(id) {
    
    $.ajax({
            url: '/deactivate_resource',
            type: 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data: {resourceId: id},
            
        })
        .done(function(response) 
        {
            debugger;
            if(response.status){
                
                location.reload();

            }
        })
        .fail(function() {
            console.log("error");
        });
}
</script>