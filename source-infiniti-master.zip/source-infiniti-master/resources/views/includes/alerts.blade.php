<div>     
  @if ($errors->any())
  <div class="alert-danger alert">
   @foreach ($errors->all() as $error)
   <div class="text-danger">{{$error}}</div> 
   @endforeach
 </div>
 @endif

 @if (Session::has('error'))
 <div class="alert-danger alert"> <div class="text-danger">{!! session('error') !!} </div> </div>
 @endif

 @if (Session::has('success'))
 <div class="alert-success alert"> <div class="text-success">{!! session('success') !!} </div> </div>
 @endif

  @if (Session::has('info'))
 <div class="alert-info alert"> <div class="text-info">{!! session('info') !!} </div> </div>
 @endif


</div>
