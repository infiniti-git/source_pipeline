<option value="">- Select -</option>
@if(!empty($employees))
  @foreach($employees as $value)
    <option value="{{ $value->id }}">{{ $value->name }}</option>
  @endforeach
@endif