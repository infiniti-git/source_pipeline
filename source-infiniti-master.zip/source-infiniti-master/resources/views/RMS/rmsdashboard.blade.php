@include('includes.header')
<div id="page-wrapper">
<div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Job Dashboard</h2>
            <div class="fa-pull-right"><a href="{{ route('job.create') }}" class="btn btn-success pull-right btn-sm">&nbsp;Create Job</a></div> 
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="clearfix"></div><br/>
     @include('includes.alerts')
              @if (session()->has('success'))
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    {{ session('success') }}
                </div>
              @endif
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>#</th>  
                      <th>Job Reference</th>
                      <th>Date Created</th>
                      <th>Job Title</th>
                      @if($jobStatus->count() > 0)
                        @foreach($jobStatus as $status)
                          <th >{{ ucfirst(strtolower($status->status)) }}</th>
                        @endforeach
                      @endif
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    @php 
                      $i = $jobs->perPage() * ($jobs->currentPage() - 1);
                      $i++;
                    @endphp
                    @if($jobs->count() > 0)
                      @foreach($jobs as $job)
                        <tr>
                          <td>{{ $i }}</td>
                          <td><a href="{{ route('job.dashboard',['jobid'=>$job->id]) }}">{{ $job->job_reference }}</a></td>
                          <td>{{ date('Y-m-d',strtotime($job->created_at)) }}</td>
                          <td><a href="{{ route('job.dashboard',['jobid'=>$job->id]) }}">{{ $job->job_title }}</a></td>
                          @if($jobStatus->count() > 0)
                            @php
                              $app = $job->applications->groupBy('application_status');
                            @endphp
                            @foreach($jobStatus as $status)
                              @if(isset($app[$status->id]))
                                @php
                                  $app_count = $app[$status->id]->count();
                                @endphp
                                @if($app_count > 0)
                                  <td><a href="{{ route('job.dashboard',['jobid'=>$job->id,'filter_status'=>$status->id]) }}">{{ $app_count }}</a></td>
                                @else
                                  <td>{{ $app_count }}</td>
                                @endif
                              @else
                                <td>0</td>
                              @endif
                            @endforeach
                          @endif
                          <td>
                            <a title="Get Job Link" data-toggle="tooltip" data-placement="bottom" data-link="{{ route('job.show',['job_reference'=>$job->job_reference]) }}" class="btn btn-sm btn-primary get-job-link" href="javascript:void(0)"><i class="fa fa-link"></i></a>
                            <a title="Delete Job" data-toggle="tooltip" data-placement="bottom" data-job="{{ $job->id }}" class="btn btn-sm btn-danger btn-delete-job" href="javascript:void(0)"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        @php $i++ @endphp  
                      @endforeach
                    @else
                      <tr>
                        <th colspan="10" class="text-center">No Jobs Posted Yet!</th>
                      </tr>
                    @endif
                  </tbody>
                </table>
              </div>
              <div style="text-align: center;">
                  {{ $jobs->links() }}
                </div>

     
        <!-- /.container-fluid -->
</div>

@include('includes/footer')

  <script type="text/javascript">
   
     $(document).ready(function(){
      $(".get-job-link").on("click", function(){
          var link_text = $(this).attr("data-link");
          $.alert({
              //columnClass: 'col-md-6',
              title: 'Job Link',
              content: link_text,
          });
      });

      $('.btn-delete-job').on('click', function(){
        var jobid = $(this).attr("data-job");
        var thisObj = $(this);
        $.confirm({
          title: 'Confirm!',
          content: 'Are you sure to delete this job?',
          buttons: {
                yes: function () {
                  $.ajax({
                    url:"{{ route('job.delete') }}",
                    type:'POST',
                    data:{_token:"{{ csrf_token() }}",job_id:jobid},
                    success:function(result){
                        if(result.status == 'success'){
                            $(thisObj).closest('tr').remove();
                        }else{
                            $.alert(result.message);
                        }
                    },
                    error:function(xhr,err){
                      $.alert(err);
                    }
                  });
                },
                no: function () {
                  //return false;
                },
            }
          });
        });
    });
  </script>
