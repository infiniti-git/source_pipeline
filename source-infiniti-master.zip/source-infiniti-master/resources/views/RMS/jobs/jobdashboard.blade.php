@include('includes.header')
<div id="page-wrapper">
<div class="row">
        <div class="col-lg-12"> 
            <h2 class="page-header">Detailed Job Dashboard</h2>
            <div class="fa-pull-right"><a href="{{route('job.home')}}" class="btn btn-success  btn-sm "> Back </a></div>
        </div>
        <!-- /.col-lg-12 -->
    </div>
        
              @if (session()->has('success'))
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    {{ session('success') }}
                </div>
              @endif
              <div class="row">
                <label class="col-md-3"><strong>Job Reference : </strong>{{ $job->job_reference }}</label>
                <label class="col-md-3"><strong>Job Title : </strong>{{ $job->job_title }}</label>
              </div>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th width="5%">Resume</th>
                        @if($job->questions->count() > 0)
                            @foreach($job->questions as $eachQues)
                                <th>{{ $eachQues->question_title }}</th>
                            @endforeach
                        @endif
                      <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                        @php 
                            $i = $applications->perPage() * ($applications->currentPage() - 1);
                            $i++;
                        @endphp
                        @if($applications->count() > 0)
                            @foreach($applications as $eachapp)
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $eachapp->applicant_name }}</td>
                                    <td>
                                        @php
                                            $application_id = $eachapp->id;
                                            $job_id = $eachapp->jobs_id;
                                            $file_name = $eachapp->resume_file_name;    
                                            $file_path = storage_path("app".DIRECTORY_SEPARATOR."application_path".DIRECTORY_SEPARATOR.$job_id.DIRECTORY_SEPARATOR.$application_id.DIRECTORY_SEPARATOR.$file_name);
                                        @endphp
                                        @if($eachapp->resume_file_name != '' && File::exists($file_path))
                                            <a title="Download attached file" target="_blank" data-toggle="tooltip" data-placement="bottom" data-job="{{ $eachapp->jobs_id }}" data-application="{{ $eachapp->id }}" class="btn btn-sm btn-info btn-download-application" href="{{ route('job.application.downloadfile',['appid'=>$eachapp->id]) }}"><i class="fa fa-download"></i></a>
                                        @else
                                            N/A
                                        @endif
                                    </td>
                                    @if($job->questions->count() > 0)
                                        @php
                                            $answers = $eachapp->answers->keyBy('questions_id');
                                        @endphp
                                        @foreach($job->questions as $eachQues)
                                            @if(isset($answers[$eachQues->id]))
                                                <td>{{ $answers[$eachQues->id]->answer }}</td>
                                            @else
                                                <td>{{ '-' }}</td>
                                            @endif
                                        @endforeach
                                    @endif
                                    <td>
                                        {{ Form::select('select_application_status', $status_array, $eachapp->application_status, array('class'=>'form-control input-sm select_application_status', 'data-application'=>$eachapp->id)) }}
                                    </td>
                                </tr>
                                @php $i++ @endphp
                            @endforeach
                        @else
                            <tr><td colspan="{{ $job->questions->count() + 3 }}" style="text-align: center;">No Application Found!</td></tr>
                        @endif
                    </tbody>
                </table>
              </div>
              <div style="text-align: center;">

                </div>
            
        <!-- /.container-fluid -->
    </div>
@include('includes.footer')

<script type="text/javascript">
    $(document).ready(function(){
        $(".select_application_status").on("change", function(){
            var app_id = $(this).attr('data-application');
            var status = $(this).val();
            $.ajax({
                url:"{{ route('jobs.application.updatestatus') }}",
                type:'POST',
                data:{_token:"{{ csrf_token() }}",application_id:app_id,status_id:status},
                status:function(){

                },error:function(xhr,err){
                    $.alert({
                        title: 'Error!',
                        content: err,
                    });
                }
            });
        });
    });
</script>
