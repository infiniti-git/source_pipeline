@extends('RMS.include.publicmain')

@section('maincontent')

		<div class="container-fluid">
			<!-- DataTables Example -->
            <div class="row">
                <div class="col-md-3">&nbsp;</div>
                <div class="col-md-6">
                    @if (session()->has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {{ session('success') }}
                        </div>
                      @endif
                    <div class="card-body" style="border:1px solid #BBB"> 
                        <div class="form-group row">
                            <label class="col-md-3 text-right"><strong>Job Reference</strong></label>
                            <div class="col-md-6">{{ $job->job_reference }}</div>
                        </div>  
                        <hr>
                        <div class="form-group row">
                            <label class="col-md-3 text-right"><strong>Job Title</strong></label>
                            <div class="col-md-6">{{ $job->job_title }}</div>
                        </div> 
                        <hr>
                        <div class="form-group row">
                            <label class="col-md-3 text-right"><strong>Description</strong></label>
                            <div class="col-md-6">{!! nl2br($job->description) !!}</div>
                        </div>
 
                        <div class="text-center" >
                           @if($done != 'Y')
                                <a href="{{ route('job.apply',['job_reference'=>$job->job_reference]) }}" class="btn btn-primary" name="apply_job" type="submit">Apply</a> 
                            @endif
                        </div>
                         
                    </div>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
		</div>
		<!-- /.container-fluid -->
@endsection