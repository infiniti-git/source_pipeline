@include('includes.header')
<div id="page-wrapper">
<div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Create Job</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
        <div class="clearfix"></div><br/>
            @if ($errors->any())
                <div class="alert alert-danger alert-dismissable" style="margin: 5px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
             <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
              <form method="POST" action="{{ route('job.store') }}">
                {!! csrf_field() !!}
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="form-group row">
                  <label class="col-md-3 text-right" for="job_title">Job Title</label>
                  <div class="col-md-6">
                    <input name="job_title" type="text" id="job_title" class="form-control" placeholder="Job Title" required="required" autofocus="autofocus" maxlength="20">                    
                  </div>
                </div>  
                <div class="form-group row">
                  <label class="col-md-3 text-right" for="job_description">Job Description</label>
                  <div class="col-md-6">
                    <textarea name="job_description" id="job_description" class="form-control" placeholder="Job Description" required="required"></textarea>
                  </div>
                </div>

                <div class="form-group row">
                    <label class="col-md-3 text-right" for="job_description">Screening Questions</label>
                    <div class="col-md-8" style="padding-left: 0px;">
                        <div class="screening_questions_area"> 
                        @if(count($standard_questions) > 0)
                            @foreach($standard_questions as $each_question)
                                <label class="col-md-5 checkbox-inline"><input name="standard_questions[]" type="checkbox" value="{{ $each_question->id }}">&nbsp;{{ $each_question->question }}</label>                      
                            @endforeach
                        @endif
                        </div>
                        <div class="col-md-12">
                            <div id="new_question_area" style="display: none"></div>

                            <div class="row">
                                <div class="col-md-12 screening_message" style="display: none;"><p style="margin-bottom:0px;"></p></div>
                                <div class="col-md-4">
                                    <a href="javascript:void(0)" class="btn btn-sm btn-primary" id="add_screen_questions" style="display: block"><i class="fa fa-plus"></i>&nbsp;Add New Questions</a>
                                </div>
                                <div class="col-md-3">
                                    <a href="javascript:void(0)" id="btn_save_screening_question" class="btn btn-sm btn-info" style="display: none">Save Questions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center" >
                  <button class="btn btn-success" name="publish_job" type="submit">Publish Job</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
</div>
 </div>       
@include('includes/footer')

    <script type="text/javascript">
        var STORE_QUESTION_ROUTE = "{{ route('question.store') }}";
    </script>
    <script src="{{ asset('js/createjobs.js') }}"></script>
