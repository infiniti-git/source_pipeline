@extends('RMS.include.publicmain')

@section('maincontent')
<style type="text/css">
    .alert ul{
        margin-bottom: 0px;
    }
</style>
        <div class="container-fluid">
            <!-- DataTables Example -->
            <div class="row">
                <div class="col-md-2">&nbsp;</div>
                <div class="col-md-8">
                    <a href="{{ route('job.show',['job_reference'=>$job->job_reference]) }}">View Job Post</a>
                    <div class="card-body" style="border: 1px solid #BBB">
                        @if ($errors->any())
                            <div class="alert alert-danger alert-dismissable" style="margin: 5px;">
                                <strong>Error!</strong>
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <div class="form-group row" style="font-weight: bold">
                            <label class="col-md-4 text-right">Job Title</label>
                            <div class="col-md-6">
                                {{ $job->job_title }}
                            </div>
                        </div>
                        {{ Form::open(array('route' => 'job.submitapplication','method'=>'POST','files'=>'true')) }}
                            <input type="hidden" name="job_reference" value="{{ $job->job_reference }}">
                            <div class="form-group row">
                                <label class="col-md-4 text-right">Name <span class="required">*</span></label>
                                <div class="col-md-7">
                                    <input name="candidate_name" type="text" value="{{ old('candidate_name') }}" class="form-control" placeholder="Provide your name" required="required" autofocus="autofocus" maxlength="30">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-4 text-right">Location <span class="required">*</span></label>
                                <div class="col-md-7">
                                    <input name="candidate_location" type="text" value="{{ old('candidate_location') }}" class="form-control" placeholder="Provide your location" required="required" maxlength="30">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-4 text-right">Resume/Cover Letter/CV</label>
                                <div class="col-md-7">
                                    <input name="candidate_resume" type="file" required="required">
                                    <span class="required" style="display: block; font-size: 12px;">(only doc,docx & pdf files are allowed)</span>
                                </div>
                            </div>
                            @if(count($standard_questions) > 0)
                                <hr>
                                @foreach($standard_questions as $each_question)
                                    <div class="form-group row">
                                        <label class="col-md-4 text-right">{{ $each_question->question }} <span class="required">*</span></label>
                                        <div class="col-md-7">
                                            <input name="standard_question_answers[{{ $each_question->id }}]" type="text" value="{{ old('standard_question_answers')[$each_question->id] }}" id="job_title" class="form-control" placeholder="Provide answer" required="required" autofocus="autofocus" maxlength="50">
                                        </div>
                                    </div>
                                @endforeach
                            @endif

                            <div class="form-group row">
                                <label class="col-md-4 text-right">&nbsp;</label>
                                <div class="col-md-7">
                                    @captcha
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-4 text-right">Please enter this code</label>
                                <div class="col-md-7">
                                    <input name="captcha" type="text" class="form-control" placeholder="Provide code" required="required" maxlength="5">
                                </div>
                            </div>
                    
                            <div class="text-center" >
                                <button class="btn btn-primary" name="submit_application" type="submit">Submit Application</button>
                            </div>
                        {{ Form::close() }}
                    </div>        
                </div>
                <div class="col-md-2">&nbsp;</div>
            </div>
        </div>
        <!-- /.container-fluid -->
  @endsection
