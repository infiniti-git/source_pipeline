@extends('include.publicmain')

@section('maincontent')

		<div class="container-fluid">
			<!-- DataTables Example -->
            <div class="row">
                <div class="col-md-3">&nbsp;</div>
                <div class="col-md-6">
                    <div class="card-body text-center" style="border:1px solid"> 
                        <h3>Invalid Request!</h3>
                        @if(isset($message))
                        <p>{!! $message !!}</p>
                        @endif
                    </div>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
		</div>
		<!-- /.container-fluid -->
@endsection