@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Upload E-hour</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    @include('includes.alerts')  
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
 
          <div class="panel-body"> 
          <div class="row">
             <div class="col-xs-12 col-sm-12 col-md-12">
               <!--  <a href="{{ route('excel-file',['type'=>'xls']) }}">Download Excel xls</a> |
                <a href="{{ route('excel-file',['type'=>'xlsx']) }}">Download Excel xlsx</a> |
                <a href="{{ route('excel-file',['type'=>'csv']) }}">Download CSV</a>-->
                <label>Note: Upload only xls/xlsx/csv format</label>
              </div> 
              <form role="form" id="ehourForm" class='col-md-3' method="POST" action="/admin/import-csv-excel" enctype="multipart/form-data">
              
                <div class="row">
                   <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                         {{ csrf_field() }}
                            <div class="col-md-9">
                              <input type="file" name="sample_file" id="fileToUpload">
                            
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div><br/>
                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                          <input type="submit" value="Upload" class="btn btn-success btn-sml" name="submit">
                    </div>
                </div>
             </form>
           </div>     
           
         </div>
        </div>
      </div>
    </div>
</div>
@include('includes.footer')
<script>
  $('#ehourForm').validate({ // initialize the plugin
        rules: {
            sample_file: {
                required: true,
                //'sample_file.*' => 'image|mimes:csv,xlsx,xls'
            },
        },
        messages :{
            sample_file : {
                required : 'Please Choose File',
            },
        }
    });
</script>
