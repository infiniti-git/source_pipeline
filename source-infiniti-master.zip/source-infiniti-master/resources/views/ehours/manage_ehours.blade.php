@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Manage E-hours</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
      @include('includes.alerts')
<div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="ManageEhour" method="GET" action="SearchEhour">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>From Date</label>
                                    <input class="form-control dateite" id="ehour_fromdate" name="ehour_fromdate" placeholder="Select Date" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>To Date</label>
                                    <input class="form-control dateite" id="ehour_todate" name="ehour_todate" placeholder="Select Date" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Source</label>
                                    <select name="ehour_source" id="ehour_source" class="form-control employee_type">
                                        <option value=""> All </option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6" id="companydiv" style="display:none">
                                <div class="form-group">
                                    <label>Company</label>
                                    <select name="resource_company" id="resource_company" class="form-control company" disabled="true">
                                        <option value="">- Select -</option>
                                        @foreach($companies as $company)
                                            <option value="{{$company->id}}">{{$company->name}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                             <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Employee</label>
                                    <select name="ehour_employee" id="ehour_employee" class="form-control employees">
                                        <option value="">- Select -</option>
                                         @foreach($employees as $employee)
                                            <option value="{{$employee->id}}">{{$employee->name}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6 pull-right">
                                <div class="form-group pull-right">
                                   <input type="button" onclick="search()" class="btn btn-success" value="Search" />
                                   <a href="" class="btn btn-danger btn-sml">Clear</a>
                                </div>                               
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>

  <table id="datatableehours" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Hours</th>
                <th>Edit</th>
            </tr>
        </thead>
        <tbody class="ehourstable" id="ehourstable">
         <tr><td align="center" colspan="4">No data available in table</td></tr>
        </tbody>
    </table>

@include('includes/footer')


<script type="text/javascript">
    /*$('#datatableehours').validate({ // initialize the plugin
        rules: {
            hrs: {
                required: true,
            }
        },
        messages :{
            hrs : {
                required : 'Please enter e-hour',
            }
        }
    });*/

   $('.dateite').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    }); 
   
   function clear()
   {
        $('#ehour_employee').val('');
        $('#ehour_fromdate').val('');
        $('#ehour_todate').val('');
   }

   function editableTable()
   {
     $('table tr').editable({
        validate: function(value) {
            if($.trim(value) == '') {
            return 'This field is required';
            }
        },
        edit: function(values) {
          $(".edit i", this)
            .removeClass('fa-pencil')
            .addClass('fa-save')
            .attr('title', 'Save');
        },
        save: function(values) {
          $(".edit i", this)
            .removeClass('fa-save')
            .addClass('fa-pencil')
            .attr('title', 'Edit');
            var ehourid = $(this).attr('id');
            var hrs=values.hrs;
           $.ajax({
                url: '/update_ehour',
                type: 'GET',
                data: {id: ehourid, hrs: hrs,_token: "{{ csrf_token() }}"}
            })
            .done(function(result) 
            {
                var a = result;
                $(".alert-success").css("display", "block");
                $(".text-success").html("Ehours update successfully");
            })
            .fail(function() {
                console.log("error");
            })
        },
        cancel: function(values) {
          $(".edit i", this)
            .removeClass('fa-save')
            .addClass('fa-pencil')
            .attr('title', 'Edit');
        }
      });
   }
 
     $(document).ready(function() {
         //$('#datatableehours').DataTable();
        editableTable();
     });

      function search()
      {
        var ehour_employee = $('#ehour_employee').val();
        var ehour_fromdate = $('#ehour_fromdate').val();
        var ehour_todate = $('#ehour_todate').val();
        var resource_company = $('#resource_company').val();
        $.ajax({
                url: '/search_ehour',
                type: 'GET',
                data: {ehour_employee: ehour_employee, ehour_fromdate: ehour_fromdate,ehour_todate:ehour_todate,resource_company:resource_company,_token: "{{ csrf_token() }}"}
            })
            .done(function(result) 
            {
                var ehours = result.ehours;
                $("#ehourstable").html(result);
                /*var table = $('#datatableehours').DataTable({
                    "destroy": true, 
                }); 
                
                oSettings = table.settings();
                table.clear(this);
                for (var i=0; i<result.length; i++)
                {
                  table.fnAddData(oSettings, result[i]);
                }
                oSettings.aiDisplay = oSettings.aiDisplayMaster.slice();
                table.fnDraw();*/

                editableTable();
            })
            .fail(function() {
                console.log("error");
            })
       }

    $( "#ehour_source" ).change(function()   {
        var source = $(this).val();
        if(source =='1')
        {
            $("#companydiv").css("display", "block");
            $("#resource_company").removeAttr('disabled');
        }
        else
        {
            $("#companydiv").css("display", "none");
            $("#resource_company").val('');
            $("#resource_company").attr('disabled','disabled');
        }
    
    });
</script>
@include('includes.scripts')
@include('includes.companychangescripts')