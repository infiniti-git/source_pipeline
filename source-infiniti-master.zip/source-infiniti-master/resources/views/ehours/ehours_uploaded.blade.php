@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
           <div class="col-xs-12 col-sm-12 col-md-12 text-right">
               
         </div>
        </div>
       </div> 
       <div class="clearfix"></div><br/>
    <!-- /.row -->
    @include('includes.alerts')  
    <div class="col-xs-12 col-sm-12 col-md-12 text-right">
     <a href="{{route('admin/import-export-csv-excel')}}" class="btn btn-success  btn-sm "> Back </a>
     <a href="{{route('admin/dashboard')}}" class="btn btn-success btn-sm "> Close </a>
   </div>
   <div class="clearfix"></div><br/>
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
 
          <div class="panel-body"> 
          <div class="row">
             <div class="col-xs-12 col-sm-12 col-md-12">
               <label class="text-danger">Below Employees are not available in db.Please add.Hence hours not updated.</label>
              </div> 
             
                <div class="row">
                   <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                         {{ csrf_field() }}
                            <div class="col-md-9">
                               @if(isset($resources))
                               @php $i = 1 @endphp
                                @foreach($resources as $value)
                                @if($value != 'Grand Total')
                                 <label>{{$value}}</label><br/>
                                @endif
                                @endforeach
                               @endif
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div><br/>
                   
                </div>
           </div>     
           
         </div>
        </div>
      </div>
    </div>
</div>
@include('includes.footer')