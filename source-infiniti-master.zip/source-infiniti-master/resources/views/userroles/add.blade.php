@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add User Role</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input class="form-control" name="resource_name" placeholder="Enter Name" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>E-Mail</label>
                                    <input class="form-control" name="resource_email" placeholder="Enter E-Mail" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Contact</label>
                                    <input class="form-control" name="resource_contact" placeholder="Enter Contact Number" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Skype ID</label>
                                    <input class="form-control" name="resource_skype" placeholder="Enter Skype ID" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Supervisor</label>
                                    <select name="" class="form-control">
                                        <option value="">- Select -</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Source</label>
                                    <select name="" class="form-control">
                                        <option value="">- Select -</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" value="Save" />
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')