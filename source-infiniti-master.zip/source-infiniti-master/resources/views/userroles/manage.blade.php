@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Manage User Roles</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
  <!-- <a href="{{route('admin/add_resource')}}" class="btn btn-success pull-right btn-sm">Add New</a> <div class="clearfix"></div><br/> -->
  <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Super Admin</td>
                <td>Active</td>
                <td>
                    <a href="#" class="btn btn-success btn-sm">Edit</a>
                    <a href="#" class="btn btn-warning btn-sm">Inactive</a>
                    <a href="#" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Admin</td>
                <td>Active</td>
                <td>
                    <a href="#" class="btn btn-success btn-sm">Edit</a>
                    <a href="#" class="btn btn-warning btn-sm">Inactive</a>
                    <a href="#" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <tr>
                <td>3</td>
                <td>Member</td>
                <td>Inactive</td>
                <td>
                    <a href="#" class="btn btn-success btn-sm">Edit</a>
                    <a href="#" class="btn btn-info btn-sm">Active</a>
                    <a href="#" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <tr>
                <td>4</td>
                <td>Lead</td>
                <td>Inactive</td>
                <td>
                    <a href="#" class="btn btn-success btn-sm">Edit</a>
                    <a href="#" class="btn btn-info btn-sm">Active</a>
                    <a href="#" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
        </tbody>
    </table>

@include('includes/footer')


<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>