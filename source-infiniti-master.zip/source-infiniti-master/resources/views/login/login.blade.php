<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Source Infinity</title>

    <!-- Bootstrap Core CSS -->

    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{asset('css/metisMenu.min.css')}}" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{asset('css/sb-admin-2.css')}}" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">

   

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <h2 class="text-center"> SOURCE INFINITI </h2>
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title text-center"> Login</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="loginform" action="{{route('dologin')}}" method="post">
                              {!! csrf_field() !!}
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter e-mail" name="email" type="email" autofocus />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter password" name="password" type="password" />
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" class="btn btn-lg btn-success btn-block" value="Login" />
                            </fieldset>
                        </form>
                    </div>
                    
                </div>
                <div>
                   
                    @if ($errors->any())
                     <div class="alert-danger alert">
                         @foreach ($errors->all() as $error)
                             <div class="text-danger">{{$error}}</div> 
                         @endforeach
                         </div>
                     @endif

                    @if (Session::has('error'))
                     <div class="alert-danger alert"> <div class="text-danger">{!! session('error') !!} </div> </div>
                   @endif
                  
                </div>
            </div>
            
        </div>
    </div>

   

    <!-- jQuery -->
    <script src="{{asset('js/jquery.min.js')}}"></script>

    <script src="{{asset('js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('js/additional-methods.js')}}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{asset('js/bootstrap.min.js')}}"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{asset('js/metisMenu.min.js')}}"></script>

    <!-- Custom Theme JavaScript -->
    <script src="{{asset('js/sb-admin-2.js')}}"></script>

    <script type="text/javascript">
        $(".alert").fadeOut(10000);
        $('#loginform').validate({ // initialize the plugin
        rules: {
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
            }
        },
        messages :{
            email : {
                required : 'Please enter username',
                email:"Please give valid e-mail"
            },
            password : {
                required : 'Please enter password',
            },
        }
    });
    </script>
</body>

</html>
