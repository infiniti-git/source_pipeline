

    <style type="text/css">
        @page {
            margin: 0px;
        }
        body {
            margin: 0px;
        }
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        a {
            color: #fff;
            text-decoration: none;
        }
        table {
            font-size: small;
        }
        tfoot tr td {
            font-weight: bold;
            font-size: medium;
        }
       .invoice table {
            width: 50%;
        }
        .invoice h3 {
            margin-left: 15px;
        }
        .invoice h6 {
            margin-left: 15px;
        }
        .information {
            background-color: #60A7A6;
            color: #FFF;
        }
        .information .logo {
            margin: 5px;
        }
        
        .invoicediv{
            font-size: small;
        }
        hr{
          border: 1px solid black;
        }
    </style>



<div class="information">
    
    <table width="100%">
        <tr>
            <td align="left" style="width: 20%;">
                <?php $image_path = '/images/logo.png'; ?>
            <img src="{{ public_path() . $image_path }}" alt="Logo" class="logo"/>
            </td>
            <td align="center" style="width: 50%;">
                
            </td>
            <td  style="width: 30%;">
                <h3>Nilacharal Ltd</h3>
                <h4>
                    18 Collingwood Road<br/>
                    Crawley<br/>
                    RH10 7WG<br/>
                    www.nilacharal.com
                </h4>
                
            </td>
        </tr>

    </table>
</div>


<br/>

<div class="invoice" align="center" >
 @foreach($payrollreport as $value)
    <h3 align="center" style="width:90%">Invoice of {{ $value->payrollmonth}}/{{ $value->year}}</h3>
    <div width="100%" style="width:100% !important;padding: 30px;text-align:center;" class="invoicediv">
        <div>
            <div align="left">
              Name : {{ $value->employeename}}
            </div>
            <div align="right">
                Invoice Date: {{ date('d-m-Y') }}
            </div>
        </div>
        <div>
            <div align="left">
               DOJ: {{date('d-m-Y',strtotime($value->joineddate))}}
            </div>
           
        </div>
    </div>
    <table width="90%"align="center">
       
            <tr>
                <td>No. of days worked : </td>
                <td>{{ $value->source_workingday}}</td>
            </tr>
            <tr>
                <td>No. of Leave Taken : </td>
                <td>{{ $value->leavetaken}}</td>
            </tr>
            <tr><td colspan="2"></td></tr>
            <tr><td colspan="2"></td></tr>
            <tr><td colspan="2"><br/></td></tr>
            <tr>
                <td>Salary :</td>
                <td>Rs. {{ $value->basicpay}}</td>
            </tr>
            @if($value->isloyaltyapplicable == 1)
            <tr>
                <td>Loyalty Bonus :</td>
                <td>Rs. {{ $value->loyaltybonus}}</td>
            </tr>
             @endif
           
            <tr>
                <td>Reimbursment : </td>
                <td>Rs. {{ $value->reimbursment}}</td>
            </tr>
            
            <tr>
                <td>Incentive : </td>
                <td>Rs. {{ $value->incentiveamount}}</td>
            </tr>
           
            <tr>
                <td>Leave Cash/ Encash(CL:{{$value->cl_leave}}/CompOff:{{$value->compoff_leave}}) : </td>
                <td>Rs. {{ $value->leaveencashamount}}</td>
            </tr>
            <tr><td colspan="2"><br/><div style="border:1px solid black;"></div></td></tr>
            <tr style="font-weight: bold;">
                <td><h4>Total Salary : </h4></td>
                <td><h4>Rs. {{ $value->totalpay}}</h4></td>
            </tr>
                
        
    </table>
 @endforeach
</div>
  
<div class="information" style="position: absolute; bottom: 0;">
    <table width="100%">
        <tr>
            <td align="left" style="width: 50%;">
                &copy; {{ date('Y') }} {{ config('app.url') }} - All rights reserved.
            </td>
            <td align="right" style="width: 50%;">
                
            </td>
        </tr>

    </table>
</div>