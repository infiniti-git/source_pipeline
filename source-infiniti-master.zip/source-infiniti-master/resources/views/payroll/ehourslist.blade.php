<div class="col-md-12">
    <h4>eHour lists</h4>
<table id="dataTablesexample" class="table table-striped table-bordered table-hover" >
    <thead>
        <tr>
            <th>S.No</th>
            <th>Date(Y-m-d)</th>
            <th>Hours</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody id="emp_Payroll_details">
    @if(isset($ehours) && count($ehours)>0)
    @php 
        $i=1;
    @endphp
    @foreach($ehours as $ehour)
      <tr id="{{$ehour->id}}">
        <td>{{$i++}}</td>  
        <td>{{$ehour->ehour_date}}</td>
        <td data-field="hrs">{{$ehour->hrs}}</td>
        <td>
            <a class="button button-small edit" title="Edit">
              <i class="fa fa-pencil"></i>
            </a>
           <!--   <a data-toggle="modal" href="#" data-target="#myModal" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a>
            <a data-toggle="modal" href="#" data-target="#myModal" class="btn btn-xs btn-success" title="Save"><i class="fa fa-save"></i></a>-->
        </td>
    </tr>  
    @endforeach
    @else
        <tr><td align="center" colspan="7">No data available in table</td></tr>
    @endif
    </tbody>
</table>
</div>
<script type="text/javascript">
    $('table tr').editable({
        edit: function(values) {
          $(".edit i", this)
            .removeClass('fa-pencil')
            .addClass('fa-save')
            .attr('title', 'Save');
        },
        save: function(values) {
          $(".edit i", this)
            .removeClass('fa-save')
            .addClass('fa-pencil')
            .attr('title', 'Edit');
            var ehourid = $(this).attr('id');
            var hrs=values.hrs;
            $.ajax({
                url: '/update_ehour',
                type: 'GET',
                data: {id: ehourid, hrs: hrs,_token: "{{ csrf_token() }}"}
            })
            .done(function(result) 
            {
                var a = result;
            })
            .fail(function() {
                console.log("error");
            })
        },
        cancel: function(values) {
          $(".edit i", this)
            .removeClass('fa-save')
            .addClass('fa-pencil')
            .attr('title', 'Edit');
        }
      });
</script>
