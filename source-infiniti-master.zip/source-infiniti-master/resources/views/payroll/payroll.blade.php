@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Payroll Generator</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
@include('includes.alerts')    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="PayrollForm" method="post">
                            {!! csrf_field() !!}
                            <!--<div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Resource Type</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                     <select name="employee_type" class="form-control employee_type">
                                        <option value=""> - Select - </option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>-->
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Employee</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <select name="employee" class="form-control employees">
                                        <option value=""> - Select - </option>
                                        @foreach($employees as $employee)
                                            <option value="{{$employee->id}}">{{$employee->name}}</option>
                                        @endforeach
                                        <option value="0"> All </option>
                                    </select>
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Month/Year</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                     <input type="text" class="form-control monthyear"  id="select_month" name="monthyear" placeholder="Select Month/Year" readonly="true" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-md-5 text-right">
                                <input type="button" onclick="gettingpayrollresources()" class="btn btn-success btn-sml" value="Submit"/>
                                <a href=" " class="btn btn-danger btn-sml">Reset</a>
                            </div>
                           </form>
                    </div>
                    <div class="clearfix"></div><br/>
                    <div class="clearfix">
                        <table id="dataTablesexample" class="table table-striped table-bordered table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Employee</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>In App Days</th>
                                    <th>eHour Days</th>
                                    <th>Ready</th>
                                    <th>Action</th>
                                    <th>Note</th>
                                    <th>Link</th>
                                </tr>
                            </thead>
                            <tbody id="emp_Payroll_details">
                                <tr><td align="center" colspan="10">No data available in table</td></tr>
                            </tbody>
                        </table>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('includes.footer')
<script>
 $(document).ready(function() {
        $('#select_month').datepicker({
            autoclose: true,
            minViewMode: 1,
            format: 'mm/yyyy'
        }).on('changeDate', function(e) {
            $("#emp_Payroll_details").html('<tr><td align="center" colspan="10">No data available in table</td></tr>');
        });
       
 });

$('#PayrollForm').validate({ // initialize the plugin
        rules: {
            employee: {
                required: true,
            },
            compoff_date: {
                required: true,
            },
            monthyear: {
                required: true,
            },
        },
        messages :{
            employee : {
                required : 'Please select Employee',
            },
            compoff_date : {
                required : 'Please select Date',
            },
            monthyear : {
                required : 'Please select Month and Year',
            },
        }
    });

 
 $(".employees").change(function(event) 
    {
         $("#emp_Payroll_details").html('<tr><td align="center" colspan="10">No data available in table</td></tr>');
    });

   function gettingpayrollresources()
   {
        if($('#PayrollForm').valid())
        {
            var emp_id = $(".employees").val();
            //var resource_type = $(".employee_type").val();
            var monthyear = $(".monthyear").val();
            $.ajax({
                url: '/calculate_payroll',
                type: 'GET',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data:{emp_id :emp_id,monthyear:monthyear},
            })
            .done(function(result) 
            {
                $("#emp_Payroll_details").html(result);
                //$('#dataTablesexample').DataTable();
            })
            .fail(function() {
                console.log("error");
            })
        }
    }

    /*function applying_leave()
   {
        if($('#add_resource_leave').valid())
        {
            var emp_id = $(".employees").val();
            var employee_leave_dates = $("#employee_leave_dates").val();
            var leave_type = $("#leave_type").val();
            var day_type = $("#day_type").val();
            $.ajax({
                url: '/payroll_applying_leave',
                type: 'GET',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data:{employee :emp_id,employee_leave_dates:employee_leave_dates,leave_type:leave_type,day_type:day_type,ispayroll:true},
            })
            .done(function(result) 
            {
                debugger;
                var a = result;
            })
            .fail(function() {
                console.log("error");
            })
        }
    }*/

 
</script>

