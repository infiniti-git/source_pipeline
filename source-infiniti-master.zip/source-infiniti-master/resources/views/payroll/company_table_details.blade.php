
<input type="hidden" id="isforce_generate" name="isforce_generate" value="{{$force_generate}}"/>
@if(isset($payrolldetails['data']) && count($payrolldetails['data'])>0)
@php 
    $i=1;
@endphp
<input type="hidden" name="ispayrollgenerated" id="ispayrollgenerated" value="{{$ispayrollgenerated}}"/>
<input type="hidden" name="invoicelink" id="invoicelink" value="{{$invoicelink}}"/>
@foreach($payrolldetails['data'] as $detail)
  <tr id="{{$detail['empid']}}">
    <!--<td>{{$i++}}</td>-->
    <td>{{$detail['emp_name']}}</td>
    <td class="role">{{$detail['employee_pay']}}</td>
    <td>{{$detail['worked_days']}}</td>
    <td>{{$detail['ehrs_days']}}</td>
    <td data-field="salary" name="salary" class="role salary">
        @if($detail['salary'] != '-')
            {{number_format($detail['salary'],2)}}
        @else
            {{$detail['salary']}}
        @endif
        </td>
    <td data-field="encash" name="encash" class="role encash"> 
        @if($detail['encash'] != '-')
            {{number_format($detail['encash'],2)}}
        @else
            {{$detail['encash']}}
        @endif</td>
    <td data-field="totsalary" name="totsalary" class="role totsalary">
    @if($detail['total_salary'] != '-')
            {{number_format($detail['total_salary'],2)}}
        @else
            {{$detail['total_salary']}}
        @endif</td>
    <td> 
        @if($detail['payroll_status']=='Yes')
            <label class="text-success">Yes</label>
        @else
            <label class="text-danger">No</label>
        @endif
    </td>
    
    <td>
        @if($detail['payroll_status']=='Yes')
            -
        @else
        <label class="text-danger">Correct discrepency Source Vs E-hours data</label>
        @endif        
    </td>
    <td style="display: none;" class="forcegenerate role">
        <a class="button button-small edit" title="Edit">
          <i class="fa fa-pencil"></i>
        </a>
    </td>
</tr>  
@endforeach
@else
    <tr><td align="center" colspan="10">No data available in table</td></tr>
@endif