@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Company Payroll Generator</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
@include('includes.alerts')    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="PayrollForm" method="POST">
                            {!! csrf_field() !!}
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <input type="hidden" id="userrole" name="userrole" value="{{$userrole}}"/>
                                        <!--<input type="hidden" id="isforce_generate" name="isforce_generate" value="{{$force_generate}}"> action="{{ url('/calculate_company_payroll') }}" method="POST"-->
                                        <label>Company</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <select name="company" class="form-control company">
                                        <option value=""> - Select - </option>
                                        @foreach($companies as $company)
                                            <option value="{{$company->id}}">{{$company->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Select Month & Year</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control month"  id="select_month" name="month" placeholder="Select Month/Year" readonly="true" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                          
                            <div class="clearfix"></div><br/>
                            <div class="col-md-5 text-right">
                                <input type="button" onclick="getCompanyPayroll()" class="btn btn-success btn-sml" value="Submit"/>
                                <!--<input type="Submit" class="btn btn-success btn-sml" value="submit"/>-->
                                <a href=" " class="btn btn-danger btn-sml">Reset</a>
                            </div>
                           </form>
                    </div>
                    <div class="clearfix"></div><br/>
                    <div class="col-md-10 text-left">
                        <input type="button" id="generate" onclick="generate()" class="btn btn-success btn-sml" value="Generate" style="display: none;" />
                        <input type="button" id="force_generate" onclick="forceGenerate()" class="btn btn-success btn-sml" value="Force Generate" style="display: none;" />
                    </div>
                    
                    <div class="col-md-2 text-right">
                         <a class="btn btn-primary btn-sml" id="a_viewinvoice" target="_blank" style="display: none;">View Invoice</a>
                     </div>
                    <div class="clearfix"></div><br/>
                    <div class="clearfix">
                        <table id="dataTablesexample" class="table table-striped table-bordered table-hover" style="width:100%">
                            <thead>
                                <tr>
                                   
                                    <th>Name</th>
                                    <th class="role">Employee Pay</th>
                                   <!--  <th>Payroll Status</th> -->
                                    <th>In App Days</th>
                                    <th>Ehrs Days</th>
                                    <th class="role">Salary</th>
                                    <th class="role">Encash</th>
                                    <th class="role" >Total Pay</th>
                                    <th>Ready for Pay</th>
                                    <th>Remarks</th>
                                    <th style="display: none;" class="forcegenerate role">Edit</th>
                                </tr>
                                <!-- <tr>
                                    <th>S.No</th>
                                    <th>Name</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>In App Days</th>
                                    <th>eHour Days</th>
                                    <th>Ready</th>
                                    <th>Action</th>
                                    <th>Note</th>
                                    <th>Link</th>
                                </tr> -->
                            </thead>
                            <tbody id="emp_Payroll_details">
                               @include('payroll.company_table_details')
                               <!-- <tr><td align="center" colspan="7">No data available in table</td></tr>-->
                            </tbody>
                        </table>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('includes.footer')
<script>
function storeTblValues()
{
    var TableData = new Array();

    $('#dataTablesexample tr').each(function(row, tr){
    TableData[row]={
        "Name" : $(tr).find('td:eq(0)').text()
        , "EmployeePay" :$(tr).find('td:eq(1)').text()
        , "InAppDays" : $(tr).find('td:eq(2)').text()
        , "EhrsDays" : $(tr).find('td:eq(3)').text()
        , "Salary" : $(tr).find('td:eq(4)').text()
        , "Encash" : $(tr).find('td:eq(5)').text()
        , "TotalPay" : $(tr).find('td:eq(6)').text()
        , "ReadyforPay" : $(tr).find('td:eq(7)').text()
    }
}); 
    TableData.shift();  // first row will be empty - so remove
    return TableData;
}
function  generate(argument) {
    var month= $(".month").val();
    var company = $(".company").val();
    if(company  != '' && month != ''){
        // var url = '/admin/payroll/generate?company_id='+company+'&month='+month;
        // window.location.href = url;    

        $.ajax({
            url: '/admin/payroll/generate',
            type: 'GET',
            data: {company: company,_token: "{{ csrf_token() }}",month: month},
        })
        .done(function(result) 
        {
            console.log(result);
            console.log(result.status);
            if(result.status){
                window.location.href = '/admin/payroll/company_pay_download?company='+company+'&month='+month;
                setTimeout(function(){// wait for 5 secs(2)
                    location.reload(); // then reload the page.(3)
                }, 5000); 
            }
            // $(".employees").html(result.options);
        })
        .fail(function() {
            console.log("error");
        });


    }
}
function forceGenerate() {
    var TableData;
    TableData = storeTblValues()
    //TableData = $.toJSON(TableData);
    var month= $(".month").val();
    var company = $(".company").val();
    if(company  != '' && month != ''){
        var url = '/admin/payroll/force_generate?company_id='+company+'&month='+month;
        window.location.href = url;    
    }
    
}

function editableTable()
   {
     $('table tr').editable({
        edit: function(values) {
          $(".edit i", this)
            .removeClass('fa-pencil')
            .addClass('fa-save')
            .attr('title', 'Save');
        },
        save: function(values) {
              $(".edit i", this)
                .removeClass('fa-save')
                .addClass('fa-pencil')
                .attr('title', 'Edit');
                var sum = 0;
                var companyId = $(".company").val();
                var monthyear = $(".month").val();
                var empid = $(this).attr('id');
                var salary=values.salary;
                var encash=values.encash;
                var total_salary=values.totsalary;
                var row = $(this).closest('tr');
                //if(validate(row,salary,encash,total_salary))
               //{
                var salamount = salary.replace(/,/g, '');
                var encashamt = encash.replace(/,/g, '');
                sum += parseFloat(salamount);
                sum += parseFloat(encashamt);
                var total_pay=sum.toFixed(2);
                $.ajax({
                    url: '/company_payroll_update',
                    type: 'POST',
                    data: {empid: empid, salary: salary,encash:encash,companyId:companyId,monthyear:monthyear,total_pay:total_pay,_token: function() {
                            return "{{csrf_token()}}"
                          }}
                })
                .done(function(result) 
                {
                    var a = result;
                })
                .fail(function() {
                    console.log("error");
                })
              //}
        },
        cancel: function(values) {
          $(".edit i", this)
            .removeClass('fa-save')
            .addClass('fa-pencil')
            .attr('title', 'Edit');
        }
      });
   }
$(document).ready(function() {
    $('#select_month').datepicker({
            autoclose: true,
            minViewMode: 1,
            format: 'mm/yyyy'
        }).on('changeDate', function(e) {
            $("#emp_Payroll_details").html('<tr><td align="center" colspan="9">No data available in table</td></tr>');
            $("#force_generate").css('display','none');
            $("#generate").css('display','none');
            $(".forcegenerate").css('display','none');
            $("#a_viewinvoice").css('display','none');
        });;
    var userrole =  $('#userrole').val();
    if(userrole == '1')
    {
         $(".role").show();
         $("#force_generate").removeAttr('disabled');
         $("#generate").removeAttr('disabled');
        // $("#encash").css('display','block');
    }
    else
    {
         $(".role").hide();
         $("#force_generate").attr('disabled','disabled');
         $("#generate").attr('disabled','disabled');
    }

      
    /*var force_generate = $("#isforce_generate").val();
    if(force_generate == '1')
    {
        $("#force_generate").css('display','block');
        $("#generate").css('display','none');
        $(".forcegenerate").css('display','none');
    }
    else
    {
        $("#force_generate").css('display','none');
        $("#generate").css('display','block');
        $(".forcegenerate").css('display','block');
        editableTable();
    }*/
});
$(".company").change(function(event) 
{
    $("#emp_Payroll_details").html('<tr><td align="center" colspan="9">No data available in table</td></tr>');
    $("#force_generate").css('display','none');
    $("#generate").css('display','none');
    $(".forcegenerate").css('display','none');
    $("#a_viewinvoice").css('display','none');
});
$('#PayrollForm').validate({ // initialize the plugin
        rules: {
            company: {
                required: true,
            },
            month: {
                required: true,
            },
        },
        messages :{
            employee : {
                required : 'Please select Company',
            },
            month : {
                required : 'Please select month/year',
            },
        }
    });

function enableviewinvoice()
{
     var ispayrollgeneated = $('#ispayrollgenerated').val();
      var invoicelink = $('#invoicelink').val();
      var link = '{{ URL::asset('+$("#invoicelink").val()+') }}';
      if(ispayrollgeneated)
      {
         $('#a_viewinvoice').attr('href','/'+invoicelink);
         $("#a_viewinvoice").removeAttr('disabled');
         $("#a_viewinvoice").css('display','block');
         $("#generate").val('Regenerate');
      }
      else
      {
        $("#a_viewinvoice").css('display','none');
        $('#a_viewinvoice').removeAttr('href');
        $("#a_viewinvoice").attr('disabled','disabled');
        $("#generate").val('Generate');
      }
}

function  getCompanyPayroll() {
    if($('#PayrollForm').valid())
        {
            var emp_id = $(".company").val();
            var month = $(".month").val();
              $.ajax({
                url: '/calculate_company_payroll',
                method: 'POST',
                data:{company_id :emp_id,month:month,_token: function() {
                        return "{{csrf_token()}}"
                      }}
                })  
                .done(function(result) 
                {
                    var a = result;
                     $("#emp_Payroll_details").html(result);
                     var force_generate = $("#isforce_generate").val();
                     var userrole =  $('#userrole').val();
                    if(force_generate == '1'){
                        $("#force_generate").css('display','block');
                        $("#generate").css('display','none');
                        $(".forcegenerate").css('display','none');
                         enableviewinvoice();
                    }
                    else if(force_generate == ''){
                        $("#force_generate").css('display','none');
                        $("#generate").css('display','block');
                        $(".forcegenerate").css('display','block');
                        editableTable();
                        enableviewinvoice();
                    }
                    else
                    {
                        $("#force_generate").css('display','none');
                        $("#generate").css('display','none');
                        $(".forcegenerate").css('display','none');
                        $("#a_viewinvoice").css('display','none');
                    }
                    if(userrole == '1')
                    {
                         $(".role").show();
                         $("#force_generate").removeAttr('disabled');
                         $("#generate").removeAttr('disabled');
                          if(force_generate == '1'){
                            $(".forcegenerate").css('display','none');
                          }
                          else if(force_generate == '')
                          {
                            $(".forcegenerate").css('display','block');
                          }
                          else
                          {
                            $(".forcegenerate").css('display','none');
                          }

                          enableviewinvoice();

                    }
                    else
                    {
                        $(".role").hide();
                        $("#force_generate").attr('disabled','disabled');
                        $("#generate").attr('disabled','disabled');
                        $("#a_viewinvoice").attr('disabled','disabled');
                        $('#a_viewinvoice').removeAttr('href');
                    }
                })
                .fail(function() {
                    console.log("error");
                }) 
        $("#dataTablesexample tbody").on("change", ".amt", function(){
            var row = $(this).closest("tr");
            var salary = row.find(".salary input.amt").val();
            var encash = row.find(".encash input.amt").val();
            var total_salary = row.find(".totsalary input.amt").val();
            if(validate(row,salary,encash,total_salary))
            {
                var sum =0;
                var salamount = salary.replace(/,/g, '');
                var encashamt = encash.replace(/,/g, '');
                sum += parseFloat(salamount);
                sum += parseFloat(encashamt);
                var total_pay=sum.toFixed(2);
                row.find(".totsalary input.amt").val(total_pay);
            }
            
        });
            /*$('#dataTablesexample').DataTable({
            destroy: true,
            processing: true,
            serverSide: true,
            paging:   false,
            info: false,
            sorting: false,
            searching: false,
            ajax: {
                url: '/calculate_company_payroll',
                method: 'GET',
                data:{company_id :emp_id,month:month},
                dataSrc: function ( json ) {
                    //Make your callback here.
                   
                    if(json.force_generate){
                        $("#force_generate").css('display','block');
                        $("#generate").css('display','none');

                    }else{
                        $("#force_generate").css('display','none');
                        $("#generate").css('display','block');
                    }
                    return json.data;
                }       
            },


          columns: [
                {data: 'emp_name', name: 'name',orderable:false},
                {data: 'employee_pay', name: 'employee_pay',orderable:false},
                {data: 'worked_days', name: 'worked_days',orderable:false},
                {data: 'ehrs_days', name: 'ehrs_days',orderable:false},
                {data: 'salary', name: 'salary',orderable:false},
                {data: 'encash', name: 'encash',orderable:false},
                {data: 'total_salary', name: 'total_salary',orderable:false},
                {data: 'payroll_status', name: 'payroll_status',orderable:false},
                {data: 'remark', name: 'remark',orderable:false},
                
                
            ],
        });*/


//             var table = $("#dataTablesexample").DataTable({
//     ajax: {
//         url: '/calculate_company_payroll',
//         type: 'GET',
//         headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
//         data:{company_id :emp_id,month:month},
//         dataSrc: 'data.result.emp_list'
//     }
//     columns: [
//         { data: 'emp_name' },
//         { data: 'employee_pay' },
//         { data: 'payroll_status' }
       
//     ]
// });
            
            // $.ajax({
            //     url: '/calculate_company_payroll',
            //     type: 'GET',
            //     headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            //     data:{company_id :emp_id,month:month},
            // })
            // .done(function(result) 
            // {
            //     $("#emp_Payroll_details").html(result);
            // })
            // .fail(function() {
            //     console.log("error");
            // })
        }
    // body...
}
 /*$('#add_resource_leave').validate({ // initialize the plugin
        rules: {
            employee: {
                required: true,
            },
            employee_leave_dates: {
                required: true,
            },
            leave_type:{
                required: true,
            },
            day_type: {
                required: true,
            },
        },
        messages :{
            employee : {
                required : 'Please select Employee',
            },
            employee_leave_dates : {
                required : 'Please select Leave Date',
            },
            leave_type : {
                required : 'Please select Leave Type',
            },
            day_type : {
                required : 'Please select Day Type',
            },
        }
    });*/
    function validate(row,salary,encash,totsalary)
    {
        var result = true;
        if(salary == '')
        {
            row.find(".salary label[for='error']").css('display','block').text('Salary is required');
            result = false;
        }
        else
        {
            row.find(".salary label[for='error']").css('display','none');
        }
        if(encash == '')
        {
            row.find(".encash label[for='error']").css('display','block').text('Encash amount should not be empty');
             result = false;
        }
        else
        {
            row.find(".encash label[for='error']").css('display','none');
        }
        if(totsalary == '')
        {
            row.find(".totsalary label[for='error']").css('display','block').text('Total Salary amount should not be empty');
             result = false;
        }
        else
        {
            row.find(".totsalary label[for='error']").css('display','none');
        }
        return result;
    }

    $(".employee_type").change(function(event) 
    {
        $.ajax({
            url: '/get_employee',
            type: 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data: {type: $(this).val()},
        })
        .done(function(result) 
        {
            $(".employees").html(result.options);
            if(result.emplength>1)
            {
                $('.employees').append($('<option>',{
                    value: 0,
                    text : 'All'
                }));
            }
        })
        .fail(function() {
            console.log("error");
        })
    });



   //$('#dataTablesexample').DataTable();

   function gettingpayrollresources()
   {
        if($('#PayrollForm').valid())
        {
            var emp_id = $(".employees").val();
            var resource_type = $(".employee_type").val();
            var month = $(".month").val();
            var year = $(".year").val();
            $.ajax({
                url: '/calculate_payroll',
                type: 'GET',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data:{emp_id :emp_id,resource_type:resource_type,month:month,year:year},
            })
            .done(function(result) 
            {
                $("#emp_Payroll_details").html(result);
            })
            .fail(function() {
                console.log("error");
            })
        }
    }

 
</script>

