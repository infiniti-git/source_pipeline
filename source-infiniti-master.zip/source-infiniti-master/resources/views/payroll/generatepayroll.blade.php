@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Payroll Generator</h2>
        </div>
    </div>
@include('includes.alerts')    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="PayrollForm" action="{{ url('admin/generatedirectpayrollpdf') }}" method="post">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="hidden" name="empid" value="{{$payroll->empid}}">
                                    <input type="hidden" name="month" value="{{$payroll->monthid}}">
                                    <input type="hidden" name="year" value="{{$payroll->year}}">
                                    <label>Name</label>
                                    <input class="form-control" name="payroll_empname" value="{{$payroll->name}}" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Number of WD {{$payroll->month}}/{{$payroll->year}}</label>
                                    <input class="form-control" name="payroll_WDmonth" value="{{$payroll->numberofWD}}" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Number of WD as per source </label>
                                    <input class="form-control" name="payroll_sourceWD" value="{{$payroll->numberofsourceWD}}" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                     <label>Leave Taken</label>
                                     <input class="form-control" name="leavetaken" value="{{$payroll->leavetaken}}" />
                                </div>
                            </div>
                           <!-- <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Number of WD as per source </label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                     <input class="form-control" name="payroll_sourceWD" value="{{$payroll->numberofsourceWD}}" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Leave Taken</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                     <input class="form-control" name="leavetaken" value="{{$payroll->leavetaken}}" />
                                </div>
                            </div>-->
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Salary</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                     <input class="form-control amount" name="payroll_basicsalary" id="payroll_basicsalary" value="{{number_format($payroll->basicsalary,2)}}" />
                                </div>
                            </div>
                           
                                <div class="clearfix <?php echo $payroll->isloyaltybonus == 1 ? 'show' : 'hidden';?>"></div><br/>
                                <div class="col-lg-12 <?php echo $payroll->isloyaltybonus == 1 ? 'show' : 'hidden';?>">
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Loyalty Bonus</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <input class="form-control" name="payroll_loyaltybonus" id="payroll_loyaltybonus" value="{{number_format($payroll->loyaltybonus,2)}}" />
                                    </div>
                                </div>
                            <div class="clearfix <?php echo $payroll->isloyaltybonus == 1 ? 'show' : 'hidden';?>"></div><br/>
                            <div class="col-lg-12 <?php echo $payroll->isloyaltybonus == 1 ? 'show' : 'hidden';?>">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Loyalty Bonus Applicable for this month</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input type="radio" id="yes" value="1" name="loyaltyyesno" class="loyaltyyesno"/>
                                    <label for="yes">Yes</label>  
                                    <input type="radio" id="no" class="loyaltyyesno" value="0" name="loyaltyyesno"/>
                                    <label for="no">No</label>  
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Reimbursment</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control amount" name="payroll_reimbursment" id="payroll_reimbursment" value="{{number_format($payroll->reimbursment,2)}}" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Incentive</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control amount" name="payroll_incentive" id="payroll_incentive" value="{{number_format($payroll->incentiveamount,2)}}" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Leave Cash/ Encash(CL:{{$payroll->availablecl}}/CompOff:{{$payroll->availablecompoff}})</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control amount" name="payroll_leaveencash" id="payroll_leaveencash" value="{{ number_format($payroll->leaveencashamount, 2) }}" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-lg-12">
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label>Total Pay</label>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <input class="form-control" name="payroll_totalpay" id="payroll_totalpay" value="{{ number_format($payroll->totalpay, 2) }}" />
                                </div>
                            </div>
                            <div class="clearfix"></div><br/>
                            <div class="col-md-5 text-right">
                                <input type="submit" class="btn btn-success btn-sml" value="Submit"/>
                            </div>
                           </form>
                    </div>
                    <div class="clearfix"></div><br/>
                   
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')
<script type="text/javascript">
    $("#payroll_reimbursment").change(function(){
        CalculateTotalPay();
    });

    $("#payroll_incentive").change(function(){
        CalculateTotalPay();
    });

    $("#payroll_leaveencash").change(function(){
        CalculateTotalPay();
    });
    
    $("#payroll_basicsalary").change(function(){
        CalculateTotalPay();
    });
    
    function CalculateTotalPay()
    {
         var sum = 0;
         var loyaltyyesno = $('input[name=loyaltyyesno]:checked').val(); 
         var loyaltybonusamount = $("#payroll_loyaltybonus").val().replace(/,/g, '');
            $(".amount").each(function() {
                var amount = this.value.replace(/,/g, '');
                if(!isNaN(amount) && amount.length!=0) {
                    sum += parseFloat(amount);
                }
            });
            if(loyaltyyesno == 1)
            {
                sum += parseFloat(loyaltybonusamount);
            }
         $("#payroll_totalpay").val(sum.toFixed(2));
    }

    $(".loyaltyyesno").click(function(){
        var value = $(this).val();
        if(value==1)
        {
            var sum=0;
            var loyaltybonus = $("#payroll_loyaltybonus").val().replace(/,/g, '');
            var totalpay= $("#payroll_totalpay").val().replace(/,/g, '');
            sum += parseFloat(loyaltybonus);
            sum += parseFloat(totalpay);
            $("#payroll_totalpay").val(sum.toFixed(2));
        }
        else
        {
            var sum = 0;
            $(".amount").each(function() {
                var amount = this.value.replace(/,/g, '');
                if(!isNaN(amount) && amount.length!=0) {
                    sum += parseFloat(amount);
                }
            });
            $("#payroll_totalpay").val(sum.toFixed(2));
        }
    });
</script>