<table width="100%">
        <tr>
            <td align="left" style="width: 20%;">
               <?php $image_path = '/images/logo.png'; ?>
               <img src="{{ public_path() . $image_path }}" alt="Logo" width="64" class="logo"/>
            </td>
            <td align="center" style="width: 40%;">
                
            </td>
            <td align="right" style="width: 40%;">
                 <h3>Nilacharal Ltd</h3>
                <h4>
                    18 Collingwood Road
                    Crawley
                    RH10 7WG
                    Crawley
                    www.nilacharal.com
                </h4>
                
            </td>
        </tr>

</table>
<table>
  <tr>
    <th><td>Company Name: </td> <td>{{$company_name}}</td></th>
  </tr>
  <tr>
    <th><td>Month & Year: </td> <td>{{$month}}/{{$year}}</td></th>
  </tr>
  
</table>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Worked Days</th>
      <th>Basic Pay</th>
      <th>Enhancement</th>
      <th>Total Salary</th>
      <th>Payment Status</th>
    </tr>
  </thead>
  <tbody>

    @foreach($emp_list as $employee)
      <tr>
        <td align="justify">{{ $employee['emp_name'] }}</td>
        <td align="justify">{{ $employee['worked_days'] }}</td>
        <td align="justify">{{ $employee['employee_pay'] }}</td>
        <td align="justify">{{ $employee['encash'] }}</td>
        <td align="justify">{{ $employee['total_salary'] }}</td>
        <td align="justify">{{ $employee['payroll_status'] }}</td>

        
      </tr>
    @endforeach
  </tbody>
</table>


<style type="text/css">
        @page {
            margin: 0px;
        }
        body {
            margin: 0px;
        }
        * {
            font-family: Verdana, Arial, sans-serif;
        }
        a {
            color: #fff;
            text-decoration: none;
        }
        table {
            font-size: x-small;
        }
        tfoot tr td {
            font-weight: bold;
            font-size: x-small;
        }
       .invoice table {
            width: 50%;
        }
        .invoice h3 {
            margin-left: 15px;
        }
        .invoice h6 {
            margin-left: 15px;
        }
        .information {
            background-color: #60A7A6;
            color: #FFF;
        }
        .information .logo {
            margin: 5px;
        }
        .information table {
            padding: 10px;
        }
    </style>