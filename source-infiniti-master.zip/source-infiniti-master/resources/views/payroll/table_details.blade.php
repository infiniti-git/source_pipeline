@if(isset($over_details) && count($over_details)>0)
@php 
    $i=1;
@endphp
@foreach($over_details as $detail)
  <tr>
    <td>{{$i++}}</td>
    <td>{{$detail['emp_name']}}</td>
    <td>{{$detail['month']}}</td>
    <td>{{$detail['year']}}</td>
    <td>{{$detail['inapp']}}</td>
    <td>{{$detail['ehour']}}</td>
    <td> 
        @if($detail['ready']==1)
            <label class="text-success">Yes</label>
        @else
            <label class="text-danger">No</label>
        @endif
    </td>
    <td>
        @if($detail['ready']==1 && $detail['isppayrollgenerated'] == false && $detail['role']==1)
            <a href="{{route('admin/generatepayroll',['empid'=>$detail['empid'],'noofWD'=>$detail['inapp'],'noofehourdays'=>$detail['ehour'],'month'=>$detail['month'],'year'=>$detail['year']])}}" class="btn btn-primary btn-xs"> Generate </a>
        @elseif($detail['ready']==1 && $detail['isppayrollgenerated'] == true && $detail['role']==1)
            <a href="{{route('admin/generatepayroll',['empid'=>$detail['empid'],'noofWD'=>$detail['inapp'],'noofehourdays'=>$detail['ehour'],'month'=>$detail['month'],'year'=>$detail['year']])}}" class="btn btn-success btn-xs"> ReGenerate </a>
        @elseif($detail['ready']==1 && $detail['isppayrollgenerated'] == true && $detail['role']!=1)
            <a class="btn btn-success btn-xs" title="do not have access" disabled> ReGenerate </a>
        @else
            <a class="btn btn-primary btn-xs" title="do not have access" disabled> Generate </a>
        @endif        
    </td>
    <td>
        @if($detail['ready']==1)
            -
        @else
        <label class="text-danger">Correct discrepency Source Vs E-hours data</label>
            
        @endif        
    </td>
    <td>
        @if($detail['invoicelink']!="#" && $detail['ready']==1 && $detail['role']==1)
           <a href="{{asset($detail['invoicelink'])}}" class="btn btn-primary btn-xs" target="_blank">View Invoice</a>
        @elseif($detail['invoicelink']!="#" && $detail['ready']==1 && $detail['role']!=1)
            <a  title="do not have access" class="btn btn-primary btn-xs" target="_blank" disabled>View Invoice</a>
        @else
            -
        @endif   
    </td>
</tr>  
@endforeach
@else
    <tr><td align="center" colspan="10">No data available in table</td></tr>
@endif
