@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add Resource</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    @include('includes.alerts') 
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="AddResource" action="add_new_resource" method="post">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="hidden" name="userrole" id="userrole" value="{{$userrole}}">
                                    <label>Name</label>
                                    <input class="form-control" name="resource_name" placeholder="Enter Name"  />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>E-Mail</label>
                                    <input class="form-control" name="resource_email" placeholder="Enter E-Mail" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Contact</label>
                                    <input class="form-control" name="resource_contact" placeholder="Enter Contact Number" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Skype ID</label>
                                    <input class="form-control" name="resource_skype" placeholder="Enter Skype ID" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Lead</label>
                                    <select name="resource_supervisor" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($supervisors as $supervisor)
                                            <option value="{{$supervisor->supervisorId}}">{{$supervisor->supervisorName}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Role</label>
                                    <select name="resource_role" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($roles as $role)
                                            <option value="{{$role->id}}">{{$role->name}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Source</label>
                                    <select name="resource_source" id="resource_source" class="form-control">
                                        <option value="">- Select -</option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6" id="companydiv" style="display:none">
                                <div class="form-group">
                                    <label>Company</label>
                                    <select name="resource_company" id="resource_company" disabled="true" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($companies as $company)
                                            <option value="{{$company->id}}">{{$company->name}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Payment Type</label>
                                    <select name="resource_paymenttype" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($paymenttypes as $paymenttype)
                                            <option value="{{$paymenttype->id}}">{{$paymenttype->payment_type}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Hours Type</label>
                                    <select name="resource_hourstype" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($hourstypes as $hourstype)
                                            <option value="{{$hourstype->id}}">{{$hourstype->hours_type}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Team</label>
                                    <select name="resource_team" class="form-control">
                                        <option value="">- Select -</option>
                                        @foreach($teams as $team)
                                            <option value="{{$team->id}}">{{$team->teamname}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Joined Date</label>
                                    <input class="form-control dateite" name="resource_joindate" placeholder="Select Date" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Basic Pay</label>
                                    <input class="form-control userrole"  name="resource_basicpay" placeholder="Enter Basic Pay" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Loyalty Bonus</label>
                                    <select id="resource_isloyaltybonus" name="resource_isloyaltybonus" class="form-control userrole">
                                        <option value="">- Select -</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <textarea name="resource_address" class="form-control"></textarea>
                                </div>                               
                            </div>
                            <div class="col-lg-6" id="loyaltybonusdiv" style="display:none">
                                <div class="form-group">
                                    <label>Loyalty Bonus Amount</label>
                                    <input class="form-control" name="resource_loyaltybonus" id="resource_loyaltybonus" disabled="true" placeholder="Enter Loyalty Bonus" />
                                </div>                               
                            </div>
                            <div class="col-lg-6 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" value="Save" />
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')
<script type="text/javascript">     
    $('.dateite').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
    });  
    $('#AddResource').validate({ // initialize the plugin
        rules: {
            resource_name: {
                required: true,
            },
            resource_email: {
                required: true,
                email: true,
                /*remote:{
                    url:"checkemailalreadyexists",
                    type:"post",
                    data: {
                      _token: function() {
                        return "{{csrf_token()}}"
                      }
                    }
                }*/
            },
            resource_contact: {
                required: true,
                number:true,
            },
            resource_skype: {
                required: true,
            },
            resource_supervisor: {
                required: true,
            },
            resource_source: {
                required: true,
            },
            resource_paymenttype: {
                required: true,
            },
            resource_address: {
                required: true,
            },
            resource_team: {
                required: true,
            },
            resource_joindate: {
                required: true,
            },
            resource_loyaltybonus: {
                required: true,
                max:15000,
                number:true,
            },
            resource_company: {
                required: true 
            },
            resource_role: {
                required: true 
            }
        },
        messages :{
            resource_name : {
                required : 'Please enter Name'
            },
            resource_email : {
                required : 'Please enter Email',
                unique : 'Email Id is already exists',
            },
            resource_contact: {
                required: 'Please enter Contact Number'
            },
            resource_skype: {
                required: 'Please enter Skype  Id'
            },
            resource_supervisor: {
                required: 'Please select Supervisor'
            },
            resource_source: {
                required: 'Please select Source'
            },
            resource_paymenttype: {
                required: 'Please select Payment'
            },
            resource_address: {
                required: 'Please enter Address'
            },
            resource_team: {
                required: 'Please select Date'
            },
            resource_joindate: {
                required: 'Please select JoinedDate'
            },
            resource_loyaltybonus: {
                required: 'Please enter loyalty bonus'
            },
            resource_company: {
                required: 'Please select Company' 
            },
            resource_role: {
                required: 'Please select user group' 
            }
        }
    });
    $( document ).ready(function() {
        var userrole = $("#userrole").val();
        if(userrole == '1')
        {
            $(".userrole").removeAttr('disabled');
        }
        else
        {
            $(".userrole").attr('disabled','disabled');
        }
    });
    $( "#resource_isloyaltybonus" ).change(function()   {
        var isloyaltybonus = $(this).val();
        if(isloyaltybonus =='1')
        {
            $("#loyaltybonusdiv").css("display", "block");
            $("#resource_loyaltybonus").removeAttr('disabled');
        }
        else
        {
            $("#loyaltybonusdiv").css("display", "none");
            $("#resource_loyaltybonus").val('');
            $("#resource_loyaltybonus").attr('disabled','disabled');
        }

        
    });
    $( "#resource_source" ).change(function()   {
        var source = $(this).val();
        if(source =='1')
        {
            $("#companydiv").css("display", "block");
            $("#resource_company").removeAttr('disabled');
        }
        else
        {
            $("#companydiv").css("display", "none");
            $("#resource_company").val('');
            $("#resource_company").attr('disabled','disabled');
        }

        
    });
    
    </script>

