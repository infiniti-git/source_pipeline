@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Manage Resources</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
      @include('includes.alerts')
  <a href="{{route('admin/add_resource')}}" class="btn btn-success pull-right btn-sm">Add New</a> <div class="clearfix"></div><br/>
  <a href="{{route('admin/export_excel')}}" class="btn btn-success pull-right btn-sm">Export</a> <div class="clearfix"></div><br/>
  <table id="dataTablesexample" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Lead</th>
                <th>Designation</th>
                <th>Source</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          
            @if(isset($resources))
               @php $i = 1 @endphp
                @foreach($resources as $value)
                <tr>
                    <td>{{$i++}}</td>
                    <td>{{$value->name}}</td>
                    <td>{{$value->email}}</td>
                    <td>{{$value->supervisor}}</td>
                    <td>{{$value->teamname}}</td>
                    <td>@if($value->resource == 1) 
                            Company
                        @else
                            Direct
                        @endif</td>
                    <td>@if($value->status ==1) 
                            Active
                        @else
                            InActive
                        @endif</td>
                    <td>
                        <a href="{{route('admin/edit_resource',['resourceId' => $value->employeeId])}}" class="btn btn-success btn-sm">Edit</a>
                        @if($value->status ==1) 
                           <a onclick="deactivateResource({{$value->employeeId}})" href="javascript:void(0)" class="btn btn-info btn-sm">DeActive</a>
                        @else
                            <a class="btn btn-info btn-sm" disabled>DeActive</a>
                        @endif
                        <!--<a href="{{route('admin/delete_resource',['resourceId' => $value->employeeId])}}" onclick="return confirmFunction()" id="resourcedelete" class="btn btn-danger btn-sm">Delete</a>href="{{route('admin/deactivate_resource',['resourceId' => $value->employeeId])}}"-->
                    </td>  
                </tr>
                @endforeach
            @endif

        </tbody>
    </table>
</div>
@include('includes/scripts')
@include('includes/footer')


<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTablesexample').DataTable();
    });

    function  deactivateResource(id) {
        $('.confirm_content').html('Are you sure want to deactivate the resource?');
        $("#confirm_id").val(id);
        $("#confirm_dialog").modal('show');
     }

     $("#confirm-btn-yes").on("click", function(){
        //callback(true);
        var id = $("#confirm_id").val();
        DeactivateResource(id);
        $("#confirm_dialog").modal('hide');
    });

    $("#confirm-btn-no").on("click", function(){
        // callback(false);
        $("#confirm_id").val('');
        $("#confirm_dialog").modal('hide');
        callback(false);
     });

    function confirmFunction() {
        if(confirm("Are you sure want to delete employee")){
            return true;
        }else{
           return false;
        }
    }
</script>