@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-md-12">
            <div class="col-md-6">
                <h2 class="page-header">Resource Leave</h2>
            </div>
        <div class="col-md-6">
            <a href="{{route('admin/resource_add_leave')}}" class="btn btn-success pull-right">Add Leave</a>
        </div>

        </div>
        <!-- /.col-lg-12 -->
    </div>

  <table id="dataTablesexample" class="table table-striped table-bordered table-hover" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Resource Type</th>
                <th>Name</th>
                <th>From Date</th>
                <th>To Date </th>
                <th>Days</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Direct</td>
                <td>Employee one</td>
                <td>15-03-2018</td>
                <td>16-03-2018</td>
                <td>2</td>
                <td>
                    <a href="#" class="btn btn-sm btn-info">Edit</a>
                    <a href="#" class="btn btn-sm btn-danger">Delete</a>
                </td>               
            </tr>
            <tr>
                <td>2</td>
                <td>Direct</td>
                <td>Employee Two</td>
                <td>16-03-2018</td>
                <td>16-03-2018</td>
                <td>1</td>
                <td>
                    <a href="#" class="btn btn-sm btn-info">Edit</a>
                    <a href="#" class="btn btn-sm btn-danger">Delete</a>
                </td>             
            </tr>
            <tr>
                <td>3</td>
                <td>Direct</td>
                <td>Employee three</td>
                <td>15-03-2018</td>
                <td>18-03-2018</td>
                <td>4</td>
                <td>
                    <a href="#" class="btn btn-sm btn-info">Edit</a>
                    <a href="#" class="btn btn-sm btn-danger disabled">Delete</a>
                </td>           
            </tr>
        </tbody>
    </table>

@include('includes/footer')


<script type="text/javascript">
    $(document).ready(function() {
    $('#dataTablesexample').DataTable();
} );
</script>