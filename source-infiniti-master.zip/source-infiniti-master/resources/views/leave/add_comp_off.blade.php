@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add Comp-Off for Resource</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
@include('includes.alerts')    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="AddCompoffForm" method="post" action="insert_compoff">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Resource Type</label>
                                     <select name="employee_type" class="form-control employee_type" onchange="changeEmployeeType(this)">
                                        <option value=""> Select </option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6" id="company_select_div" style="display: none;" >
                                <div class="form-group">
                                    <label>Company</label>
                                    <select name="company" class="form-control" id="company_select" onchange="changeCompany(this)">
                                        <option value="">- Select -</option>
                                        
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Employee</label>
                                    <select name="employee" class="form-control" id="employee_select">
                                        <option value="">- Select -</option>
                                       <!--  @foreach($employees as $employee)
                                            <option value="{{$employee->id}}">{{$employee->name}}</option>
                                        @endforeach -->
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Date</label>
                                    <input class="form-control dateite" name="compoff_date" placeholder="Select Date" readonly="true" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Day type</label>
                                    <select name="day_type" class="form-control leave_type">
                                        <option value="">- Select -</option>
                                        <option value="1">Full Day</option>
                                        <option value="2">Half Day</option>
                                        <option value="3">Other</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-6 hours hidden">
                                <div class="form-group">
                                    <label>Hour(s)</label>
                                    <input type="text" class="form-control" disabled="true" id="hours" name="hours" placeholder="Give Hours" />
                                </div>                               
                            </div>
                            <div class="col-lg-12 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" value="Save" name="Add_compoff" />
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')

<script>
    
var today = new Date();
var startDate = new Date(today.getFullYear(), today.getMonth(), 1);
var endDate = new Date(today.getFullYear(), today.getMonth()+1, 0);


$('.dateite').datepicker({
    format: 'dd-mm-yyyy',
    autoclose: true,
    startDate: startDate,
    endDate: endDate
});

$('#AddCompoffForm').validate({ // initialize the plugin
        rules: {
            employee: {
                required: true,
            },
            compoff_date: {
                required: true,
            },
            day_type:
            {
                required: true,
            },
            hours:
            {
                required: true,
            },
        },
        messages :{
            employee : {
                required : 'Please select Employee',
            },
            compoff_date : {
                required : 'Please select Date',
            },
            day_type : {
                required : 'Please select Day type',
            },
            hours : {
                required : 'Please give Hours',
            },
        }
    });

    $(".leave_type").change(function(event) 
    {
        if($(this).val()==3)
        {
            $(".hours").removeClass('hidden').show();
            $("#hours").removeAttr('disabled');
        }
        else
        {
            $(".hours").addClass('hidden').hide();
            $("#hours").attr('disabled','disabled');
        }
    });
</script>

@include('includes.scripts')