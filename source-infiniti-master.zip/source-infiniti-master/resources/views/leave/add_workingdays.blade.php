@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add/Update Working Day for Current Month</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

@include('includes.alerts') 

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="AddWorkingDaysForm" action="workingdays_for_month" method="post">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Month</label>
                                   <input type="text" class="form-control" value="{{$month}}" readonly="true" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Year</label>
                                    <input type="text" class="form-control" value="{{$year}}" readonly="true" />
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Working Day(s)</label>
                                    @php
                                        if($work_day!='')
                                        {
                                            $days = explode('.', $work_day);
                                            if($days[1]>0)
                                            $days = $work_day;
                                            else
                                            $days = $days[0];
                                        }
                                        else
                                        {
                                            $days = '';
                                        }
                                    @endphp
                                    <input class="form-control" id="working_days" name="working_days" placeholder="Enter Working Day(s)" value="{{$days}}" />
                                </div>                               
                            </div>
                            <div class="col-lg-12 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" name="addWorkingDays" value="Save" />
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')
<script type="text/javascript">       
    var maxdays = daysInThisMonth();
        $('#AddWorkingDaysForm').validate({ // initialize the plugin
        rules: {
            working_days: {
                required: true,
                number:true,
                max:maxdays,
                min:1,
            }
        },
        messages :{
            working_days : {
                required : 'Please enter Working Day(s)',
                number: 'Please enter only numbers',
                max:  'Number of workingdays should not be more than '+maxdays+ ' days',
                min: 'Number of working day should be minimum one day',
            },
        }
    });
    function daysInThisMonth() {
      var now = new Date();
      return new Date(now.getFullYear(), now.getMonth()+1, 0).getDate();
    }
    </script>
