@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Leave/Comp-off Available Balance for the Current Month</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

  <table id="dataTablesexample" class="table table-striped table-bordered table-hover" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Resource Type</th>
                <th>Name</th>
                <th>Available CL Day(s)</th>
                <th>Available Compoff Day(s)</th>
                <!-- <th>Expired Compoff Day(s)</th>     -->
            </tr>
        </thead>
        <tbody>
            @if(isset($emloyeeAvailLeave))
               @php $i = 1 @endphp
                @foreach($emloyeeAvailLeave as $value)
                <tr>
                    <td>{{$i++}}</td>
                    <td>
                       {{$value['resource_type']}}
                    </td>
                    <td>{{$value['employee_name']}}</td>
                    <td>
                        {{$value['avail_cl']}}
                    </td>
                    <td>
                        {{$value['avail_comp_off']}}
                    </td>
                </tr>
                @endforeach
            @endif
        </tbody>
    </table>
@include('includes/footer')

<script type="text/javascript">
$(document).ready(function() 
{
    $('#dataTablesexample').DataTable();
});
</script>