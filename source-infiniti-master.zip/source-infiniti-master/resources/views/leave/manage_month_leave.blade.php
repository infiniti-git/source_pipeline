@include('includes.header')
<div id="page-wrapper">
   <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">View Leave Details</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
@include('includes.alerts')    
   <div class="clearfix"></div>
         <div class="">
             <form action="resource_month_leave" method="get" id="GetMonthForm">
            <div class="col-md-3">
            <div class="form-group">
                
                <input type="text" class="form-control"  id="select_month" name="month" placeholder="Select Month/Year" readonly="true" />

              
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                
                <input type="submit" class="btn btn-sm btn-success m-t" name="get_month" value="Submit" />
                <a href="resource_month_leave" class="btn btn-sm btn-danger m-t" >Clear </a>
            </div>                               
        </div>
        </form>
    </div>
       
    
    <div class="clearfix"></div>
  <table id="dataTablesexample" class="table table-striped table-bordered table-hover" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>Resource Type</th>
                <th>Month</th>
                <th>Name</th>
                 <th>Leave Type</th>
                <th>Date</th>
                <th>Day type</th>
                <th>Action</th>
               
            </tr>
        </thead>
        <tbody>

             @if(isset($monthLeaves))
               @php $i = 1 @endphp
                @foreach($monthLeaves as $value)
                <tr>
                    <td>{{$i++}}</td>
                    <td>
                        @if($value->resource ==1) 
                            Company
                        @else
                            Direct
                        @endif
                    </td>
                    <td>{{$monthName}}</td>
                    <td>{{$value->name}}</td>
                    <td>@if($value->leave_type==1)
                        CL
                        @elseif($value->leave_type==2)
                        Comp Off
                        @else
                        LOP
                        @endif
                    </td>
                    <td>{{date('d-m-Y',strtotime($value->date))}}</td>
                    <td>
                        @if($value->day_type==1)
                        Full Day
                        @else
                        Half Day
                        @endif
                    </td>
                    <td>
                        <a title="Cancel Leave" data-toggle="tooltip" onclick="cancelLeave({{$value->leave_id}})" href="javascript:void(0)"><i class="fa fa-remove"></i> </a>
                    </td>
                    
                 </tr>
                @endforeach
            @endif
        </tbody>
    </table>
@include('includes/scripts')
@include('includes/footer')


<script type="text/javascript">

    $(document).ready(function() {
        $('#dataTablesexample').DataTable();

        $('#select_month').datepicker({
            autoclose: true,
            minViewMode: 1,
            format: 'mm/yyyy'
        });
    });

     $('#GetMonthForm').validate({ // initialize the plugin
        rules: {
            month: {
                required: true,
            },
        },
        messages :{
            month : {
                required : 'Please select Month',
            },
        }
    });

     function  cancelLeave(id) {
        // deleteLeave(id);
        $('.confirm_content').html('Are you sure want to cancel the leave?');
        $("#confirm_id").val(id);
        $("#confirm_dialog").modal('show');

     
     }

     $("#confirm-btn-yes").on("click", function(){
        // callback(true);
        var id = $("#confirm_id").val();
        deleteLeave(id);
        $("#confirm_dialog").modal('hide');
    });

    $("#confirm-btn-no").on("click", function(){
        // callback(false);
        $("#confirm_id").val('');
        $("#confirm_dialog").modal('hide');
        callback(false);
     });



    //  .on('changeDate', function(selected){
    //     startDate = new Date(selected.date.valueOf());
    //     startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
    //     $('.to').datepicker('setStartDate', startDate);
    // }); 
</script>