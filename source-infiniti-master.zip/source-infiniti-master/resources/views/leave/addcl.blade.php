@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Load CL for the Current Month</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

@include('includes.alerts') 

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="AddCLForm" action="applycl_resource" method="post">
                            {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Resource Type</label>
                                    <select name="employee_type" class="form-control employee_type">
                                        <option value=""> All </option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Employee</label>
                                    <select name="employee" class="form-control employees">
                                        <option value="">- Select -</option>
                                        @foreach($employees as $employee)
                                            <option value="{{$employee->id}}">{{$employee->name}}</option>
                                        @endforeach
                                    </select>
                                </div>                               
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Available CL Till Now</label>
                                    <input class="form-control" id="available_cl" name="available_cl" placeholder="Enter CL Days" />
                                    <input type="hidden" id="employee_leave_master" name="employee_leave_id" />
                                </div>                               
                            </div>
                            <div class="col-lg-12 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" name="addcl" value="Save" />
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')
<script type="text/javascript">       
        $('#AddCLForm').validate({ // initialize the plugin
        rules: {
            employee: {
                required: true,
            },
            available_cl: {
                required: true,
            }
        },
        messages :{
            employee : {
                required : 'Please select Employee',
            },
            available_cl : {
                required : 'Please enter CL Days',
            },
        }
    });

    $(".employees").change(function(event) 
    {
        if($(this).val()!='')
        {
            $.ajax({
                url: '/employee_cl',
                type: 'POST',
                data: {emp_id: $(this).val(),_token: "{{ csrf_token() }}"},
            })
            .done(function(result) 
            {
                var a = result.cldays;
                $("#available_cl").val(result.cldays);
                $("#employee_leave_master").val(result.clid);
            })
            .fail(function() {
                console.log("error");
            })
        }
        else
        {
            $("#available_cl").val('');
            $("#employee_leave_master").val('');
        }
    });
    </script>
@include('includes.scripts')
