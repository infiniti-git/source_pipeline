@include('includes.header')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Apply Leave for Resource</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    @include('includes.alerts')
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <form role="form" id="add_resource_leave" action="applying_leave" method="post">
                                 {!! csrf_field() !!}
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Resource Type</label>
                                     <select name="employee_type" id="employee_type" class="form-control employee_type" onchange="changeEmployeeType(this)">
                                        <option value=""> Select </option>
                                        <option value="1">Company</option>
                                        <option value="2">Direct</option>
                                    </select>
                                </div>                               
                            </div>

                            <div class="col-lg-6" id="company_select_div" style="display: none;" >
                                <div class="form-group">
                                    <label>Company</label>
                                    <select name="company" class="form-control" id="company_select" onchange="changeCompany(this)">
                                        <option value="">- Select -</option>
                                        
                                    </select>
                                </div>                               
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Employee</label>
                                    <select name="employee" class="form-control" id="employee_select">
                                        <option value="">- Select -</option>
                                       <!--  @foreach($employees as $employee)
                                            <option value="{{$employee->id}}">{{$employee->name}}</option>
                                        @endforeach -->
                                    </select>
                                </div>                               
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Please Pick Date(s)</label>
                                    <input class="form-control datepicker" readonly="true" id="startdate" name="employee_leave_dates" placeholder="Select Date" />
                                    
                                </div>                               
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Leave Type</label>
                                     <select name="leave_type" id="leave_type" class="form-control leave_type">
                                        <option value="">- Select -</option>
                                        <option value="1">CL</option>
                                        <option value="2">Comp off</option>
                                        <option value="3">LOP</option>
                                    </select>
                                </div>                               
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Leave Full Day/Half Day</label>
                                    <select name="day_type" class="form-control">
                                        <option value="">- Select -</option>
                                        <option value="1">Full Day</option>
                                        <option value="2">Half Day</option>
                                    </select>                                   
                                </div>                               
                            </div>


                            <div class="col-lg-6 pull-right">
                                <div class="form-group pull-right">
                                   <input type="submit" class="btn btn-success" value="Save" name="ApplyLeave" />
                                </div>                               
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('includes.footer')
<script type="text/javascript">   
        $('#employee_type').change(function(){
            var empType = $("#employee_type").val();
            $('#leave_type').val('');
            if(empType == 1)
                $('#leave_type option[value="1"]').not(this).prop('disabled', true);
            else
                $('#leave_type option[value="1"]').not(this).prop('disabled', false);
        });    
   
        $('#add_resource_leave').validate({ // initialize the plugin
        rules: {
            employee: {
                required: true,
            },
            employee_leave_dates: {
                required: true,
            },
            leave_type:{
                required: true,
            },
            day_type: {
                required: true,
            },
        },
        messages :{
            employee : {
                required : 'Please select Employee',
            },
            employee_leave_dates : {
                required : 'Please select Leave Date',
            },
            leave_type : {
                required : 'Please select Leave Type',
            },
            day_type : {
                required : 'Please select Day Type',
            },
        }
    });

    // $(".leave_type").change(function(event){
    //     var Emp_id = $(".employees").val();
    //     var leave_type = $(this).val();
    //     if($(this).val()!='' && Emp_id!='')
    //     {
    //         $.ajax({
    //             url: '/get_leave_details',
    //             type: 'POST',
    //             data: {emp_id: Emp_id, lev_type:leave_type, _token: "{{ csrf_token() }}"},
    //         })
    //         .done(function(result) 
    //         {
    //             $("#available_cl").val(result.cldays);
    //             $("#employee_leave_master").val(result.clid);
    //         })
    //         .fail(function() {
    //             console.log("error");
    //         })
    //     }
    //     else
    //     {
    //         $("#employee_leave_master").val('');
    //     }
    // });

    $("#startdate").datepicker({
        multidate: true,
        format: 'dd-mm-yyyy',
        showOn: "button",
        buttonImage: "calendar.gif",
        buttonImageOnly: true
    });
    </script>
@include('includes.scripts')