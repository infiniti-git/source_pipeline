<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*LOGIN ROUTES STARTS */

Route::get('/', ['as' =>'login', 'uses'=>'LoginController@index']);
Route::post('/dologin', ['as' =>'dologin', 'uses'=>'LoginController@LoginVerify']);
Route::get('/logout', ['as' =>'logout', 'uses'=>'LoginController@Logout']);

/*LOGIN ROUTES  ENDS  */


/* -- ADMIN -- ROUTES STARTS HERE */

Route::get('/admin/dashboard', ['as' =>'admin/dashboard', 'uses'=>'AdminController@index']);
Route::get('/admin/manage_userroles', ['as' =>'admin/manage_userroles', 'uses'=>'AdminController@ManageUserRoles']);
Route::get('/admin/new_userroles', ['as' =>'admin/new_userroles', 'uses'=>'AdminController@NewUserRoles']);
Route::get('/admin/manage_users', ['as' =>'admin/manage_users', 'uses'=>'AdminController@ManageUsers']);


Route::get('/admin/resource_leave', ['as' =>'admin/resource_leave', 'uses'=>'AdminController@ResourceLeave']);
Route::get('/admin/resource_add_cl', ['as' =>'admin/resource_add_cl', 'uses'=>'AdminController@ResourceAddCL']);
Route::get('/admin/resource_manage_leave', ['as' =>'admin/resource_manage_leave', 'uses'=>'AdminController@ResourceManageLeave']);

Route::get('/admin/resource_month_leave', ['as' =>'admin/resource_month_leave', 'uses'=>'AdminController@ResourceMonthLeave']);


Route::post('/admin/applycl_resource', ['as' =>'/admin/applycl_resource', 'uses'=>'AdminController@ApplyCLforResource']);



// -- AJAX URL STARTS -- // 
Route::post('/get_employee', ['as' =>'admin/get_employee', 'uses'=>'AjaxController@GetEmployeeByResourceType']); 
Route::post('/employee_cl', ['as' =>'admin/employee_cl', 'uses'=>'AjaxController@GetEmployeeCL']);
Route::post('/get_leave_details', ['as' =>'admin/get_leave_details', 'uses'=>'AjaxController@GetLeaveDetails']);
Route::get('/update_ehour', ['as' =>'admin/update_ehour', 'uses'=>'AjaxController@UpdateEhour']);
Route::get('/search_ehour',array('as'=>'admin/search_ehour','uses'=>'AjaxController@SearchEhour'));
Route::post('/get_employeebycompany', ['as' =>'admin/get_employeebycompany', 'uses'=>'AjaxController@GetEmployeeByCompany']); 
Route::get('/calculate_payroll', ['as' =>'admin/calculate_payroll', 'uses'=>'AjaxController@CalculatePayroll']); 
Route::get('/ehour_details_daterange', ['as' =>'admin/ehour_details_daterange', 'uses'=>'AjaxController@EhourDetailsDaterange']);
Route::get('/get_companies', ['as' =>'admin/get_companies', 'uses'=>'AjaxController@getCompanies']);
Route::post('/get_employees', ['as' =>'admin/get_employees', 'uses'=>'AjaxController@getEmployees']);
Route::post('/delete_leave', ['as' =>'admin/delete_leave', 'uses'=>'AjaxController@deleteLeave']);
Route::post('/deactivate_resource', ['as' =>'admin/deactivate_resource', 'uses'=>'AjaxController@DeactivateResource']);
// -- AJAX URL  ENDS  -- //



/* EMPLOYEE LEAVE CONTROLLER STARTS */
Route::get('/admin/resource_add_leave', ['as' =>'admin/resource_add_leave', 'uses'=>'EmployeeLeaveController@ResourceAddLeave']); 
Route::post('/admin/applying_leave', ['as' =>'admin/applying_leave', 'uses'=>'EmployeeLeaveController@ApplyLeaveforResource']); 
Route::get('/payroll_applying_leave', ['as' =>'admin/payroll_applying_leave', 'uses'=>'EmployeeLeaveController@ApplyLeaveforResource']);
Route::get('/admin/add_working_days', ['as' =>'admin/add_working_days', 'uses'=>'EmployeeLeaveController@AddWorkingDays']);
Route::post('/admin/workingdays_for_month', ['as' =>'admin/workingdays_for_month', 'uses'=>'EmployeeLeaveController@InsertWorkingDays']);
/* EMPLOYEE LEAVE CONTROLLER  ENDS  */



/* EMPLOYEE COMPOFF CONTROLLER STARTS */ 
Route::get('/admin/add_comp_off', ['as' =>'admin/add_comp_off', 'uses'=>'EmployeeCompoffController@AddCompOff']); 
Route::post('/admin/insert_compoff', ['as' =>'admin/insert_compoff', 'uses'=>'EmployeeCompoffController@InsertCompOff']); 
/* EMPLOYEE COMPOFF CONTROLLER  ENDS  */


/* Resource Controller Starts*/
Route::get('/admin/manage_resources/{resourceStatus}', ['as' =>'admin/manage_resources', 'uses'=>'ResourceController@ManageResources']);
Route::get('/admin/add_resource', ['as' =>'admin/add_resource', 'uses'=>'ResourceController@AddResource']);
Route::post('/admin/add_new_resource', ['as' =>'admin/add_new_resource', 'uses'=>'ResourceController@AddNewResource']);
Route::get('/admin/edit_resource/{resourceId}', ['as' =>'admin/edit_resource', 'uses'=>'ResourceController@EditResource']);
Route::post('/admin/update_resource', ['as' =>'admin/update_resource', 'uses'=>'ResourceController@UpdateResource']);
Route::get('/admin/delete_resource/{resourceId}', ['as' =>'admin/delete_resource', 'uses'=>'ResourceController@DeleteResource']);
Route::get('/admin/export_excel', ['as' =>'admin/export_excel', 'uses'=>'ResourceController@ExportExcel']);
/*Route::post('/admin/checkemailalreadyexists',function()
    {

      $user = \App\Http\Models\Employees::where('email', Illuminate\Support\Facades\Input::get('resource_email'))->first();

      if ($user) {
              return 0;
      } else {
          return "";
      }
    });*/
/* Resource Controller Ends*/


/* PAYROLL CONTROLLER STARTS */
Route::get('/admin/payroll', ['as' =>'admin/payroll', 'uses'=>'PayrollController@index']); 
Route::get('/admin/generatepayroll/{empid}/{noofWD}/{noofehourdays}/{month}/{year}', ['as' =>'admin/generatepayroll', 'uses'=>'PayrollController@GeneratePayroll']); 
Route::post('/admin/generatedirectpayrollpdf', ['as' =>'admin/generatedirectpayrollpdf', 'uses'=>'PayrollController@GenerateDirectPayrollPDF']);

Route::get('/admin/payroll/company', ['as' =>'admin/company_payroll', 'uses'=>'PayrollController@companyPayroll']); 
Route::post('/calculate_company_payroll', ['as' =>'admin/calculate_company_payroll', 'uses'=>'AjaxController@calculateCompanyPayroll']); 

Route::get('/admin/payroll/force_generate', ['as' =>'admin/force_generate', 'uses'=>'PayrollController@forceGenerateCompanyPayroll']); 
Route::get('/admin/payroll/generate', ['as' =>'admin/generate', 'uses'=>'PayrollController@generateCompanyPayroll']);
Route::get('/admin/payroll/company_pay_download', ['as' =>'admin/generate', 'uses'=>'PayrollController@downloadCompanyPayroll']);
Route::post('/company_payroll_update', ['as' =>'admin/company_payroll_update', 'uses'=>'AjaxController@CompanyPayrollUpdate']);
/* PAYROLL CONTROLLER  ENDS  */


/* CRON JOB URL STARTS */
Route::get('/add_cl_resource', ['as' =>'/add_cl_resource', 'uses'=>'AjaxController@AddCLResource']);
Route::get('/compoff_expiry', ['as' =>'/compoff_expiry', 'uses'=>'AjaxController@CompOffExpiry']);
/* CRON JOB URL  ENDS  */

/* Ehours Controller Starts*/
Route::get('/admin/manage_ehours', ['as' =>'admin/manage_ehours', 'uses'=>'EhoursController@ManageEhours']);
Route::get('/admin/import-export-csv-excel',array('as'=>'admin/import-export-csv-excel','uses'=>'EhoursController@importExportExcelORCSV'));
Route::post('/admin/import-csv-excel',array('as'=>'import-csv-excel','uses'=>'EhoursController@importFileIntoDB'));
Route::get('download-excel-file/{type}', array('as'=>'excel-file','uses'=>'EhoursController@downloadExcelFile'));
/* Ehours Controller Ends*/

/* -- ADMIN -- ROUTES  ENDS  HERE */

/* RMS Routes Starts */
Route::get('/home', 'RmsDashboardController@index')->name('job.home');
Route::match(['get'], '/jobpost/{job_reference}/{d?}', 'JobsController@show')->name('job.show');
Route::match(['get'], '/apply/{job_reference}', 'JobsController@apply')->name('job.apply');
Route::match(['post'], '/submitapplication','JobsController@submitapplication')->name('job.submitapplication');


Route::prefix('jobs')->group(function () {
    Route::match(['get'], '/create', 'JobsController@create')->name('job.create');
    Route::match(['post'], '/store', 'JobsController@store')->name('job.store');
    Route::match(['post'], '/storequestions', 'QuestionsController@storequestions')->name('question.store');
    Route::match(['get'], '/jobdashboard/{jobid}/{filter_status?}', 'JobsController@jobDashboard')->name('job.dashboard');
    Route::match(['post'], '/updateApplicationStatus', 'JobsController@updateApplicationStatus')->name('jobs.application.updatestatus');
    Route::match(['post'], '/deletejob', 'JobsController@destroy')->name('job.delete');
Route::match(['get'], '/downloadapplicationfile/{appid}', 'JobsController@downloadApplicationFile')->name('job.application.downloadfile');
});
/* RMS Routes Ends */

// Route::get('/manage_resources', ['as' =>'manage_resources', 'uses'=>'resources@index']);
// Route::get('/add_resource', ['as' =>'add_resource', 'uses'=>'resources@AddResource']);

Route::get('/cron_cl', 'CronController@addCl');
//Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
