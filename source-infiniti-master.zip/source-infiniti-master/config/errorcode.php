<?php

return [

      // Default
      '0' => 'Try catch error.',
      '1' => 'Success.',
      '2' => 'Error.',
      '3' => 'No of working days not assigned to this month'
      

];
